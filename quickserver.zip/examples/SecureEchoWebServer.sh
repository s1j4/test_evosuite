#!/bin/bash
exec java -server -ea -jar ./../dist/QuickServer.jar -load conf/SecureEchoWebServer.xml