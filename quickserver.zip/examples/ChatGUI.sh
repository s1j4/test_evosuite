#!/bin/bash
#exec java -jar dist/chatclient.jar home 127.0.0.1 7412
exec java -jar dist/chatclient.jar "$@"