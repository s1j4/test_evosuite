
QuickServer Application has a Windows Service

In this section of the QuickServer Examples we look into how a server written 
using QuickServer can be made to run has a Windows Service [Win Nt/2000/XP]

In this example we will try to get our FtpServer example has a windows
service. To do this we will be using an open-source library 

JMidoriService [http://www003.upp.so-net.ne.jp/midori/JMidoriService.html]
License: GNU LGPL license

You can download the full library from 
http://sourceforge.net/projects/jmidoriservice/ 
