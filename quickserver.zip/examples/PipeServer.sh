#!/bin/bash
exec java -server -cp ./../dist/QuickServer.jar:dist/pipeserver.jar pipeserver.PipeServer