Twittetr4J is a Twitter API binding library for the Java language licensed under Apache License 2.0.

readme-libs.txt - this file
twitter4j-core.jar - REST and Search API support
twitter4j-examples.jar - examples : use with twitter4j-core