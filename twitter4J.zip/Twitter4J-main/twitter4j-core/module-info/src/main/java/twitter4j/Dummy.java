package twitter4j;

@SuppressWarnings("unused")
class Dummy {
}
