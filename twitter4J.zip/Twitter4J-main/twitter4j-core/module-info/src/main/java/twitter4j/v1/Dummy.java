package twitter4j.v1;

@SuppressWarnings("unused")
class Dummy {
}
