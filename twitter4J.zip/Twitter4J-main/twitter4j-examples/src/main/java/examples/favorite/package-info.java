/**
 * example codes for favorite resources
 */
package examples.favorite;