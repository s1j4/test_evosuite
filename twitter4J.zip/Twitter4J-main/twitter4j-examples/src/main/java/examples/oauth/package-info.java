/**
 * example code for OAuth dance
 */
package examples.oauth;