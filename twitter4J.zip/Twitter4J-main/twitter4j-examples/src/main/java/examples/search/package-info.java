/**
 * example code for the search API
 */
package examples.search;