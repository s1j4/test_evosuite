/**
 * example codes for block resources
 */
package examples.block;