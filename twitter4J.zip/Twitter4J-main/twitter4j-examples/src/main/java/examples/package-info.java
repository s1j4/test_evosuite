/**
 * Twitter4J examples
 */
package examples;