/**
 * example codes for geo resources
 */
package examples.geo;