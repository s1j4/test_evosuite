/**
 * example codes for streaming API
 */
package examples.stream;