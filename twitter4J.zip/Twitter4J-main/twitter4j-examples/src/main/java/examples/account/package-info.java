/**
 * example codes for account resources
 */
package examples.account;