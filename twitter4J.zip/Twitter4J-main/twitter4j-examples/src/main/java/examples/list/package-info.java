/**
 * example codes for list resources
 */
package examples.list;