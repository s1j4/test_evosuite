/**
 * example codes for spam reporting resources
 */
package examples.spamreporting;