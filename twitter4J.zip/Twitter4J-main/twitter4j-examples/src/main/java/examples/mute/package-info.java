/**
 * example codes for media APIs
 */
package examples.mute;