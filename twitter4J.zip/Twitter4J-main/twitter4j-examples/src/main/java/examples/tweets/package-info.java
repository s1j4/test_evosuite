/**
 * example codes for tweets resources
 */
package examples.tweets;