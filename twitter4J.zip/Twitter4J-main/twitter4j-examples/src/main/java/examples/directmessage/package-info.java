/**
 * example codes for direct message resources
 */
package examples.directmessage;