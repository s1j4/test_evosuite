/**
 * example codes for timeline resources
 */
package examples.timeline;