/**
 * example codes for friendship resources
 */
package examples.friendship;