/**
 * example codes for saved searches resources
 */
package examples.savedsearches;