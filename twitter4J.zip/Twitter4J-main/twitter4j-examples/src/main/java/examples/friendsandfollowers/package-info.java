/**
 * example codes for friends and followers resources
 */
package examples.friendsandfollowers;