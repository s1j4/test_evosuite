/**
 * example code for trends resources
 */
package examples.trends;