/**
 * example codes explaining getting and storing JSON
 */
package examples.json;