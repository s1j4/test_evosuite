/**
 * example codes for user resources
 */
package examples.user;