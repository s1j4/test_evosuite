package com.pmdesigns.jvc;

public interface Destroyable {

	void destroy();
}
