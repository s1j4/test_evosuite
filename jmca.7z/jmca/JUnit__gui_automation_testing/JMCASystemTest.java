package com.soops.CEN4010.JMCA;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.IOException;
import java.io.File;
import javax.swing.*;
import javax.swing.filechooser.*;

/**
 * Unit test for simple App.
 */
public class JMCASystemTest extends TestCase
{

	static JMCAController control;

    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public JMCASystemTest( String testName )
    {
        super( testName );

    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        control = new JMCAController();
        control.setup();

        return new TestSuite( JMCASystemTest.class );
    }

    /**
     * Rigourous Test :-)
     */
    public void testJMCASystem()
    {
/*	Leaving this test code here, but don't think its that helpful at the moment

		String testFilename ="c:\\java\\JMCAController.java";

    	assertNotNull(control); //Instantiated?

		Component parentContainer = control.getContainer();
		assertNotNull(parentContainer);

		JMCAView view = control.getView();
		assertNotNull(view);

		//TestPlan Step 3
    	JTextField inputFile = (JTextField) TestUtils.getChildNamed(parentContainer, "inputFile");
    	assertNotNull(inputFile); //component found?

    	inputFile.setText(testFilename);
    	inputFile.postActionEvent();

		assertEquals(view.getFilename(), testFilename);


		//TestPlan Step 4
		JButton selectFileButton = (JButton) TestUtils.getChildNamed (parentContainer, "selectFileButton");
		assertNotNull(selectFileButton);
		selectFileButton.doClick();


    	JButton analyzeButton = (JButton) TestUtils.getChildNamed (parentContainer, "analyzeButton");
		assertNotNull(analyzeButton);

		analyzeButton.doClick();

*/

    	assertTrue( true );

    }
}
