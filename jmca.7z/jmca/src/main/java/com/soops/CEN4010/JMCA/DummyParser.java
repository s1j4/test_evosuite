package com.soops.CEN4010.JMCA;

public class DummyParser implements Parser
{
    public ASTNode parse (java.io.Reader rdr) {
        return null;
    }
}
