cp ../Summa/Common/summa-common-build-5003.jar .
