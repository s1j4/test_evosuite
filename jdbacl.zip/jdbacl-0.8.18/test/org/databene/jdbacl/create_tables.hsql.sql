create table T1 (
  ID   int,
  NAME varchar(30) not null,
  constraint T1_PK primary key (ID)
);
insert into T1 values (1, 'R&B');