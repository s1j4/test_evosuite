drop table table4;
drop table table3;
drop table table2;
drop table table1;
drop sequence seq1;
