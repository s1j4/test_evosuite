RELEASE NOTES ClassViewer 5.2.1:
---------------------------------------

Font size functionality and some improvements for the 5.2.1 release.


Updated FEATURES:


Ability to increase font size or decrease within a set limit. Can set in ClassViewerConfig.xml a larger font default size.

Font size can increase from base of 12 to 14 or down to 10. Or with larger default from base of 13 to 17, or down to 11.

Can copy from Results window with a right click which copies to system clipboard and gives a notification.

Cleaned up some odd behavior with right click.
  

The application can be run as a full application from the executable
jar ClassViewer.jar, or you can unpack and run com.jstevh.viewer.ClassViewer and remember to have
your classpath set properly for any classes or jars that you want to view.

To unpack ClassViewer.jar you can use the command: jar -xf ClassViewer.jar


BASIC TROUBLESHOOTING:

The application will not find classes without the file ClassViewerConfig.xml in the file directory
from which it is ran.

For instance if you execute the Jar file on the desktop, ClassViewerConfig.xml has to be on
the desktop.

That xml file contains information on known packages and where your browser is located.

You can also easily add packages to the xml file, while the program is set up to assume that
any packages that begin with "java" can be found at a default location.

When you click on the "Documents" button after having loaded a class it will call the application
at the location specified, which by default is C:\\Program Files\\Mozilla Firefox\\firefox.exe
but it's easy enough to change like to C:\\Program Files\\Internet Explorer\\IEXPLORE.EXE
simply by pasting that in to replace with a text editor.

If no <web> location is given and file is local the application will try to open the local file if a text editor
has been given.

