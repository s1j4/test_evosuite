package umd.cs.shop;

import java.util.*;

public class JSParserError extends Error {
    JSParserError() {
        super();
    }
}