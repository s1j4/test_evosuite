var p = new Promise(resolve, reject) {};
p.then(function(res) {})
.catch(function(err) {})
.finally(function() {});
