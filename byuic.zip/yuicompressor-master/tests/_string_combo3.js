function test(){
    for ( var i = 0; i < 3; i++ ) {
        var a = "a" + "bcd"[i];
    }
}
