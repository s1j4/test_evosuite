#!/usr/bin/env python
# encoding: utf-8
"""
@package byuic python compressor
@version p1.0
@copyright (c) 2008-2009 Brilaps, LLC (http://brilaps.com)
@projectUrl http://sourceforge.net/projects/byuic/
@license BSD License - http://www.opensource.org/licenses/bsd-license.php
"""

import os
import sys
import getopt
import fnmatch
from os.path import join

global jar_param_string

def usage():
    print "Usage: \npython byuic.py -d /path/to/webdir [-n] [-s] [-z] [-v]"
    print '''\nJavaScript Options:
    -h  Display help/usage information
    -d  Valid web directory path to act on
    -n  Minify only, do not obfuscate
    -s  Preserve all semicolons
    -z  Disable all micro optimizations
    -v  Display informational messages and warnings'''

def do_compression(file_to_compress, file_type):
    print "Compressing " + file_to_compress + "..."
    if file_type == 'js':
        os.system("java -jar ../yuicompressor*.jar --type js " + jar_param_string + " -o " + file_to_compress + " " + file_to_compress + " 1>/dev/null 2>>ERRORS")
    else:
        #CSS files do not utilize the JavaScript jar parameters
        os.system("java -jar ../yuicompressor*.jar --type css" + " -o " + file_to_compress + " " + file_to_compress + " 1>/dev/null 2>>ERRORS")    
    
def recursive_find(path, filter):
    matched = list()
    for root, dirs, files in os.walk(path):
        for name in files:
            if fnmatch.fnmatch(name,filter):
                matched.append(join(root, name));
    return matched

def main():
    global jar_param_string
    
    try:
        opts, args = getopt.getopt(sys.argv[1:], "hd:vnzs")
    except getopt.GetoptError, err:
        #Print help information and exit:
        print str(err) #Will print something like "option -a not recognized"
        usage()
        sys.exit(2)
    
    directory = None
    jar_params = []
    output_message = []
    
    for param, param_val in opts:
        if param in ("-h", "--help"):
            usage()
            sys.exit()
        elif param == "-d":
            directory = param_val
        elif param == "-v":
            jar_params.append('-v')
        elif param == "-n":
            jar_params.append('--nomunge')
        elif param == "-s":
            jar_params.append('--preserve-semi')
        elif param == "-z":
            jar_params.append('--disable-optimizations')    
        else:
            assert False, "unhandled option"
    
    #We must have a web directory parameter
    if directory == None or not os.path.exists(directory):
        print 'A valid web directory parameter (-d) is required!'
        usage()
        sys.exit()
    else:
        jar_param_string = ' '.join(jar_params)

    print "Locating JavaScript files to compress..."
    jsfiles = recursive_find(directory, '*.js')
    print "Compressing JavaScript files..."
    for f in jsfiles:
        #We'll skip already minified files and/or debug files since they shouldn't be used in production
        if not f.endswith('-min.js') and not f.endswith('-debug.js'):
            do_compression(f, 'js')
    print "Done compressing JavaScript files!"

    output_message.append('JavaScript files compressed: ')
    output_message.append(str(len(jsfiles)))

    print "Locating CSS files to compress..." 
    cssfiles = recursive_find(directory, '*.css')
    print "Compressing CSS files..."
    for f in cssfiles:
        do_compression(f, 'css')
    print "Done compressing CSS files!"

    output_message.append(', CSS files compressed: ')
    output_message.append(str(len(cssfiles)))

    print ''.join(output_message)
    print "Script complete!  Review the ERRORS file for errors.  If blank, all is well."

if __name__ == "__main__":
    main()
