#!/bin/sh

###################################################################################################################################
# @package byuic bash compressor
# @version b1.3
# @copyright (c) 2008-2009 Brilaps, LLC (http://brilaps.com)
# @projectUrl http://sourceforge.net/projects/byuic/
# @license BSD License - http://www.opensource.org/licenses/bsd-license.php
#
# Usage:
# 1) chmod this script to give it execute permissions 
#  (ex) chmod +x byuic.sh
# 2) Run the script and pass it the path to your web project needing compression and any optional parameters as needed
#  (ex) sh /path/to/byuic.sh -d /path/to/your/project
# 3) Run with -h to see the full usage statement (ex) sh /path/to/byuic.sh -h
###################################################################################################################################

#Track down the YUI Compressor (better than hardcoding the version #)
if ! [ `find ../ -type f -name yuicompressor\*.jar` ]
then
	echo "Unable to locate the YUI Compressor jar file!"
	exit 1
else 
	YUICOMPRESSOR=`find ../ -type f -name yuicompressor\*.jar`
fi

#Setup some script defaults
NO_ARGS=0
VALID_WEBDIR=0
PRESERVE_SEMI=""
DISABLE_MICRO_OPT=""
JSWARN=""

#Define a usage statement
function usage() {
	echo "Usage: sh byuic.sh -[hnszv]d /path/to/webdirectory)."
	echo "JavaScript Options:"
	echo "-h    Display help/usage information"
	echo "-d    Valid web directory path to act on (should be last parameter with a valid directory path)"
	echo "-n    Minify only, do not obfuscate"
	echo "-s    Preserve all semicolons"
	echo "-z    Disable all micro optimizations"
	echo "-v    Display informational messages and warnings"
}

if [ $# -eq "$NO_ARGS" ]  #Script invoked with no command-line args
 then
  usage
  exit 1 #Exit and explain usage, if no argument(s) given.
elif [ ${1:0:1} != '-' ] #The option list must begin with a '-'
  then
    echo "Invalid option value!"
    usage
    exit 1
fi

while getopts "hnszvd:path" input
do
 case $input in
  h ) usage
      exit 0;;
  n ) NOMUNGE="--nomunge";;
  s ) PRESERVE_SEMI="--preserve-semi";;
  z ) DISABLE_MICRO_OPT="--disable-optimizations";;
  v ) JSWARN="--verbose";;
  d ) WEBDIR="$OPTARG"
      if ! [ -d "$WEBDIR" ]; then
	    echo "Invalid web directory specified!"
	    exit 1
	  else 
	    VALID_WEBDIR=1
	  fi;; 
 esac
done

if [ $VALID_WEBDIR -eq 0 ] #Should have been set in the while loop if 'd' was provided
  then
  echo "The -d option must be specified last with a valid web directory path!"
  usage
  exit 1
fi

#Process JavaScript files
echo "Locating JavaScript files to compress..."
jslist=`find $WEBDIR -type f -name \*.js`
jscount=`find $WEBDIR -type f -name \*.js | wc -l` #0 is returned if none are found
echo "Compressing JavaScript files..." 
for jfile in $jslist
    do
     if [ ${jfile:(-7)} != '-min.js' ] && [ ${jfile:(-9)} != '-debug.js' ]; then
       echo "Compressing ${jfile}...."
       java -jar ${YUICOMPRESSOR} --type js ${NOMUNGE} ${PRESERVE_SEMI} ${DISABLE_MICRO_OPT} ${JSWARN} -o ${jfile} ${jfile} 1>/dev/null 2>>ERRORS
     fi
    done
echo "Done compressing JavaScript files!"
	
#Process CSS files
echo "Locating CSS files to compress..."
csslist=`find $WEBDIR -type f -name \*.css`
csscount=`find $WEBDIR -type f -name \*.css | wc -l` #0 is returned if none are found
echo "Compressing CSS files..."
for cfile in $csslist
 do
  echo "Compressing ${cfile}...."
  java -jar ${YUICOMPRESSOR} --type css -o ${cfile} ${cfile} 1>/dev/null 2>>ERRORS
 done
echo "Done compressing CSS files!"

#Exit cleanly
echo "JavaScript files compressed: ${jscount}, CSS files compressed: ${csscount}"
echo "Script complete!  Review the ERRORS file for errors.  If blank, all is well."
exit 0
