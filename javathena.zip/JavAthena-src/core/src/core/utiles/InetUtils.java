/*
 * InetUtils.java
 *
 * Created on September 20, 2005, 8:39 PM
 *
 * Copyright (c) 2006, Fran�ois Bradette
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of their contributors may be used to endorse or
 *       promote products derived from this software without specific prior
 *       written permission.
 *
 * This software is provided by the regents and contributors "as is" and any
 * express or implied warranties, including, but not limited to, the implied
 * warranties of merchantability and fitness for a particular purpose are
 * disclaimed.  In no event shall the regents and contributors be liable for any
 * direct, indirect, incidental, special, exemplary, or consequential damages
 * (including, but not limited to, procurement of substitute goods or services;
 * loss of use, data, or profits; or business interruption) however caused and
 * on any theory of liability, whether in contract, strict liability, or tort
 * (including negligence or otherwise) arising in any way out of the use of this
 * software, even if advised of the possibility of such damage.
 *
 * Translate from eAthena(c) by Fran�ois Bradette
 */

package core.utiles;

/**
 *
 * @author Francois
 */
import java.net.*;
public class InetUtils {
  /**
   * Donne le masque reseau associee a la classe d'une adresse 
   * Internet stockee dans quatre cases d'un tableau d'octets.
   * @param address tableau d'octets contenant l'adresse Internet.
   * @param offset index du premier octet de l'adresse dans le tableau.
   * @return l'objet adresse Internet contenant le masque reseau.
   * @exception UnknownHostException si l'adresse est de classe
   * D ou E.
   */
  public static InetAddress getMask(byte[] address, int offset)
    throws UnknownHostException {
    byte[] mask = new byte[4];
    if(address[offset]==0){
      throw new UnknownHostException();
    }
    mask[0]=(byte)255;
    if((address[offset]&  0x80000000)==0) {
      // Adresse de classe A
      return byteToInetAddress(mask,0);
    }
    mask[1]=(byte)255;
    if((address[offset]& 0x40)==0) {
      // Adresse de classe B
      return byteToInetAddress(mask,0);
    }
    if((address[offset] & 0x20)==0){
      // Adresse de classe C
      mask[2]=(byte)255;
      return byteToInetAddress(mask,0);
    }
    // Adresse de classe D ou E
    throw new UnknownHostException();
  }
  /**
   * Donne l'adresse de broadcast IP associee a la classe
   * d'une adresse Internet stockee dans quatre cases
   * d'un tableau d'octets.
   * @param address tableau d'octets contenant l'adresse Internet.
   * @param offset index du premier octet de l'adresse dans le tableau.
   * @return l'objet adresse Internet contenant l'adresse de 
   * broadcast.
   * @exception UnknownHostException si l'adresse est de classe
   * D ou E.
   */
  public static InetAddress getBroadcast(byte[] address, int offset)
    throws UnknownHostException {
    byte[] broadcast = new byte[4];
    broadcast[0]=address[offset];
    if((address[offset]&  0x80000000)==0) {
      // Adresse de classe A
      broadcast[1]=(byte)255;
      broadcast[2]=(byte)255;
      broadcast[3]=(byte)255;
      return byteToInetAddress(broadcast,0);
    }
    broadcast[1]=address[offset+1];
    if((address[offset]& 0x40)==0) {
      // Adresse de classe B
      broadcast[2]=(byte)255;
      broadcast[3]=(byte)255;
      return byteToInetAddress(broadcast,0);
    }
    if((address[offset] & 0x20)==0){
      // Adresse de classe C
      broadcast[2]=address[offset+2];
      broadcast[3]=(byte)255;
      return byteToInetAddress(broadcast,0);
    }
    // Adresse de classe D ou E
    throw new UnknownHostException();
  }

  /**
   * Construit l'adresse de broadcast IP deduite
   * de l'adresse Internet locale.
   * @return l'objet adresse Internet de broadcast.
   */
  public static InetAddress getLocalBroadcast()
    throws UnknownHostException{
    byte[] localAddress = InetAddress.getLocalHost().getAddress();
    return getBroadcast(localAddress,0);
  }
    
  /**
   * Transforme une adresse Internet stockee dans quatre
   * cases d'un tableau de byte en un objet adresse Internet.
   * @param address tableau d'octets contenant l'adresse Internet.
   * @param offset index du premier octet de l'adresse dans le tableau.
   * @return l'objet adresse Internet.
   */
  public static InetAddress byteToInetAddress(byte[] address, int offset)
    throws UnknownHostException{
    StringBuffer buffer = new StringBuffer(15);
    int tmp;
    for(int i=0;i<4;i++){
      // Recupere la valeur non signee de l'octet
      tmp = address[offset+i] & 0x7F;
      // Recupere le bit de signe qui, a cause de la
      // promotion entiere de l'octet, se trouve dans
      //l'octet de poids fort d'un entier
      if((address[offset+i]&80000000)!=0)
	tmp = tmp | 0x80;
      
      buffer.append(tmp);
      if(i!=3)
	buffer.append('.');
    }
    return InetAddress.getByName(buffer.toString());
  }
}