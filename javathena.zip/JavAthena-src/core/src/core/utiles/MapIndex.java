/*
 * MapIndex.java
 *
 * Created on 21 mai 2006, 12:24
 *
 * Copyright (c) 2006, Fran�ois Bradette
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of their contributors may be used to endorse or
 *       promote products derived from this software without specific prior
 *       written permission.
 *
 * This software is provided by the regents and contributors "as is" and any
 * express or implied warranties, including, but not limited to, the implied
 * warranties of merchantability and fitness for a particular purpose are
 * disclaimed.  In no event shall the regents and contributors be liable for any
 * direct, indirect, incidental, special, exemplary, or consequential damages
 * (including, but not limited to, procurement of substitute goods or services;
 * loss of use, data, or profits; or business interruption) however caused and
 * on any theory of liability, whether in contract, strict liability, or tort
 * (including negligence or otherwise) arising in any way out of the use of this
 * software, even if advised of the possibility of such damage.
 *
 * Translate from eAthena(c) by Fran�ois Bradette
 */


package core.utiles;

import java.io.File;
import java.io.IOException;
import java.util.StringTokenizer;
import javolution.util.FastMap;

/**
 *
 * @author Darksid_1
 */
class Map_name
{
    private int map_id;
    private String name;
    public Map_name(int id, String name)
    {
        map_id = id;
        this.name = name;
    }
    
    public int getMap_id()
    {
        return map_id;
    }
    
    public void setMap_id(int map_id)
    {
        this.map_id = map_id;
    }
    
    public String getName()
    {
        return name;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
}
public class MapIndex
{
    private static FastMap index_map_name_byName;
    private static FastMap index_map_name_byID;
    /** Creates a new instance of MapIndex */
    private MapIndex()
    {
    }
    public static void init()
    {
        boolean test = false;
        index_map_name_byName = new FastMap();
        index_map_name_byID = new FastMap();
        
        int last_index = -1;
        String maps = "";
        int index = 0;
        File mapIndexConf = new File(ConfigurationManagement.getMapIndex());
        
        if(mapIndexConf.exists())
        {
            try
            {
                maps = Functions.readConf(mapIndexConf);
            }
            catch (IOException ex)
            {
                Functions.showFatalError(MultilanguageManagement.getFatal_error_1(), ConfigurationManagement.getMapIndex());
                ex.printStackTrace();
                System.exit(1);
            }
            StringTokenizer mapsTK = new StringTokenizer(maps,"\n");
            while(mapsTK.hasMoreElements())
            {
                
                String map_name = mapsTK.nextElement().toString();
                if(!Character.isDigit(map_name.charAt(map_name.length()-1)))
                {
                    index = last_index + 1;
                }
                if(map_name.length() > Constants.MAP_NAME_LENGTH)
                {
                    Functions.showError(MultilanguageManagement.getError_19(), map_name,Constants.MAP_NAME_LENGTH);
                    continue;
                }
                if(!map_name.endsWith(".gat"))
                {
                    if(map_name.contains("."))
                    {
                        map_name = map_name.substring(0,map_name.indexOf('.')) + "gat";
                    }
                    else
                    {
                        map_name +=".gat";
                    }
                }
                if(map_name.length() > Constants.MAP_NAME_LENGTH)
                {
                    Functions.showError(MultilanguageManagement.getError_19(), map_name,Constants.MAP_NAME_LENGTH);
                    continue;
                }
                Map_name nMap_name = (Map_name) index_map_name_byID.get(index);
                if(nMap_name != null)
                {
                    Functions.showWarning(MultilanguageManagement.getWarning_47(), index, nMap_name.getName(), map_name);
                }
                nMap_name = new Map_name(index,map_name);
                index_map_name_byID.put(index,nMap_name);
                index_map_name_byName.put(map_name,nMap_name);
                last_index++;
            }
        }
        else
        {
            Functions.showFatalError(MultilanguageManagement.getFatal_error_1(), ConfigurationManagement.getMapIndex());
        }
           
    }
    public static Integer getMapId(String name)
    {
        return ((Map_name)index_map_name_byName.get(name)).getMap_id();
    }
    public static String getMapName(int id)
    {
        return ((Map_name)index_map_name_byID.get(id)).getName();
    }
}