/*
 * Multilanguage.java
 *
 * Created on 11 mai 2006, 20:54
 *
 * Copyright (c) 2006, Fran�ois Bradette
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of their contributors may be used to endorse or
 *       promote products derived from this software without specific prior
 *       written permission.
 *
 * This software is provided by the regents and contributors "as is" and any
 * express or implied warranties, including, but not limited to, the implied
 * warranties of merchantability and fitness for a particular purpose are
 * disclaimed.  In no event shall the regents and contributors be liable for any
 * direct, indirect, incidental, special, exemplary, or consequential damages
 * (including, but not limited to, procurement of substitute goods or services;
 * loss of use, data, or profits; or business interruption) however caused and
 * on any theory of liability, whether in contract, strict liability, or tort
 * (including negligence or otherwise) arising in any way out of the use of this
 * software, even if advised of the possibility of such damage.
 *
 * Translate from eAthena(c) by Fran�ois Bradette
 */


package core.utiles;

import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 *
 * @author Darksid_1
 */
public class MultilanguageManagement
{
    private static String warning;
    private static String error;
    private static String notice;
    private static String info;
    private static String status;
    private static String fatalError;
    
    private static String warning_1;
    private static String warning_2;
    private static String warning_3;
    private static String warning_4;
    private static String warning_5;
    private static String warning_6;
    private static String warning_7;
    private static String warning_8;
    private static String warning_9;
    private static String warning_10;
    private static String warning_11;
    private static String warning_12;
    private static String warning_13;
    private static String warning_14;
    private static String warning_15;
    private static String warning_16;
    private static String warning_17;
    private static String warning_18;
    private static String warning_19;
    private static String warning_20;
    private static String warning_21;
    private static String warning_22;
    private static String warning_23;
    private static String warning_24;
    private static String warning_25;
    private static String warning_26;
    private static String warning_27;
    private static String warning_28;
    private static String warning_29;
    private static String warning_30;
    private static String warning_31;
    private static String warning_32;
    private static String warning_33;
    private static String warning_34;
    private static String warning_35;
    private static String warning_36;
    private static String warning_37;
    private static String warning_38;
    private static String warning_39;
    private static String warning_40;
    private static String warning_41;
    private static String warning_42;
    private static String warning_43;
    private static String warning_44;
    private static String warning_45;
    private static String warning_46;
    private static String warning_47;
    private static String warning_48;
    private static String warning_49;
    private static String warning_50;
    
    private static String fatal_error_1;
    
    private static String error_1;
    private static String error_2;
    private static String error_3;
    private static String error_4;
    private static String error_5;
    private static String error_6;
    private static String error_7;
    private static String error_8;
    private static String error_9;
    private static String error_10;
    private static String error_11;
    private static String error_12;
    private static String error_13;
    private static String error_14;
    private static String error_15;
    private static String error_16;
    private static String error_17;
    private static String error_18;
    private static String error_19;
    private static String error_20;
    private static String error_21;
    private static String error_22;
    private static String error_23;
    private static String error_24;
    
    private static String notice_1;
    private static String notice_2;
    private static String notice_3;
    private static String notice_4;
    private static String notice_5;
    private static String notice_6;
    private static String notice_7;
    private static String notice_8;
    private static String notice_9;
    private static String notice_10;
    private static String notice_11;
    private static String notice_12;
    private static String notice_13;
    private static String notice_14;
    private static String notice_15;
    private static String notice_16;
    private static String notice_17;
    private static String notice_18;
    private static String notice_19;
    
    private static String info_1;
    private static String info_2;
    private static String info_3;
    private static String info_4;
    private static String info_5;
    private static String info_6;
    
    private static String login_log_1;
    private static String login_log_2;
    private static String login_log_3;
    private static String login_log_4;
    private static String login_log_5;
    private static String login_log_6;
    private static String login_log_7;
    private static String login_log_8;
    private static String login_log_9;
    private static String login_log_10;
    private static String login_log_11;
    private static String login_log_12;
    private static String login_log_13;
    private static String login_log_14;
    private static String login_log_15;
    private static String login_log_16;
    private static String login_log_17;
    private static String login_log_18;
    private static String login_log_19;
    private static String login_log_20;
    private static String login_log_21;
    private static String login_log_22;
    private static String login_log_23;
    private static String login_log_24;
    private static String login_log_25;
    private static String login_log_26;
    private static String login_log_27;
    private static String login_log_28;
    private static String login_log_29;
    private static String login_log_30;
    private static String login_log_31;
    private static String login_log_32;
    private static String login_log_33;
    private static String login_log_34;
    private static String login_log_35;
    private static String login_log_36;
    private static String login_log_37;
    private static String login_log_38;
    private static String login_log_39;
    private static String login_log_40;
    private static String login_log_41;
    private static String login_log_42;
    private static String login_log_43;
    private static String login_log_44;
    private static String login_log_45;
    private static String login_log_46;
    private static String login_log_47;
    private static String login_log_48;
    
    private static String status_1;
    private static String status_2;
    private static String status_3;
    private static String status_4;
    private static String status_5;
    private static String status_6;
    
    private static String char_log_1;
    private static String char_log_2;

    private static String error_25;
    
    public static void init()
    {
        //use the user lang file if the ResourceBundle exist else we use the default Locale
        init(Constants.LANG);
    }
    
    public static void init(String lang)
    {
        ResourceBundle langBundle;
        try
        {
            langBundle = ResourceBundle.getBundle("core/lang/Login_" + lang);
        }
        catch(MissingResourceException ex)
        {
            langBundle = ResourceBundle.getBundle("core/lang/Login");
        }
        warning = langBundle.getString("warning");
        error = langBundle.getString("error");
        notice = langBundle.getString("notice");
        info = langBundle.getString("info");
        status = langBundle.getString("status");
        fatalError = langBundle.getString("fatal_error");
        
        error_1 = langBundle.getString("error_1");
        error_2 = langBundle.getString("error_2");
        error_3 = langBundle.getString("error_3");
        error_4 = langBundle.getString("error_4");
        error_5 = langBundle.getString("error_5");
        error_6 = langBundle.getString("error_6");
        error_7 = langBundle.getString("error_7");
        error_8 = langBundle.getString("error_8");
        error_9 = langBundle.getString("error_9");
        error_10 = langBundle.getString("error_10");
        error_11 = langBundle.getString("error_11");
        error_12 = langBundle.getString("error_12");
        error_13 = langBundle.getString("error_13");
        error_14 = langBundle.getString("error_14");
        error_15 = langBundle.getString("error_15");
        error_16 = langBundle.getString("error_16");
        error_17 = langBundle.getString("error_17");
        error_18 = langBundle.getString("error_18");
        error_19 = langBundle.getString("error_19");
        error_20 = langBundle.getString("error_20");
        error_21 = langBundle.getString("error_21");
        error_22 = langBundle.getString("error_22");
        error_23 = langBundle.getString("error_23");
        error_24 = langBundle.getString("error_24");
        error_25 = langBundle.getString("error_25");
        
        fatal_error_1 = langBundle.getString("fatal_error_1");
        
        notice_1 = langBundle.getString("notice_1");
        notice_2 = langBundle.getString("notice_2");
        notice_3 = langBundle.getString("notice_3");
        notice_4 = langBundle.getString("notice_4");
        notice_5 = langBundle.getString("notice_5");
        notice_6 = langBundle.getString("notice_6");
        notice_7 = langBundle.getString("notice_7");
        notice_8 = langBundle.getString("notice_8");
        notice_9 = langBundle.getString("notice_9");
        notice_10 = langBundle.getString("notice_10");
        notice_11 = langBundle.getString("notice_11");
        notice_12 = langBundle.getString("notice_12");
        notice_13 = langBundle.getString("notice_13");
        notice_14 = langBundle.getString("notice_14");
        notice_15 = langBundle.getString("notice_15");
        notice_16 = langBundle.getString("notice_16");
        notice_17 = langBundle.getString("notice_17");
        notice_18 = langBundle.getString("notice_18");
        notice_19 = langBundle.getString("notice_19");
        
        warning_1 = langBundle.getString("warning_1");
        warning_2 = langBundle.getString("warning_2");
        warning_3 = langBundle.getString("warning_3");
        warning_4 = langBundle.getString("warning_4");
        warning_5 = langBundle.getString("warning_5");
        warning_6 = langBundle.getString("warning_6");
        warning_7 = langBundle.getString("warning_7");
        warning_8 = langBundle.getString("warning_8");
        warning_9 = langBundle.getString("warning_9");
        warning_10 = langBundle.getString("warning_10");
        warning_11 = langBundle.getString("warning_11");
        warning_12 = langBundle.getString("warning_12");
        warning_13 = langBundle.getString("warning_13");
        warning_14 = langBundle.getString("warning_14");
        warning_15 = langBundle.getString("warning_15");
        warning_16 = langBundle.getString("warning_16");
        warning_17 = langBundle.getString("warning_17");
        warning_18 = langBundle.getString("warning_18");
        warning_19 = langBundle.getString("warning_19");
        warning_20 = langBundle.getString("warning_20");
        warning_21 = langBundle.getString("warning_21");
        warning_22 = langBundle.getString("warning_22");
        warning_23 = langBundle.getString("warning_23");
        warning_24 = langBundle.getString("warning_24");
        warning_25 = langBundle.getString("warning_25");
        warning_26 = langBundle.getString("warning_26");
        warning_27 = langBundle.getString("warning_27");
        warning_28 = langBundle.getString("warning_28");
        warning_29 = langBundle.getString("warning_29");
        warning_30 = langBundle.getString("warning_30");
        warning_31 = langBundle.getString("warning_31");
        warning_32 = langBundle.getString("warning_32");
        warning_33 = langBundle.getString("warning_33");
        warning_34 = langBundle.getString("warning_34");
        warning_35 = langBundle.getString("warning_35");
        warning_36 = langBundle.getString("warning_36");
        warning_37 = langBundle.getString("warning_37");
        warning_38 = langBundle.getString("warning_38");
        warning_39 = langBundle.getString("warning_39");
        warning_40 = langBundle.getString("warning_40");
        warning_41 = langBundle.getString("warning_41");
        warning_42 = langBundle.getString("warning_42");
        warning_43 = langBundle.getString("warning_43");
        warning_44 = langBundle.getString("warning_44");
        warning_45 = langBundle.getString("warning_45");
        warning_46 = langBundle.getString("warning_46");
        warning_47 = langBundle.getString("warning_47");
        warning_48 = langBundle.getString("warning_48");
        warning_49 = langBundle.getString("warning_49");
        warning_50 = langBundle.getString("warning_50");
        
        info_1 = langBundle.getString("info_1");
        info_2 = langBundle.getString("info_2");
        info_3 = langBundle.getString("info_3");
        info_4 = langBundle.getString("info_4");
        info_5 = langBundle.getString("info_5");
        info_6 = langBundle.getString("info_6");
        
        login_log_1 = langBundle.getString("login_log_1");
        login_log_2 = langBundle.getString("login_log_2");
        login_log_3 = langBundle.getString("login_log_3");
        login_log_4 = langBundle.getString("login_log_4");
        login_log_5 = langBundle.getString("login_log_5");
        login_log_6 = langBundle.getString("login_log_6");
        login_log_7 = langBundle.getString("login_log_7");
        login_log_8 = langBundle.getString("login_log_8");
        login_log_9 = langBundle.getString("login_log_9");
        login_log_10 = langBundle.getString("login_log_10");
        login_log_11 = langBundle.getString("login_log_11");
        login_log_12 = langBundle.getString("login_log_12");
        login_log_13 = langBundle.getString("login_log_13");
        login_log_14 = langBundle.getString("login_log_14");
        login_log_15 = langBundle.getString("login_log_15");
        login_log_16 = langBundle.getString("login_log_16");
        login_log_17 = langBundle.getString("login_log_17");
        login_log_18 = langBundle.getString("login_log_18");
        login_log_19 = langBundle.getString("login_log_19");
        login_log_20 = langBundle.getString("login_log_20");
        login_log_21 = langBundle.getString("login_log_21");
        login_log_22 = langBundle.getString("login_log_22");
        login_log_23 = langBundle.getString("login_log_23");
        login_log_24 = langBundle.getString("login_log_24");
        login_log_25 = langBundle.getString("login_log_25");
        login_log_26 = langBundle.getString("login_log_26");
        login_log_27 = langBundle.getString("login_log_27");
        login_log_28 = langBundle.getString("login_log_28");
        login_log_29 = langBundle.getString("login_log_29");
        login_log_30 = langBundle.getString("login_log_30");
        login_log_31 = langBundle.getString("login_log_31");
        login_log_32 = langBundle.getString("login_log_32");
        login_log_33 = langBundle.getString("login_log_33");
        login_log_34 = langBundle.getString("login_log_34");
        login_log_35 = langBundle.getString("login_log_35");
        login_log_36 = langBundle.getString("login_log_36");
        login_log_37 = langBundle.getString("login_log_37");
        login_log_38 = langBundle.getString("login_log_38");
        login_log_39 = langBundle.getString("login_log_39");
        login_log_40 = langBundle.getString("login_log_40");
        login_log_41 = langBundle.getString("login_log_41");
        login_log_42 = langBundle.getString("login_log_42");
        login_log_43 = langBundle.getString("login_log_43");
        login_log_44 = langBundle.getString("login_log_44");
        login_log_45 = langBundle.getString("login_log_45");
        login_log_46 = langBundle.getString("login_log_46");
        login_log_47 = langBundle.getString("login_log_47");
        login_log_48 = langBundle.getString("login_log_48");
        
        status_1 = langBundle.getString("status_1");
        status_2 = langBundle.getString("status_2");
        status_3 = langBundle.getString("status_3");
        status_4 = langBundle.getString("status_4");
        status_5 = langBundle.getString("status_5");
        status_6 = langBundle.getString("status_6");
        
        char_log_1 = langBundle.getString("char_log_1");
        char_log_2 = langBundle.getString("char_log_2");
        
    }
    
    public static String getError_1()
    {
        return error_1;
    }
    
    public static String getError_2()
    {
        return error_2;
    }
    
    public static String getError_3()
    {
        return error_3;
    }
    
    public static String getError_4()
    {
        return error_4;
    }
    
    public static String getError_5()
    {
        return error_5;
    }
    
    public static String getNotice_1()
    {
        return notice_1;
    }
    
    public static String getNotice_2()
    {
        return notice_2;
    }
    
    public static String getNotice_3()
    {
        return notice_3;
    }
    
    public static String getNotice_4()
    {
        return notice_4;
    }
    
    public static String getNotice_5()
    {
        return notice_5;
    }
    
    public static String getNotice_6()
    {
        return notice_6;
    }
    
    public static String getNotice_7()
    {
        return notice_7;
    }
    
    public static String getNotice_8()
    {
        return notice_8;
    }
    
    public static String getNotice_9()
    {
        return notice_9;
    }
    
    public static String getNotice_10()
    {
        return notice_10;
    }
    
    public static String getNotice_11()
    {
        return notice_11;
    }
    
    public static String getNotice_12()
    {
        return notice_12;
    }
    
    public static String getNotice_13()
    {
        return notice_13;
    }
    
    public static String getInfo_1()
    {
        return info_1;
    }
    
    public static String getWarning()
    {
        return warning;
    }
    
    public static String getWarning_1()
    {
        return warning_1;
    }
    
    public static String getError()
    {
        return error;
    }
    
    public static String getNotice()
    {
        return notice;
    }
    
    public static String getInfo()
    {
        return info;
    }
    
    public static String getStatus()
    {
        return status;
    }
    
    public static String getFatalError()
    {
        return fatalError;
    }
    
    public static String getWarning_2()
    {
        return warning_2;
    }
    
    public static String getWarning_3()
    {
        return warning_3;
    }
    
    public static String getWarning_4()
    {
        return warning_4;
    }
    
    public static String getWarning_5()
    {
        return warning_5;
    }
    
    public static String getWarning_6()
    {
        return warning_6;
    }
    
    public static String getWarning_7()
    {
        return warning_7;
    }
    
    public static String getWarning_8()
    {
        return warning_8;
    }
    
    public static String getWarning_9()
    {
        return warning_9;
    }
    
    public static String getWarning_10()
    {
        return warning_10;
    }
    
    public static String getWarning_11()
    {
        return warning_11;
    }
    
    public static String getWarning_12()
    {
        return warning_12;
    }
    
    public static String getWarning_13()
    {
        return warning_13;
    }
    
    public static String getWarning_14()
    {
        return warning_14;
    }
    
    public static String getWarning_15()
    {
        return warning_15;
    }
    
    public static String getWarning_16()
    {
        return warning_16;
    }
    
    public static String getWarning_17()
    {
        return warning_17;
    }
    
    public static String getWarning_18()
    {
        return warning_18;
    }
    
    public static String getWarning_19()
    {
        return warning_19;
    }
    
    public static String getWarning_20()
    {
        return warning_20;
    }
    
    public static String getWarning_21()
    {
        return warning_21;
    }
    
    public static String getWarning_22()
    {
        return warning_22;
    }
    
    public static String getWarning_23()
    {
        return warning_23;
    }
    
    public static String getWarning_24()
    {
        return warning_24;
    }
    
    public static String getWarning_25()
    {
        return warning_25;
    }
    
    public static String getWarning_26()
    {
        return warning_26;
    }
    
    public static String getWarning_27()
    {
        return warning_27;
    }
    
    public static String getWarning_28()
    {
        return warning_28;
    }
    
    public static String getWarning_29()
    {
        return warning_29;
    }
    
    public static String getWarning_30()
    {
        return warning_30;
    }
    
    public static String getWarning_31()
    {
        return warning_31;
    }
    
    public static String getWarning_32()
    {
        return warning_32;
    }
    
    public static String getWarning_33()
    {
        return warning_33;
    }
    
    public static String getWarning_34()
    {
        return warning_34;
    }
    
    public static String getWarning_35()
    {
        return warning_35;
    }
    
    public static String getWarning_36()
    {
        return warning_36;
    }
    
    public static String getWarning_37()
    {
        return warning_37;
    }
    
    public static String getWarning_38()
    {
        return warning_38;
    }
    
    public static String getWarning_39()
    {
        return warning_39;
    }
    
    public static String getInfo_2()
    {
        return info_2;
    }
    
    public static String getInfo_3()
    {
        return info_3;
    }
    
    public static String getInfo_4()
    {
        return info_4;
    }
    
    public static String getInfo_5()
    {
        return info_5;
    }
    
    public static String getLogin_log_1()
    {
        return login_log_1;
    }
    
    public static String getLogin_log_2()
    {
        return login_log_2;
    }
    
    public static String getLogin_log_3()
    {
        return login_log_3;
    }
    
    public static String getLogin_log_4()
    {
        return login_log_4;
    }
    
    public static String getLogin_log_5()
    {
        return login_log_5;
    }
    
    public static String getLogin_log_6()
    {
        return login_log_6;
    }
    
    public static String getLogin_log_7()
    {
        return login_log_7;
    }
    
    public static String getLogin_log_8()
    {
        return login_log_8;
    }
    
    public static String getLogin_log_9()
    {
        return login_log_9;
    }
    
    public static String getLogin_log_10()
    {
        return login_log_10;
    }
    
    public static String getLogin_log_11()
    {
        return login_log_11;
    }
    
    public static String getLogin_log_12()
    {
        return login_log_12;
    }
    
    public static String getLogin_log_13()
    {
        return login_log_13;
    }
    
    public static String getLogin_log_14()
    {
        return login_log_14;
    }
    
    public static String getLogin_log_15()
    {
        return login_log_15;
    }
    
    public static String getLogin_log_16()
    {
        return login_log_16;
    }
    
    public static String getLogin_log_17()
    {
        return login_log_17;
    }
    
    public static String getLogin_log_18()
    {
        return login_log_18;
    }
    
    public static String getLogin_log_19()
    {
        return login_log_19;
    }
    
    public static String getLogin_log_20()
    {
        return login_log_20;
    }
    
    public static String getLogin_log_21()
    {
        return login_log_21;
    }
    
    public static String getLogin_log_22()
    {
        return login_log_22;
    }
    
    public static String getLogin_log_23()
    {
        return login_log_23;
    }
    
    public static String getLogin_log_24()
    {
        return login_log_24;
    }
    
    public static String getLogin_log_25()
    {
        return login_log_25;
    }
    
    public static String getLogin_log_26()
    {
        return login_log_26;
    }
    
    public static String getLogin_log_27()
    {
        return login_log_27;
    }
    
    public static String getLogin_log_28()
    {
        return login_log_28;
    }
    
    public static String getLogin_log_29()
    {
        return login_log_29;
    }
    
    public static String getLogin_log_30()
    {
        return login_log_30;
    }
    
    public static String getLogin_log_31()
    {
        return login_log_31;
    }
    
    public static String getLogin_log_32()
    {
        return login_log_32;
    }
    
    public static String getLogin_log_33()
    {
        return login_log_33;
    }
    
    public static String getLogin_log_34()
    {
        return login_log_34;
    }
    
    public static String getLogin_log_35()
    {
        return login_log_35;
    }
    
    public static String getLogin_log_36()
    {
        return login_log_36;
    }
    
    public static String getLogin_log_37()
    {
        return login_log_37;
    }
    
    public static String getLogin_log_38()
    {
        return login_log_38;
    }
    
    public static String getLogin_log_39()
    {
        return login_log_39;
    }
    
    public static String getLogin_log_40()
    {
        return login_log_40;
    }
    
    public static String getLogin_log_41()
    {
        return login_log_41;
    }
    
    public static String getLogin_log_42()
    {
        return login_log_42;
    }
    
    public static String getLogin_log_43()
    {
        return login_log_43;
    }
    
    public static String getLogin_log_44()
    {
        return login_log_44;
    }
    
    public static String getLogin_log_45()
    {
        return login_log_45;
    }
    
    public static String getLogin_log_46()
    {
        return login_log_46;
    }
    
    public static String getLogin_log_47()
    {
        return login_log_47;
    }
    
    public static String getLogin_log_48()
    {
        return login_log_48;
    }
    
    public static String getError_6()
    {
        return error_6;
    }
    
    public static String getError_7()
    {
        return error_7;
    }
    
    public static String getError_8()
    {
        return error_8;
    }
    
    public static String getError_9()
    {
        return error_9;
    }
    
    public static String getError_10()
    {
        return error_10;
    }
    
    public static String getError_11()
    {
        return error_11;
    }
    
    public static String getError_12()
    {
        return error_12;
    }
    
    public static String getError_13()
    {
        return error_13;
    }
    
    public static String getError_14()
    {
        return error_14;
    }
    
    public static String getError_15()
    {
        return error_15;
    }
    
    public static String getError_16()
    {
        return error_16;
    }
    
    public static String getError_17()
    {
        return error_17;
    }
    
    public static String getNotice_14()
    {
        return notice_14;
    }
    
    public static String getNotice_15()
    {
        return notice_15;
    }
    
    public static String getNotice_16()
    {
        return notice_16;
    }
    
    public static String getNotice_17()
    {
        return notice_17;
    }
    
    public static String getNotice_18()
    {
        return notice_18;
    }
    
    public static String getWarning_40()
    {
        return warning_40;
    }
    
    public static String getWarning_41()
    {
        return warning_41;
    }
    
    public static String getWarning_42()
    {
        return warning_42;
    }
    
    public static String getWarning_43()
    {
        return warning_43;
    }
    
    public static String getWarning_44()
    {
        return warning_44;
    }
    
    public static String getWarning_45()
    {
        return warning_45;
    }
    
    public static String getWarning_46()
    {
        return warning_46;
    }
    
    
    public static String getFatal_error_1()
    {
        return fatal_error_1;
    }
    
    public static String getError_18()
    {
        return error_18;
    }
    
    public static String getError_19()
    {
        return error_19;
    }
    
    public static String getWarning_47()
    {
        return warning_47;
    }
    
    public static String getInfo_6()
    {
        return info_6;
    }
    
    public static String getStatus_1()
    {
        return status_1;
    }
    
    public static String getStatus_2()
    {
        return status_2;
    }
    
    public static String getStatus_3()
    {
        return status_3;
    }
    
    public static String getStatus_4()
    {
        return status_4;
    }
    
    public static String getError_20()
    {
        return error_20;
    }
    
    public static String getWarning_48()
    {
        return warning_48;
    }

    public static String getError_21()
    {
        return error_21;
    }

    public static String getError_22()
    {
        return error_22;
    }

    public static String getNotice_19()
    {
        return notice_19;
    }

    public static String getChar_log_1()
    {
        return char_log_1;
    }

    public static String getStatus_5()
    {
        return status_5;
    }

    public static String getStatus_6()
    {
        return status_6;
    }

    public static String getWarning_49()
    {
        return warning_49;
    }

    public static String getError_23()
    {
        return error_23;
    }

    public static String getChar_log_2()
    {
        return char_log_2;
    }

    public static String getError_24()
    {
        return error_24;
    }

    public static String getError_25()
    {
        return error_25;
    }

    public static String getWarning_50()
    {
        return warning_50;
    }
}
