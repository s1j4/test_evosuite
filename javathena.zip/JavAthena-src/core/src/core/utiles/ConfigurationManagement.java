/*
 * ConfigurationManagement.java
 *
 * Created on 5 avril 2006, 19:57
 *
 * Translate from Eathena(c) by darksid_1@htomail.com
 */
package core.utiles;

import core.data.Point;
import core.data.SubNetConf;
import core.utiles.ACO;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.util.StringTokenizer;

import core.utiles.Functions;
import core.utiles.MultilanguageManagement;
import javolution.util.FastTable;
//import javathena.login.*;

/**
 *
 * @author Darksid_1
 */
public class ConfigurationManagement
{
    
    private static String date_format;
    private static String order;
    private static int server_num;
    private static int new_account_flag;
    private static String bind_ip_str;//[16];
    private static String bind_ip;
    private static String lan_char_ip;//[16];
    private static int subneti[];//[4];
    private static int subnetmaski[];//[4];
    private static int use_MD5_passwords;
    private static String account_filename;
    private static  String GM_account_filename;
    private static  String login_log_filename;
    private static int auth_before_save_file = 0; // Counter. First save when 1st char-server do connection.
    
    private static int admin_state = 0;
    private static String admin_pass;//[24] = "";
    private static String gm_pass;//[64] = "";
    private static int level_new_gm = 60;
    
    private static boolean console = false;
    private static int login_port;
    private static boolean dynamic_pass_failure_ban = true;
    private static int dynamic_pass_failure_ban_time = 5;
    private static int dynamic_pass_failure_ban_how_many = 3;
    private static int dynamic_pass_failure_ban_how_long = 1;
    private static  String login_log_unknown_packets_filename;
    //char date_format[32] = "%Y-%m-%d %H:%M:%S";
    private static  int save_unknown_packets;
    private static  long creation_time_GM_account_file;
    private static  int gm_account_filename_check_timer;
    
    private static  boolean log_login;
    
    private static  boolean display_parse_login; // 0: no, 1: yes
    private static  boolean display_parse_admin; // 0: no, 1: yes
    private static  int display_parse_fromchar; // 0: no, 1: yes (without packet 0x2714), 2: all packets
    
    //private static int login_fd;
    
    //Account flood protection [Kevin]
    private static  long new_reg_tick;
    private static  int allowed_regs;
    private static  long num_regs;
    private static  int time_allowed; //Init this to 10 seconds. [Skotlex]
    
    private static  ACO access_order;
    private static  int access_allownum;
    private static  int access_denynum;
    private static  String access_allow;
    private static  String access_deny;
    
    
    private static  int access_ladmin_allownum;
    private static  String access_ladmin_allow;
    
    private static  int min_level_to_connect; // minimum level of player/GM (0: player, 1-99: gm) to connect on the server
    private static  int add_to_unlimited_account; // Give possibility or not to adjust (ladmin command: timeadd) the time of an unlimited account.
    private static  int start_limited_time; // Starting additional sec from now for the limited time at creation of accounts (-1: unlimited time, 0 or more: additional sec from now)
    private static  int check_ip_flag; // It's to check IP of a player between login-server and char-server (part of anti-hacking system)
    
    private static boolean check_client_version; //Client version check ON/OFF .. (sirius)
    private static int client_version_to_connect; //Client version needed to connect ..(sirius)
    private static long startLimitedTime;
    private static int GMMax;
    private static String lan_map_ip;
    
    private static boolean online_check;
    
    private static boolean use_dnsbl;
    
    private static boolean ipban = true;
    
    private static boolean use_md5_passwds;
    private static int gmLevel = Constants.DEFAULT_GM_LEVEL;
    
    private static String mapIndexPath = "db/map_index.txt";
    
    private static String timestamp_format;
    
    private static boolean console_silent;
    
    private static String charPassword;
    private static String server_name;
    private static String charUserid;
    private static String wisp_server_name;
    
    private static String login_ip_str;
    private static String char_ip_str;
    
    private static boolean login_ip_set_;
    private static boolean char_ip_set_;
    private static boolean bind_ip_set_;
    
    private static int char_port;
    private static int char_maintenance;
    private static int char_new;
    private static int char_new_display;
    private static int email_creation;
    
    private static String char_txt;
    
    private static String scdata_txt;
    
    private static String backup_txt;
    
    private static String friends_txt;
    
    private static String backup_txt_flag;
    private static String max_connect_user;
    private static int gm_allow_level;
    private static int autosave_time;
    private static int autosave_interval;
    
    private static int save_log;
    
    private static Point start_point;
    
    private static boolean log_char;
    
    
    
    private static int start_zeny;
    private static int start_weapon;
    private static int start_armor;
    private static String unknown_char_name;
    private static String char_log_filename;
    private static int name_ignoring_case;
    private static int char_name_option;
    private static String char_name_letters;
    private static String online_txt_filename;
    private static String online_html_filename;
    private static int online_sorting_option;
    private static int online_display_option;
    private static int online_gm_display_min_level;
    private static int online_refresh_html;
    private static String db_path;
    private static int fame_list_size_alchemist;
    private static int fame_list_size_blacksmith;
    private static int fame_list_size_taekwon;
    
    private static FastTable subNetConfs;
    
    private static int char_id_count;
    static
    {
        subNetConfs = new FastTable();
        login_port = Constants.DEFAULT_LOGIN_PORT;
        startLimitedTime = -1;
        GMMax = 30;
    }
    /** Creates a new instance of ConfigurationManagement */
    private ConfigurationManagement()
    {
    }
    
//----------------------------------
// Reading Lan Support configuration
// Rewrote: Anvanced subnet check [LuzZza]
// Rerewrote: java translate [Darksid_1]
//----------------------------------
    public static int char_lan_config_read(String cfgName)
    {
        File cfgFile = new File(cfgName);
        if(!cfgFile.exists())
        {
            Functions.showWarning(String.format(MultilanguageManagement.getWarning_1(),cfgName));
            return 1;
        }
        Functions.showInfo(String.format(MultilanguageManagement.getInfo_2(),cfgName));
        try
        {
            StringTokenizer lanConf = new StringTokenizer(Functions.readConf(cfgFile),"\n");
            while(lanConf.hasMoreElements())
            {
                StringTokenizer lineConf = new StringTokenizer(lanConf.nextElement().toString(),":");
                SubNetConf tmp = new SubNetConf();
                if(lanConf.hasMoreElements() && lanConf.nextElement().equals("subnet"))
                {
                    
                    String mask = lanConf.nextElement().toString();
                    String charIP = lanConf.nextElement().toString();
                    String mapIP = lanConf.nextElement().toString();
                    
                    
                    tmp.setMask(Long.parseLong(mask.replaceAll(".","")));
                    tmp.setChar_ip(Long.parseLong(charIP.toString().replaceAll(".","")));
                    tmp.setMap_ip(Long.parseLong(lanConf.nextElement().toString().replaceAll(".","")));
                    tmp.setSubnet(tmp.getChar_ip()&tmp.getMask());
                    if(tmp.getSubnet() != (tmp.getMap_ip()&tmp.getMask()))
                    {
                        Functions.showError(MultilanguageManagement.getError_21(), cfgName, charIP, mapIP);
                        continue;
                    }
                }
                subNetConfs.add(tmp);
            }
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }
        return 0;
    }
    
    
    public static int char_config_read(String cfgName)
    {
        File conf = new File(cfgName);
        String charConf = "";
        if(!conf.exists())
            Functions.showFatalError(MultilanguageManagement.getWarning_2(),cfgName);
        
        Functions.showInfo(MultilanguageManagement.getInfo_2(),cfgName);
        try
        {
            char_id_count = Constants.START_CHAR_NUM;
            charConf = Functions.readConf(conf);
            if(charConf.contains("timestamp_format"))
                timestamp_format = Functions.getValueFromConfigString(charConf,"timestamp_format");
            
            if(charConf.contains("console_silent"))
                console_silent = Integer.parseInt(Functions.getValueFromConfigString(charConf,"console_silent")) == 1;
            Functions.showInfo(MultilanguageManagement.getInfo_6(), console_silent);
            
            if(charConf.contains("userid"))
                charUserid = Functions.getValueFromConfigString(charConf,"userid");
            
            if(charConf.contains("passwd"))
                charPassword = Functions.getValueFromConfigString(charConf,"passwd");
            
            if(charConf.contains("server_name"))
            {
                server_name = Functions.getValueFromConfigString(charConf,"server_name");
                Functions.showStatus(MultilanguageManagement.getStatus_1(), server_name);
            }
            
            if(charConf.contains("wisp_server_name"))
                wisp_server_name = Functions.getValueFromConfigString(charConf,"wisp_server_name");
            
            if(charConf.contains("login_ip"))
            {
                login_ip_set_ = true;
                String login_ip = Functions.getValueFromConfigString(charConf,"login_ip");
                byte[] tabIp = InetAddress.getByName(login_ip).getAddress();
                login_ip_str = String.format("%d.%d.%d.%d",tabIp[0],tabIp[1],tabIp[2],tabIp[3]);
                Functions.showStatus(MultilanguageManagement.getStatus_2(),login_ip,tabIp[0],tabIp[1],tabIp[2],tabIp[3]);
            }
            
            if(charConf.contains("login_port"))
                login_port = Integer.parseInt(Functions.getValueFromConfigString(charConf,"login_port"));
            
            if(charConf.contains("char_ip"))
            {
                char_ip_set_ =true;
                String char_ip = Functions.getValueFromConfigString(charConf,"char_ip");
                byte[] tabIp = InetAddress.getByName(char_ip).getAddress();
                char_ip_str = String.format("%d.%d.%d.%d",tabIp[0],tabIp[1],tabIp[2],tabIp[3]);
                Functions.showStatus(MultilanguageManagement.getStatus_3(),char_ip,char_ip_str);
            }
            if(charConf.contains("bind_ip"))
            {
                bind_ip_set_ = true;
                String bind_ip = Functions.getValueFromConfigString(charConf,"bind_ip");
                byte[] tabIp = InetAddress.getByName(bind_ip).getAddress();
                bind_ip_str = String.format("%d.%d.%d.%d",tabIp[0],tabIp[1],tabIp[2],tabIp[3]);
                Functions.showStatus(MultilanguageManagement.getStatus_4(),bind_ip,tabIp[0],tabIp[1],tabIp[2],tabIp[3]);
            }
            
            if(charConf.contains("char_port"))
                char_port = Integer.parseInt(Functions.getValueFromConfigString(charConf,"char_port"));
            
            if(charConf.contains("char_maintenance"))
                char_maintenance = Integer.parseInt(Functions.getValueFromConfigString(charConf,"char_maintenance"));
            
            if(charConf.contains("char_new"))
                char_new = Integer.parseInt(Functions.getValueFromConfigString(charConf,"char_new"));
            
            if(charConf.contains("char_new_display"))
                char_new_display = Integer.parseInt(Functions.getValueFromConfigString(charConf,"char_new_display"));
            
            if(charConf.contains("email_creation"))
                email_creation = config_switch(Functions.getValueFromConfigString(charConf,"email_creation"));
            
            if(charConf.contains("char_txt"))
                char_txt = Functions.getValueFromConfigString(charConf,"char_txt");
            
            if(charConf.contains("scdata_txt"))
                scdata_txt = Functions.getValueFromConfigString(charConf,"scdata_txt");
            
           /* if(charConf.contains("backup_txt"))
                backup_txt = Functions.getValueFromConfigString(charConf,"backup_txt");
            */
            if(charConf.contains("friends_txt"))
                friends_txt = Functions.getValueFromConfigString(charConf,"friends_txt");
            
//The backup_txt file was created because char deletion bug existed.
//Now it's finish and that take a lot of time to create a second file when there are a lot of characters. By [Yor]
 /*  ___
  * {o,o}
  * |)__)
  * -"-"-
  * O RLY?
  if(charConf.contains("backup_txt_flag"))
               backup_txt_flag = Functions.getValueFromConfigString(charConf,"backup_txt_flag");*/
            
            
            if(charConf.contains("max_connect_user"))
                max_connect_user = Functions.getValueFromConfigString(charConf,"max_connect_user");
            
            if(charConf.contains("gm_allow_level"))
                gm_allow_level = Integer.parseInt(Functions.getValueFromConfigString(charConf,"gm_allow_level"));
            
            
            if(charConf.contains("check_ip_flag"))
                check_ip_flag = config_switch(Functions.getValueFromConfigString(charConf,"check_ip_flag"));
            
            if(charConf.contains("online_check"))
                online_check = config_switch(Functions.getValueFromConfigString(charConf,"online_check")) == 1;
            
            
            if(charConf.contains("autosave_time"))
            {
                autosave_time = Integer.parseInt(Functions.getValueFromConfigString(charConf,"autosave_time")) * 1000;
                
                if (autosave_interval <= 0)
                    autosave_interval = Constants.DEFAULT_AUTOSAVE_INTERVAL;
                
            }
            
            if(charConf.contains("save_log"))
                save_log = config_switch(Functions.getValueFromConfigString(charConf,"save_log"));
            
            start_point = new Point();
            if(charConf.contains("start_point"))
            {
                StringTokenizer start_pointBeforeParsing  = new StringTokenizer(Functions.getValueFromConfigString(charConf,"start_point")," ,");
                Integer mapId = MapIndex.getMapId(start_pointBeforeParsing.nextElement().toString());
                if(mapId == null)
                {
                    Functions.showError(MultilanguageManagement.getError_20(), mapId);
                    start_point.setMap(0);
                }
                else
                {
                    start_point.setMap(mapId);
                }
                start_point.setX(Integer.parseInt(start_pointBeforeParsing.nextElement().toString()));
                start_point.setY(Integer.parseInt(start_pointBeforeParsing.nextElement().toString()));
                
            }
            if(charConf.contains("log_char"))
                log_char = Integer.parseInt(Functions.getValueFromConfigString(charConf,"log_char")) == 1;
            
            if(charConf.contains("start_zeny"))
            {
                start_zeny = Integer.parseInt(Functions.getValueFromConfigString(charConf,"start_zeny"));
                if (start_zeny < 0)
                    start_zeny = 0;
            }
            
            if(charConf.contains("start_weapon"))
            {
                start_weapon = Integer.parseInt(Functions.getValueFromConfigString(charConf,"start_weapon"));
                if (start_weapon < 0)
                    start_weapon = 0;
            }
            
            if(charConf.contains("start_armor"))
            {
                start_armor = Integer.parseInt(Functions.getValueFromConfigString(charConf,"start_armor"));
                if (start_armor < 0)
                    start_armor = 0;
            }
            
            if(charConf.contains("unknown_char_name"))
                unknown_char_name = Functions.getValueFromConfigString(charConf,"unknown_char_name");
            
            if(charConf.contains("char_log_filename"))
                char_log_filename = Functions.getValueFromConfigString(charConf,"char_log_filename");
            
            if(charConf.contains("name_ignoring_case"))
                name_ignoring_case = Integer.parseInt(Functions.getValueFromConfigString(charConf,"name_ignoring_case"));
            
            if(charConf.contains("char_name_option"))
                char_name_option =  Integer.parseInt(Functions.getValueFromConfigString(charConf,"char_name_option"));
            
            if(charConf.contains("char_name_letters"))
                char_name_letters = Functions.getValueFromConfigString(charConf,"char_name_letters");
            
            if(charConf.contains("online_txt_filename"))
                online_txt_filename = Functions.getValueFromConfigString(charConf,"online_txt_filename");
            
            
            if(charConf.contains("online_html_filename"))
                online_html_filename = Functions.getValueFromConfigString(charConf,"online_html_filename");
            
            if(charConf.contains("online_sorting_option"))
                online_sorting_option = Integer.parseInt(Functions.getValueFromConfigString(charConf,"online_sorting_option"));
            
            if(charConf.contains("online_display_option"))
                online_display_option = Integer.parseInt(Functions.getValueFromConfigString(charConf,"online_display_option"));
            
            if(charConf.contains("online_gm_display_min_level"))
            {
                online_gm_display_min_level = Integer.parseInt(Functions.getValueFromConfigString(charConf,"online_gm_display_min_level"));
                
                if (online_gm_display_min_level < 5) // send online file every 5 seconds to player is enough
                    online_gm_display_min_level = 5;
            }
            
            if(charConf.contains("online_refresh_html"))
            {
                online_refresh_html = Integer.parseInt(Functions.getValueFromConfigString(charConf,"online_refresh_html"));
                
                if (online_refresh_html < 1)
                    online_refresh_html = 1;
            }
            
            if(charConf.contains("db_path"))
                db_path = Functions.getValueFromConfigString(charConf,"db_path");
            
            
            if(charConf.contains("console"))
                console = config_switch(Functions.getValueFromConfigString(charConf,"console")) == 1;
            
            if(charConf.contains("fame_list_alchemist"))
            {
                fame_list_size_alchemist = Integer.parseInt(Functions.getValueFromConfigString(charConf,"fame_list_alchemist"));
                if (fame_list_size_alchemist > Constants.MAX_FAME_LIST)
                {
                    Functions.showWarning(MultilanguageManagement.getWarning_48(), Constants.MAX_FAME_LIST,"fame_list_alchemist");
                    fame_list_size_alchemist = Constants.MAX_FAME_LIST;
                }
            }
            
            if(charConf.contains("fame_list_blacksmith"))
            {
                fame_list_size_blacksmith = Integer.parseInt(Functions.getValueFromConfigString(charConf,"fame_list_blacksmith"));
                if (fame_list_size_blacksmith > Constants.MAX_FAME_LIST)
                {
                    Functions.showWarning(MultilanguageManagement.getWarning_48(), Constants.MAX_FAME_LIST,"fame_list_blacksmith");
                    fame_list_size_blacksmith = Constants.MAX_FAME_LIST;
                }
            }
            
            if(charConf.contains("fame_list_taekwon"))
            {
                fame_list_size_taekwon = Integer.parseInt(Functions.getValueFromConfigString(charConf,"fame_list_taekwon"));
                if (fame_list_size_taekwon > Constants.MAX_FAME_LIST)
                {
                    Functions.showWarning(MultilanguageManagement.getWarning_48(), Constants.MAX_FAME_LIST,"fame_list_taekwon");
                    fame_list_size_taekwon = Constants.MAX_FAME_LIST;
                }
            }
            
            if(charConf.contains("import"))
                char_config_read(Functions.getValueFromConfigString(charConf,"import"));
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }
        
        return 0;
    }
    public static int login_lan_config_read(String lancfgName)
    {
        int j;
        File fp;
        
        // set default configuration
        lan_char_ip = "127.0.0.1";
        subneti[0] = 127;
        subneti[1] = 0;
        subneti[2] = 0;
        subneti[3] = 1;
        for(j = 0; j < 4; j++)
            subnetmaski[j] = 255;
        
        fp = new File(lancfgName);
        
        if (fp == null || !fp.exists())
        {
            Functions.showWarning(MultilanguageManagement.getWarning_1(),lancfgName);
            return 1;
        }
        
        Functions.showInfo(MultilanguageManagement.getInfo_2(),lancfgName);
        
        String lu = null;
        
        try
        {
            
            lu = Functions.readConf(fp);
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }
        StringTokenizer stLu = new StringTokenizer(lu,":");
        
        String param = stLu.nextElement().toString();
        if(param.equals("subnet"))
        {
            String subnet = stLu.nextElement().toString();
            StringTokenizer subip = new StringTokenizer(subnet,":./");
            
            for(j = 0; j < 4; j++)
                subneti[j] = Integer.parseInt(subip.nextElement().toString().trim());
            
            for(j = 0; j < 4; j++)
                subnetmaski[j] = Integer.parseInt(subip.nextElement().toString());
            
            lan_char_ip = stLu.nextElement().toString().trim();
            
            lan_map_ip = stLu.nextElement().toString().trim();
            
        }
        
        
        Functions.showInfo(MultilanguageManagement.getInfo_3(), lancfgName);
        return 0;
    }
    
    /**-----------------------------------
     * // Reading general configuration file
     * //---------------------------------**/
    public static int login_config_read(String cfgName)
    {
        int j;
        File fp;
        // set default configuration
        lan_char_ip = "127.0.0.1";
        subneti[0] = 127;
        subneti[1] = 0;
        subneti[2] = 0;
        subneti[3] = 1;
        for(j = 0; j < 4; j++)
            subnetmaski[j] = 255;
        
        fp = new File(cfgName);
        
        if (fp == null || !fp.exists())
        {
            Functions.showWarning(MultilanguageManagement.getWarning_2(), cfgName);
            return 1;
        }
        String lu = null;
        Functions.showInfo(MultilanguageManagement.getInfo_2(), cfgName);
        try
        {
            lu = Functions.readConf(fp);
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }
        
        String login_properties_names[] = {"admin_state","admin_pass",
        "ladminallowip","gm_pass","level_new_gm","bind_ip","login_port",
        "account_filename","gm_account_filename",
        "gm_account_filename_check_timer","use_MD5_passwords",
        "login_log_filename","log_login","login_log_unknown_packets_filename",
        "save_unknown_packets","display_parse_login","display_parse_admin",
        "display_parse_fromchar","date_format","min_level_to_connect",
        "add_to_unlimited_account","start_limited_time","check_ip_flag","order",
        "dynamic_pass_failure_ban","dynamic_pass_failure_ban_time",
        "dynamic_pass_failure_ban_how_many","dynamic_pass_failure_ban_how_long",
        "import","check_client_version","client_version_to_connect","console",
        "allowed_regs","time_allowed","new_account","online_check","use_dnsbl",
        "ipban","use_md5_passwds","deny"};
        String login_properties_values[] = new String[login_properties_names.length];
        String ladminallowip ="";
        for(int i = 0;i < login_properties_names.length;i++)
        {
            if(lu.contains(login_properties_names[i]))
            {
                int indexParam = lu.indexOf(login_properties_names[i]);
                int start = lu.indexOf(":",indexParam);
                while(!lu.substring(indexParam,start).trim().equals(login_properties_names[i]))
                {
                    indexParam = lu.indexOf(login_properties_names[i],indexParam+1);
                    start = lu.indexOf(":",indexParam);
                }
                int end = lu.indexOf("\n",start);
                login_properties_values[i] =lu.substring(start+1,end).trim();
                switch(i)
                {
                    case 0:
                        admin_state = Integer.parseInt(login_properties_values[i]);break;
                    case 1:
                        admin_pass = login_properties_values[i];break;
                    case 2:
                        ladminallowip = login_properties_values[i];break;
                    case 3:
                        gm_pass =login_properties_values[i];break;
                    case 4:
                        level_new_gm = Integer.parseInt(login_properties_values[i]);
                        break;
                    case 5:
                        bind_ip_str =  login_properties_values[i];
                        break;
                    case 6:
                        // login_port = Integer.parseInt(login_properties_values[i]);
                        
                        break;
                    case 7:
                        account_filename = login_properties_values[i];
                        
                        break;
                    case 8:
                        GM_account_filename = login_properties_values[i];
                        
                        break;
                    case 9:
                        gm_account_filename_check_timer = Integer.parseInt(login_properties_values[i]);
                        
                        break;
                    case 10:
                        use_MD5_passwords = config_switch(login_properties_values[i]);
                        
                        break;
                    case 11:
                        login_log_filename = login_properties_values[i];
                        
                        break;
                    case 12:
                        log_login = Integer.parseInt(login_properties_values[i]) == 1;
                        
                        break;
                    case 13:
                        login_log_unknown_packets_filename =  login_properties_values[i];
                        
                        break;
                    case 14:
                        save_unknown_packets = config_switch(login_properties_values[i]);
                        
                        break;
                    case 15:
                        display_parse_login = config_switch(login_properties_values[i]) == 1;
                        
                        break;
                    case 16:
                        display_parse_admin = config_switch(login_properties_values[i]) == 1;
                        break;
                    case 17:
                        display_parse_fromchar = config_switch(login_properties_values[i]);
                        break;
                    case 18:
                        date_format = login_properties_values[i];
                        break;
                    case 19:
                        min_level_to_connect = Integer.parseInt(login_properties_values[i]);
                        break;
                    case 20:add_to_unlimited_account =  config_switch(login_properties_values[i]);
                    
                    break;
                    case 21:
                        start_limited_time = Integer.parseInt(login_properties_values[i]);
                        
                        break;
                    case 22:check_ip_flag = config_switch(login_properties_values[i]);
                    
                    break;
                    case 23:order = login_properties_values[i];
                    
                    break;
                    case 24:dynamic_pass_failure_ban = config_switch(login_properties_values[i]) == 1;
                    
                    break;
                    case 25:dynamic_pass_failure_ban_time = Integer.parseInt(login_properties_values[i]);
                    
                    break;
                    case 26:dynamic_pass_failure_ban_how_many = Integer.parseInt(login_properties_values[i]);
                    
                    break;
                    case 27:dynamic_pass_failure_ban_how_long = Integer.parseInt(login_properties_values[i]);
                    
                    break;
                    case 28: login_config_read(login_properties_values[i]);
                    
                    break;
                    case 29:check_client_version = yesNoOnOffToBoolean(login_properties_values[i]);
                    
                    break;
                    case 30:client_version_to_connect = Integer.parseInt(login_properties_values[i]);
                    
                    break;
                    case 31: console = yesNoOnOffToBoolean(login_properties_values[i]);
                    
                    break;
                    case 32:
                        allowed_regs = Integer.parseInt(login_properties_values[i]);
                        break;
                        
                    case 33:
                        time_allowed = Integer.parseInt(login_properties_values[i]);
                        break;
                        
                    case 34:
                        new_account_flag = Integer.parseInt(login_properties_values[i]);
                        break;
                        
                    case 35:
                        online_check = config_switch(login_properties_values[i]) == 1;
                        break;
                        
                    case 36:
                        use_dnsbl = login_properties_values[i].equals("1");
                        break;
                        
                    case 37:
                        ipban = login_properties_values[i].equals("1");
                        break;
                        
                    case 38:
                        use_md5_passwds = login_properties_values[i].toUpperCase().equals("YES");
                        break;
                    case 39:
                        Functions.addToBanListTXT(login_properties_values[i]);
                }
            }
        }
        
        if(ladminallowip.equals("clear"))
        {
            access_ladmin_allow = null;
            access_ladmin_allownum = 0;
        }
        else if (ladminallowip.equals("all"))
        {
            // set to all
            access_ladmin_allownum = 1;
            access_ladmin_allow = null;
        }
        else
        {
            access_ladmin_allow = null;
        }
        Functions.showInfo(MultilanguageManagement.getInfo_3(), cfgName);
        return 0;
    }
    /**-------------------------------------------------
     * // Return numerical value of a switch configuration
     * // on/off, english, fran?ais, deutsch, espa?ol
     * //-----------------------------------------------**/
    public static int config_switch(String str)
    {
        if (str.equals("on") || str.equals("yes") || str.equals("oui") || str.equals("ja") || str.equals("si")|| str.equals("1"))
            return 1;
        if ( str.equals("off") || str.equals("no") || str.equals( "non") || str.equals("nein")|| str.equals("0"))
            return 0;
        
        return -1;
    }
    
    public static boolean yesNoOnOffToBoolean(String anw)
    {
        anw = anw.toUpperCase();
        if(anw.equals("YES") || anw.equals("ON") )return true;
        if(anw.equals("NO") || anw.equals("OFF") )return false;
        throw new IllegalArgumentException("anw doit etre egale a yes/no/on/off");
    }
    
    public static void display_conf_warnings()
    {
        if (admin_state != 0 && admin_state != 1)
        {
            Functions.showWarning(MultilanguageManagement.getWarning_3());
            admin_state = 0;
        }
        
        if (admin_state == 1)
        {
            if (admin_pass == null)
            {
                Functions.showWarning(MultilanguageManagement.getWarning_4());
            }
            else if (admin_pass.equals("admin"))
            {
                Functions.showWarning(MultilanguageManagement.getWarning_5());
                Functions.showWarning(MultilanguageManagement.getWarning_6());
            }
        }
        
        if (gm_pass == null)
        {
            Functions.showWarning(MultilanguageManagement.getWarning_7());
            Functions.showWarning(MultilanguageManagement.getWarning_8());
        }
        else if (gm_pass.equals("gm"))
        {
            Functions.showWarning(MultilanguageManagement.getWarning_9());
            Functions.showWarning(MultilanguageManagement.getWarning_6());
        }
        
        if (level_new_gm < 0 || level_new_gm > 99)
        {
            Functions.showWarning(MultilanguageManagement.getWarning_11());
            level_new_gm = 60;
        }
        
        if (new_account_flag != 0 && new_account_flag != 1)
        {
            Functions.showWarning(MultilanguageManagement.getWarning_12());
            new_account_flag = 0;
        }
        
        if (login_port < 1024 || login_port > 65535)
        {
            Functions.showWarning(MultilanguageManagement.getWarning_13());
            login_port = 6900;
        }
        
        if (gm_account_filename_check_timer < 0)
        {
            Functions.showWarning(MultilanguageManagement.getWarning_14());
            gm_account_filename_check_timer = 15;
        }
        else if (gm_account_filename_check_timer == 1)
        {
            Functions.showWarning(MultilanguageManagement.getWarning_15());
            gm_account_filename_check_timer = 2;
        }
        
        if (save_unknown_packets != 0 && save_unknown_packets != 1)
        {
            Functions.showWarning(MultilanguageManagement.getWarning_16());
            save_unknown_packets = 0;
        }
        
        if (display_parse_fromchar < 0 || display_parse_fromchar > 2)
        { // 0: no, 1: yes (without packet 0x2714), 2: all packets
            Functions.showWarning(MultilanguageManagement.getWarning_17());
            display_parse_fromchar = 0;
        }
        
        if (min_level_to_connect < 0)
        { // 0: all players, 1-99 at least gm level x
            Functions.showWarning(MultilanguageManagement.getWarning_18(),min_level_to_connect);
            min_level_to_connect = 0;
        }
        else if (min_level_to_connect > 99)
        { // 0: all players, 1-99 at least gm level x
            Functions.showWarning(MultilanguageManagement.getWarning_19(),min_level_to_connect);
            min_level_to_connect = 99;
        }
        
        if (add_to_unlimited_account != 0 && add_to_unlimited_account != 1)
        { // 0: no, 1: yes
            Functions.showWarning(MultilanguageManagement.getWarning_20());
            Functions.showWarning(MultilanguageManagement.getWarning_21());
            add_to_unlimited_account = 0;
        }
        
        if (start_limited_time < -1)
        { // -1: create unlimited account, 0 or more: additionnal sec from now to create limited time
            Functions.showWarning(MultilanguageManagement.getWarning_22());
            Functions.showWarning(MultilanguageManagement.getWarning_23());
            start_limited_time = -1;
        }
        
        if (check_ip_flag != 0 && check_ip_flag != 1)
        { // 0: no, 1: yes
            Functions.showWarning(MultilanguageManagement.getWarning_24());
            Functions.showWarning(MultilanguageManagement.getWarning_25());
            check_ip_flag = 1;
        }
        
        if (access_order == ACO.DENY_ALLOW)
        {
            if (access_denynum == 1 && access_deny == null)
            {
                Functions.showWarning(MultilanguageManagement.getWarning_26());
            }
        }
        else if (access_order == ACO.ALLOW_DENY)
        {
            if (access_allownum == 0)
            {
                Functions.showWarning(MultilanguageManagement.getWarning_27());
            }
        }
        else
        { // ACO_MUTUAL_FAILTURE
            if (access_allownum == 0)
            {
                Functions.showWarning(MultilanguageManagement.getWarning_28());
                Functions.showWarning(MultilanguageManagement.getWarning_29());
                Functions.showWarning(MultilanguageManagement.getWarning_30());
            }
            else if (access_denynum == 1 && access_deny == null)
            {
                Functions.showWarning(MultilanguageManagement.getWarning_31());
                Functions.showWarning(MultilanguageManagement.getWarning_32());
                Functions.showWarning(MultilanguageManagement.getWarning_33());
            }
        }
        
        if (dynamic_pass_failure_ban)
        {
            if (dynamic_pass_failure_ban_time < 1)
            {
                Functions.showWarning(MultilanguageManagement.getWarning_34(),dynamic_pass_failure_ban_how_long);
                Functions.showWarning(MultilanguageManagement.getWarning_35());
                dynamic_pass_failure_ban_time = 5;
            }
            if (dynamic_pass_failure_ban_how_many < 1)
            {
                Functions.showWarning(MultilanguageManagement.getWarning_36(),dynamic_pass_failure_ban_how_long);
                Functions.showWarning(MultilanguageManagement.getWarning_37());
                dynamic_pass_failure_ban_how_many = 3;
            }
            if (dynamic_pass_failure_ban_how_long < 1)
            {
                Functions.showWarning(MultilanguageManagement.getWarning_38(),dynamic_pass_failure_ban_how_long);
                Functions.showWarning(MultilanguageManagement.getWarning_39());
                dynamic_pass_failure_ban_how_long = 1;
            }
        }
        
        return;
    }
    
    public static long getStart_limited_time()
    {
        return startLimitedTime;
    }
    
    public static void setStart_limited_time(long aStart_limited_time)
    {
        startLimitedTime = aStart_limited_time;
    }
    
    public static int getGMMax()
    {
        return GMMax;
    }
    
    public static void setGMMax(int aGMMax)
    {
        GMMax = aGMMax;
    }
    public static void addGMMax(int aGMMax)
    {
        aGMMax+= aGMMax;
    }
    public static void addGMMax()
    {
        GMMax++;
    }
    
    public static int getServer_num()
    {
        return server_num;
    }
    
    public static void setServer_num(int aServer_num)
    {
        server_num = aServer_num;
    }
    
    public static int getNew_account_flag()
    {
        return new_account_flag;
    }
    
    public static void setNew_account_flag(int aNew_account_flag)
    {
        new_account_flag = aNew_account_flag;
    }
    
    public static String getBind_ip_str()
    {
        return bind_ip_str;
    }
    
    public static void setBind_ip_str(String aBind_ip_str)
    {
        bind_ip_str = aBind_ip_str;
    }
    
    public static String getBind_ip()
    {
        return bind_ip;
    }
    
    public static void setBind_ip(String aBind_ip)
    {
        bind_ip = aBind_ip;
    }
    
    public static String getLan_char_ip()
    {
        return lan_char_ip;
    }
    
    public static void setLan_char_ip(String aLan_char_ip)
    {
        lan_char_ip = aLan_char_ip;
    }
    
    public static int[] getSubneti()
    {
        return subneti;
    }
    
    public static void setSubneti(int[] aSubneti)
    {
        subneti = aSubneti;
    }
    
    public static int[] getSubnetmaski()
    {
        return subnetmaski;
    }
    
    public static void setSubnetmaski(int[] aSubnetmaski)
    {
        subnetmaski = aSubnetmaski;
    }
    
    public static int getUse_MD5_passwords()
    {
        return use_MD5_passwords;
    }
    
    public static void setUse_MD5_passwords(int aUse_MD5_passwords)
    {
        use_MD5_passwords = aUse_MD5_passwords;
    }
    
    public static String getAccount_filename()
    {
        return account_filename;
    }
    
    public static void setAccount_filename(String aAccount_filename)
    {
        account_filename = aAccount_filename;
    }
    
    public static String getGM_account_filename()
    {
        return GM_account_filename;
    }
    
    public static void setGM_account_filename(String aGM_account_filename)
    {
        GM_account_filename = aGM_account_filename;
    }
    
    public static String getLogin_log_filename()
    {
        return login_log_filename;
    }
    
    public static void setLogin_log_filename(String aLogin_log_filename)
    {
        login_log_filename = aLogin_log_filename;
    }
    
    
    public static String getLogin_log_unknown_packets_filename()
    {
        return login_log_unknown_packets_filename;
    }
    
    public static void setLogin_log_unknown_packets_filename(String aLogin_log_unknown_packets_filename)
    {
        login_log_unknown_packets_filename = aLogin_log_unknown_packets_filename;
    }
    
    public static int getSave_unknown_packets()
    {
        return save_unknown_packets;
    }
    
    public static void setSave_unknown_packets(int aSave_unknown_packets)
    {
        save_unknown_packets = aSave_unknown_packets;
    }
    
    public static long getCreation_time_GM_account_file()
    {
        return creation_time_GM_account_file;
    }
    
    public static void setCreation_time_GM_account_file(long aCreation_time_GM_account_file)
    {
        creation_time_GM_account_file = aCreation_time_GM_account_file;
    }
    
    public static int getGm_account_filename_check_timer()
    {
        return gm_account_filename_check_timer;
    }
    
    public static void setGm_account_filename_check_timer(int aGm_account_filename_check_timer)
    {
        gm_account_filename_check_timer = aGm_account_filename_check_timer;
    }
    
    public static boolean isLog_login()
    {
        return log_login;
    }
    
    public static void setLog_login(boolean aLog_login)
    {
        log_login = aLog_login;
    }
    
    public static boolean isDisplay_parse_login()
    {
        return display_parse_login;
    }
    
    public static void setDisplay_parse_login(boolean aDisplay_parse_login)
    {
        display_parse_login = aDisplay_parse_login;
    }
    
    public static boolean isDisplay_parse_admin()
    {
        return display_parse_admin;
    }
    
    public static void setDisplay_parse_admin(boolean aDisplay_parse_admin)
    {
        display_parse_admin = aDisplay_parse_admin;
    }
    
    public static int getDisplay_parse_fromchar()
    {
        return display_parse_fromchar;
    }
    
    public static void setDisplay_parse_fromchar(int aDisplay_parse_fromchar)
    {
        display_parse_fromchar = aDisplay_parse_fromchar;
    }
    
    public static long getNew_reg_tick()
    {
        return new_reg_tick;
    }
    
    public static void setNew_reg_tick(long aNew_reg_tick)
    {
        new_reg_tick = aNew_reg_tick;
    }
    
    public static int getAllowed_regs()
    {
        return allowed_regs;
    }
    
    public static void setAllowed_regs(int aAllowed_regs)
    {
        allowed_regs = aAllowed_regs;
    }
    
    public static long getNum_regs()
    {
        return num_regs;
    }
    
    public static void setNum_regs(long aNum_regs)
    {
        num_regs = aNum_regs;
    }
    public static void addNum_regs(long aNum_regs)
    {
        num_regs += aNum_regs;
    }
    public static void addNum_regs()
    {
        num_regs++;
    }
    public static int getTime_allowed()
    {
        return time_allowed;
    }
    
    public static void setTime_allowed(int aTime_allowed)
    {
        time_allowed = aTime_allowed;
    }
    
    public static ACO getAccess_order()
    {
        return access_order;
    }
    
    public static void setAccess_order(ACO aAccess_order)
    {
        access_order = aAccess_order;
    }
    
    public static int getAccess_allownum()
    {
        return access_allownum;
    }
    
    public static void setAccess_allownum(int aAccess_allownum)
    {
        access_allownum = aAccess_allownum;
    }
    
    public static int getAccess_denynum()
    {
        return access_denynum;
    }
    
    public static void setAccess_denynum(int aAccess_denynum)
    {
        access_denynum = aAccess_denynum;
    }
    
    public static String getAccess_allow()
    {
        return access_allow;
    }
    
    public static void setAccess_allow(String aAccess_allow)
    {
        access_allow = aAccess_allow;
    }
    
    public static String getAccess_deny()
    {
        return access_deny;
    }
    
    public static void setAccess_deny(String aAccess_deny)
    {
        access_deny = aAccess_deny;
    }
    
    public static int getAccess_ladmin_allownum()
    {
        return access_ladmin_allownum;
    }
    
    public static void setAccess_ladmin_allownum(int aAccess_ladmin_allownum)
    {
        access_ladmin_allownum = aAccess_ladmin_allownum;
    }
    
    public static String getAccess_ladmin_allow()
    {
        return access_ladmin_allow;
    }
    
    public static void setAccess_ladmin_allow(String aAccess_ladmin_allow)
    {
        access_ladmin_allow = aAccess_ladmin_allow;
    }
    
    public static int getMin_level_to_connect()
    {
        return min_level_to_connect;
    }
    
    public static void setMin_level_to_connect(int aMin_level_to_connect)
    {
        min_level_to_connect = aMin_level_to_connect;
    }
    
    public static int getAdd_to_unlimited_account()
    {
        return add_to_unlimited_account;
    }
    
    public static void setAdd_to_unlimited_account(int aAdd_to_unlimited_account)
    {
        add_to_unlimited_account = aAdd_to_unlimited_account;
    }
    
    public static void setStart_limited_time(int aStart_limited_time)
    {
        start_limited_time = aStart_limited_time;
    }
    
    public static int getCheck_ip_flag()
    {
        return check_ip_flag;
    }
    
    public static void setCheck_ip_flag(int aCheck_ip_flag)
    {
        check_ip_flag = aCheck_ip_flag;
    }
    
    public static boolean isCheck_client_version()
    {
        return check_client_version;
    }
    
    public static void setCheck_client_version(boolean aCheck_client_version)
    {
        check_client_version = aCheck_client_version;
    }
    
    public static int getClient_version_to_connect()
    {
        return client_version_to_connect;
    }
    
    public static void setClient_version_to_connect(int aClient_version_to_connect)
    {
        client_version_to_connect = aClient_version_to_connect;
    }
    
    public static long getStartLimitedTime()
    {
        return startLimitedTime;
    }
    
    public static void setStartLimitedTime(long aStartLimitedTime)
    {
        startLimitedTime = aStartLimitedTime;
    }
    public static int lesslessAuth_before_save_file()
    {
        return --auth_before_save_file;
    }
    public static int getAuth_before_save_file()
    {
        return auth_before_save_file;
    }
    
    public static void setAuth_before_save_file(int aAuth_before_save_file)
    {
        auth_before_save_file = aAuth_before_save_file;
    }
    
    public static int getAdmin_state()
    {
        return admin_state;
    }
    
    public static void setAdmin_state(int aAdmin_state)
    {
        admin_state = aAdmin_state;
    }
    
    public static String getAdmin_pass()
    {
        return admin_pass;
    }
    
    public static void setAdmin_pass(String aAdmin_pass)
    {
        admin_pass = aAdmin_pass;
    }
    
    public static String getGm_pass()
    {
        return gm_pass;
    }
    
    public static void setGm_pass(String aGm_pass)
    {
        gm_pass = aGm_pass;
    }
    
    public static int getLevel_new_gm()
    {
        return level_new_gm;
    }
    
    public static void setLevel_new_gm(int aLevel_new_gm)
    {
        level_new_gm = aLevel_new_gm;
    }
    
 /*   public static int getLogin_port()
    {
        return login_port;
    }
  
    public static void setLogin_port(int aLogin_port)
    {
        login_port = aLogin_port;
    }
  */
    public static boolean getDynamic_pass_failure_ban()
    {
        return dynamic_pass_failure_ban;
    }
    
    public static void setDynamic_pass_failure_ban(boolean aDynamic_pass_failure_ban)
    {
        dynamic_pass_failure_ban = aDynamic_pass_failure_ban;
    }
    
    public static int getDynamic_pass_failure_ban_time()
    {
        return dynamic_pass_failure_ban_time;
    }
    
    public static void setDynamic_pass_failure_ban_time(int aDynamic_pass_failure_ban_time)
    {
        dynamic_pass_failure_ban_time = aDynamic_pass_failure_ban_time;
    }
    
    public static int getDynamic_pass_failure_ban_how_many()
    {
        return dynamic_pass_failure_ban_how_many;
    }
    
    public static void setDynamic_pass_failure_ban_how_many(int aDynamic_pass_failure_ban_how_many)
    {
        dynamic_pass_failure_ban_how_many = aDynamic_pass_failure_ban_how_many;
    }
    
    public static int getDynamic_pass_failure_ban_how_long()
    {
        return dynamic_pass_failure_ban_how_long;
    }
    
    public static void setDynamic_pass_failure_ban_how_long(int aDynamic_pass_failure_ban_how_long)
    {
        dynamic_pass_failure_ban_how_long = aDynamic_pass_failure_ban_how_long;
    }
    
    public static String getDate_format()
    {
        return date_format;
    }
    
    public static void setDate_format(String aDate_format)
    {
        date_format = aDate_format;
    }
    
    public static String getOrder()
    {
        return order;
    }
    
    public static void setOrder(String aOrder)
    {
        order = aOrder;
    }
    
    public boolean isConsole()
    {
        return console;
    }
    
    public void setConsole(boolean console)
    {
        this.console = console;
    }
    
    public static boolean isOnline_check()
    {
        return online_check;
    }
    
    
    public static boolean isUse_dnsbl()
    {
        return use_dnsbl;
    }
    
    public static boolean isIpban()
    {
        return ipban;
    }
    
    public static boolean isUse_md5_passwds()
    {
        return use_md5_passwds;
    }
    
    public static int getGmLevel()
    {
        return gmLevel;
    }
    
    public static void setGmLevel(int aGmLevel)
    {
        gmLevel = aGmLevel;
    }
    
    public static int getLogin_port()
    {
        return login_port;
    }
    
    public static void setLogin_port(int aLogin_port)
    {
        login_port = aLogin_port;
    }
    
    public static String getMapIndex()
    {
        return mapIndexPath;
    }
    
    public static void setMapIndex(String aMapIndex)
    {
        mapIndexPath = aMapIndex;
    }
    
    public static String getTimestamp_format()
    {
        return timestamp_format;
    }
    
    public static void setTimestamp_format(String aTimestamp_format)
    {
        timestamp_format = aTimestamp_format;
    }
    
    public static boolean isConsole_silent()
    {
        return console_silent;
    }
    
    public static void setConsole_silent(boolean aConsole_silent)
    {
        console_silent = aConsole_silent;
    }
    
    public static String getWisp_server_name()
    {
        return wisp_server_name;
    }
    
    public static String getLogin_ip_str()
    {
        return login_ip_str;
    }
    
    public static boolean isLogin_ip_set_()
    {
        return login_ip_set_;
    }
    
    public static String getMapIndexPath()
    {
        return mapIndexPath;
    }
    
    public static String getCharPassword()
    {
        return charPassword;
    }
    
    public static String getServer_name()
    {
        return server_name;
    }
    
    public static String getCharUserid()
    {
        return charUserid;
    }
    
    public static String getChar_ip_str()
    {
        return char_ip_str;
    }
    
    public static boolean isChar_ip_set_()
    {
        return char_ip_set_;
    }
    
    public static int getChar_port()
    {
        return char_port;
    }
    
    public static int getChar_maintenance()
    {
        return char_maintenance;
    }
    
    public static int getChar_new()
    {
        return char_new;
    }
    
    public static int getChar_new_display()
    {
        return char_new_display;
    }
    
    public static int getEmail_creation()
    {
        return email_creation;
    }
    
    public static String getChar_txt()
    {
        return char_txt;
    }
    
    public static String getScdata_txt()
    {
        return scdata_txt;
    }
    
    public static String getBackup_txt()
    {
        return backup_txt;
    }
    
    public static String getFriends_txt()
    {
        return friends_txt;
    }
    
    public static String getBackup_txt_flag()
    {
        return backup_txt_flag;
    }
    
    public static String getMax_connect_user()
    {
        return max_connect_user;
    }
    
    public static int getGm_allow_level()
    {
        return gm_allow_level;
    }
    
    public static int getAutosave_time()
    {
        return autosave_time;
    }
    
    public static int getAutosave_interval()
    {
        return autosave_interval;
    }
    
    public static Point getStart_point()
    {
        return start_point;
    }
    
    public static void setStart_point(Point aStart_point)
    {
        start_point = aStart_point;
    }
    
    public static boolean isLog_char()
    {
        return log_char;
    }
    
    public static int getStart_zeny()
    {
        return start_zeny;
    }
    
    public static int getStart_weapon()
    {
        return start_weapon;
    }
    
    public static int getStart_armor()
    {
        return start_armor;
    }
    
    public static String getUnknown_char_name()
    {
        return unknown_char_name;
    }
    
    public static String getChar_log_filename()
    {
        return char_log_filename;
    }
    
    public static int getName_ignoring_case()
    {
        return name_ignoring_case;
    }
    
    public static int getChar_name_option()
    {
        return char_name_option;
    }
    
    public static String getChar_name_letters()
    {
        return char_name_letters;
    }
    
    public static String getOnline_txt_filename()
    {
        return online_txt_filename;
    }
    
    public static String getOnline_html_filename()
    {
        return online_html_filename;
    }
    
    public static int getOnline_sorting_option()
    {
        return online_sorting_option;
    }
    
    public static int getOnline_display_option()
    {
        return online_display_option;
    }
    
    public static int getOnline_gm_display_min_level()
    {
        return online_gm_display_min_level;
    }
    
    public static int getOnline_refresh_html()
    {
        return online_refresh_html;
    }
    
    public static String getDb_path()
    {
        return db_path;
    }
    
    public static int getFame_list_alchemist()
    {
        return fame_list_size_alchemist;
    }
    
    public static int getFame_list_blacksmith()
    {
        return fame_list_size_blacksmith;
    }
    
    public static int getFame_list_taekwon()
    {
        return fame_list_size_taekwon;
    }
    
    public static void setLogin_ip_str(String aLogin_ip_str)
    {
        login_ip_str = aLogin_ip_str;
    }
    
    public static void setChar_ip_str(String aChar_ip_str)
    {
        char_ip_str = aChar_ip_str;
    }
    
    public static int getChar_id_count()
    {
        return char_id_count;
    }
    
    public static void setChar_id_count(int aChar_id_count)
    {
        char_id_count = aChar_id_count;
    }
    public static void addChar_id_count(int aChar_id_count)
    {
        char_id_count += aChar_id_count;
    }
    public static void addChar_id_count( )
    {
        char_id_count ++;
    }
}
