/*
 * MapServer.java
 *
 * Created on 20 mai 2006, 23:51
 *
 * Copyright (c) 2006, Fran�ois Bradette
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of their contributors may be used to endorse or
 *       promote products derived from this software without specific prior
 *       written permission.
 *
 * This software is provided by the regents and contributors "as is" and any
 * express or implied warranties, including, but not limited to, the implied
 * warranties of merchantability and fitness for a particular purpose are
 * disclaimed.  In no event shall the regents and contributors be liable for any
 * direct, indirect, incidental, special, exemplary, or consequential damages
 * (including, but not limited to, procurement of substitute goods or services;
 * loss of use, data, or profits; or business interruption) however caused and
 * on any theory of liability, whether in contract, strict liability, or tort
 * (including negligence or otherwise) arising in any way out of the use of this
 * software, even if advised of the possibility of such damage.
 *
 * Translate from eAthena(c) by Fran�ois Bradette
 */


package core.data;

import core.utiles.Constants;
import javolution.util.FastMap;
import javolution.util.FastTable;

/**
 *
 * @author Darksid_1
 */
public class MapServer
{
    private static FastMap maps_id_index;
    private static FastMap maps_id_ip_port_index;
    private String ip;
    private int port;
    private int users;
    private FastTable maps;
    /** Creates a new instance of MapServer */
    static
    {
        maps_id_index = new FastMap();
        maps_id_ip_port_index = new FastMap();
    }
    public MapServer()
    {
        maps = new FastTable();
    }
    
    public String getIp()
    {
        return ip;
    }
    
    public void setIp(String ip)
    {
        this.ip = ip;
    }
    
    public int getPort()
    {
        return port;
    }
    
    public void setPort(int port)
    {
        this.port = port;
    }
    
    public int getUsers()
    {
        return users;
    }
    
    public void setUsers(int users)
    {
        this.users = users;
    }
    
    public void addMapTXT(short id)
    {
        if(maps.size() != Constants.MAX_MAP_PER_SERVER)
        {
            maps.add(id);
            maps_id_index.put(id,this);
            maps_id_ip_port_index.put(id+ip+port,this);
        }
    }
    
    public static MapServer getMapServerTXT(short aId)
    {
        return (MapServer) maps_id_index.get(aId);
    }
    
    public static MapServer getMapServerTXT(short aId,String aIp,int aPort)
    {
        return (MapServer) maps_id_ip_port_index.get(aId+aIp+aPort);
    }
}
