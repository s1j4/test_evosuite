/*
 * Auth_data.java
 *
 * Created on March 24, 2006, 3:06 PM
 *
 *
 * Copyright (c) 2006, Fran�ois Bradette
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of their contributors may be used to endorse or
 *       promote products derived from this software without specific prior
 *       written permission.
 *
 * This software is provided by the regents and contributors "as is" and any
 * express or implied warranties, including, but not limited to, the implied
 * warranties of merchantability and fitness for a particular purpose are
 * disclaimed.  In no event shall the regents and contributors be liable for any
 * direct, indirect, incidental, special, exemplary, or consequential damages
 * (including, but not limited to, procurement of substitute goods or services;
 * loss of use, data, or profits; or business interruption) however caused and
 * on any theory of liability, whether in contract, strict liability, or tort
 * (including negligence or otherwise) arising in any way out of the use of this
 * software, even if advised of the possibility of such damage.
 *
 * Translate from eAthena(c) by Fran�ois Bradette
 */

package core.data;

import core.utiles.ConfigurationManagement;
import core.utiles.Constants;
import java.net.InetAddress;
import java.util.Calendar;
import core.utiles.Functions;


/**
 *
 * @author root
 */
public class Auth_data
{
    protected int account_id;
    protected int ip;
    protected int sex;
    protected int delflag;
    
    protected String userid;//[24],
    protected String pass;//[33],
    protected Calendar lastlogin;//[24]; // 33 for 32 + NULL terminated
    
    protected int logincount;
    protected int state; // packet 0x006a value + 1 (0: compte OK)
    
    protected String email;//[40]; // e-mail (by default: a@a.com)
    protected String error_message;//[20]; // Message of error code #6 = Your are Prohibited to log in until %s (packet 0x006a)
    
    protected Calendar ban_until_time; // # of seconds 1/1/1970 (timestamp): ban time limit of the account (0 = no ban)
    protected Calendar connect_until_time; // # of seconds 1/1/1970 (timestamp): Validity limit of the account (0 = unlimited)
    
    protected String last_ip;//[16]; // save of last IP of connection
    protected String memo;//[255]; // a memo field
    
    protected int account_reg2_num;
    protected Global_reg[] account_reg2;//[ACCOUNT_REG2_NUM];
    protected boolean waiting_disconnect;
    protected int version;
    protected int level;
    
    
    public Auth_data()
    {
        level = ConfigurationManagement.getGmLevel();
        account_reg2 = new Global_reg[Constants.ACCOUNT_REG2_NUM];
    }
    
    public Integer getAccount_id()
    {
        return account_id;
    }
    
    public void setAccount_id(int account_id)
    {
        this.account_id = account_id;
    }
    
    public int getSex()
    {
        return sex;
    }
    
    public void setSex(int sex)
    {
        this.sex = sex;
    }
    
    public int getDelflag()
    {
        return delflag;
    }
    
    public void setDelflag(int delflag)
    {
        this.delflag = delflag;
    }
    
    public String getUserid()
    {
        return userid;
    }
    
    public void setUserid(String userid)
    {
        this.userid = userid;
    }
    
    public String getPass()
    {
        return pass;
    }
    
    public void setPass(String pass)
    {
        this.pass = pass;
    }
    
    public Calendar getLastlogin()
    {
        return lastlogin;
    }
    
    public void setLastlogin(Calendar lastlogin)
    {
        this.lastlogin = lastlogin;
    }
    
    public void setLastlogin()
    {
        this.lastlogin = Calendar.getInstance();
        logincount++;
    }
    
    public int getLogincount()
    {
        return logincount;
    }
    
    public void setLogincount(int logincount)
    {
        if(logincount > 0)
            this.logincount = 0;
        else
            this.logincount = logincount;
    }
    
    public int getState()
    {
        return state;
    }
    
    public void setState(int state)
    {
        if (state > 255)
            this.state = 100;
        else
            if (state < 0)
                this.state = 0;
            else
                this.state = state;
    }
    
    public String getEmail()
    {
        return email;
    }
    
    public void setEmail(String email)
    {
        this.email = email;
    }
    
    public String getError_message()
    {
        return error_message;
    }
    
    public void setError_message(String error_message)
    {
        this.error_message = error_message;
    }
    
    public Calendar getBan_until_time()
    {
        return ban_until_time;
    }
    
    public void setBan_until_time(Calendar ban_until_time)
    {
        this.ban_until_time = ban_until_time;
    }
    
    public Calendar getConnect_until_time()
    {
        return connect_until_time;
    }
    
    public void setConnect_until_time(Calendar connect_until_time)
    {
        this.connect_until_time = connect_until_time;
    }
    
    public String getLast_ip()
    {
        return last_ip;
    }
    
    public void setLast_ip(String last_ip)
    {
        this.last_ip = last_ip;
    }
    
    public String getMemo()
    {
        return memo;
    }
    
    public void setMemo(String memo)
    {
        this.memo = memo;
    }
    
    public int getAccount_reg2_num()
    {
        return account_reg2.length;
    }
    
    public  Global_reg[] getAccount_reg2()
    {
        return account_reg2;
    }
    
    public void setAccount_reg2(Global_reg account2[])
    {
        account_reg2 = account2;
    }
    
    public void setAccount_reg2At(Global_reg account2, int index)
    {
        account_reg2[index] = account2;
    }
    
    public int getVersion()
    {
        return version;
    }
    
    public void setVersion(int version)
    {
        this.version = version;
    }
    
    public String toString()
    {
        String str;
        str = getAccount_id()+"\t"+ getUserid()  +"\t"+
                getPass()+"\t"+ Functions.calendarToString(getLastlogin())+"\t" +
                ((getSex() == 2)?"S":(getSex() == 1?"M":"F")) +"\t"+ getLogincount()+"\t"+
                getState()+"\t"+ getEmail()+"\t"+
                getError_message()+"\t"+ getConnect_until_time().getTimeInMillis()+"\t"+
                (getLast_ip() != null?getLast_ip():"-")+
                "\t"+ getMemo()+"\t"+
                (getBan_until_time() != null ? getBan_until_time().getTimeInMillis():"0")+"\t";
        
        for(int i = 0; i < getAccount_reg2_num() && account_reg2[i] != null; i++)
        {
            str += account_reg2[i].getStr()+","+ account_reg2[i].getValue();
        }
        
        return str;
    }
    
    public boolean isWaiting_disconnect()
    {
        return waiting_disconnect;
    }
    
    public void setWaiting_disconnect(boolean waiting_disconnect)
    {
        this.waiting_disconnect = waiting_disconnect;
    }
    
    public void setLevel(int level)
    {
        this.level = level;
    }
    
    public int getLevel()
    {
        return level;
    }
}