/*
 * CharacterData.java
 *
 * Created on 20 mai 2006, 22:46
 *
 * Copyright (c) 2006, Fran�ois Bradette
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of their contributors may be used to endorse or
 *       promote products derived from this software without specific prior
 *       written permission.
 *
 * This software is provided by the regents and contributors "as is" and any
 * express or implied warranties, including, but not limited to, the implied
 * warranties of merchantability and fitness for a particular purpose are
 * disclaimed.  In no event shall the regents and contributors be liable for any
 * direct, indirect, incidental, special, exemplary, or consequential damages
 * (including, but not limited to, procurement of substitute goods or services;
 * loss of use, data, or profits; or business interruption) however caused and
 * on any theory of liability, whether in contract, strict liability, or tort
 * (including negligence or otherwise) arising in any way out of the use of this
 * software, even if advised of the possibility of such damage.
 *
 * Translate from eAthena(c) by Fran�ois Bradette
 */


package core.data;

import core.utiles.Constants;
import javolution.util.FastMap;
import javolution.util.FastTable;

/**
 *
 * @author Darksid_1
 */
public class CharacterData
{
    private Global_reg global[];
    
    private int char_id;
    private int account_id;
    private int partner_id;
    private int father;
    private int mother;
    private int child;
    private int base_exp;
    private int job_exp;
    private int zeny;
    
    private Constants.JOB class_;
    private short status_point;
    private short skill_point;
    private int hp;
    private int max_hp;
    private int sp;
    private int max_sp;
    private short option;
    private short manner;
    private char karma;
    private short hair;
    private int hair_color;
    private int clothes_color;
    private int party_id;
    private int guild_id;
    private int pet_id;
    private int fame;
    
    private short weapon;
    private short shield;
    private short head_top;
    private short head_mid;
    private short head_bottom;
    
    private String name;//[NAME_LENGTH];
    private int base_level;
    private int job_level;
    private short str;
    private short agi;
    private short vit;
    private short int_;
    private short dex;
    private short luk;
    private char char_num;
    private char sex;
    
    private long mapip;
    private int mapport;
    private Point last_point;
    private Point save_point;
    
    private Point memo_point[];
    
    private Item inventory[];//[MAX_INVENTORY],
    private Item cart[];//[MAX_CART];
    private Skill skills[];
    private Friend friends[];//New friend system [Skotlex]
    
    private static CharacterTable dbCharacter;
    //                    character_id
    
    
    static
    {
        dbCharacter = new CharacterTable();
    }
    
    /**
     * Creates a new instance of CharacterData
     */
    public CharacterData()
    {
        global = new Global_reg[Constants.ACCOUNT_REG2_NUM];
        memo_point = new Point[Constants.MAX_MEMOPOINTS];
        inventory  = new Item[Constants.MAX_INVENTORY];
        cart = new Item[Constants.MAX_CART];
        skills = new Skill[Constants.MAX_SKILL];
        friends = new Friend[Constants.MAX_FRIENDS];
    }
    
    public static void addTXT(CharacterData charact)
    {
        FastTable characters = null;
        dbCharacter.addCaracter(charact);
    }
    public static CharacterTable getCharacterDatas()
    {
        return dbCharacter;
    }
    public static void setCharacterDatas(CharacterTable adbCharacter)
    {
        dbCharacter = adbCharacter;
    }
    public void setItemAt(Item inventoryItem,int ind)
    {
        inventory[ind] = inventoryItem;
    }
    
    public void setMemoAt(Point memo,int ind)
    {
        memo_point[ind] = memo;
    }
    public static CharacterData getCharacterTXT(String name)
    {
        return dbCharacter.getByCharName(name);
    }
    
    public static CharacterData getCharacterTXT(int char_id)
    {
        return dbCharacter.getByCharId(char_id);
    }
    
    public static FastTable getCharactersTXT(int account_id)
    {
        return dbCharacter.getByAccountId(account_id);
    }
    public Global_reg[] getGlobal()
    {
        return global;
    }
    
    public void setGlobal(Global_reg[] global)
    {
        this.global = global;
    }
    
    public int getChar_id()
    {
        return char_id;
    }
    
    public void setChar_id(int char_id)
    {
        this.char_id = char_id;
    }
    
    public int getAccount_id()
    {
        return account_id;
    }
    
    public void setAccount_id(int account_id)
    {
        this.account_id = account_id;
    }
    
    public int getPartner_id()
    {
        return partner_id;
    }
    
    public void setPartner_id(int partner_id)
    {
        this.partner_id = partner_id;
    }
    
    public int getFather()
    {
        return father;
    }
    
    public void setFather(int father)
    {
        this.father = father;
    }
    
    public int getMother()
    {
        return mother;
    }
    
    public void setMother(int mother)
    {
        this.mother = mother;
    }
    
    public int getChild()
    {
        return child;
    }
    
    public void setChild(int child)
    {
        this.child = child;
    }
    
    public int getBase_exp()
    {
        return base_exp;
    }
    
    public void setBase_exp(int base_exp)
    {
        this.base_exp = base_exp;
    }
    
    public int getJob_exp()
    {
        return job_exp;
    }
    
    public void setJob_exp(int job_exp)
    {
        this.job_exp = job_exp;
    }
    
    public int getZeny()
    {
        return zeny;
    }
    
    public void setZeny(int zeny)
    {
        this.zeny = zeny;
    }
    
    public Constants.JOB getClass_()
    {
        return class_;
    }
    
    public void setClass_(Constants.JOB class_)
    {
        this.class_ = class_;
    }
    
    public short getStatus_point()
    {
        return status_point;
    }
    
    public void setStatus_point(short status_point)
    {
        this.status_point = status_point;
    }
    
    public short getSkill_point()
    {
        return skill_point;
    }
    
    public void setSkill_point(short skill_point)
    {
        this.skill_point = skill_point;
    }
    
    public int getHp()
    {
        return hp;
    }
    
    public void setHp(int hp)
    {
        this.hp = hp;
    }
    
    public int getMax_hp()
    {
        return max_hp;
    }
    
    public void setMax_hp(int max_hp)
    {
        this.max_hp = max_hp;
    }
    
    public int getJob_level()
    {
        return job_level;
    }
    
    public void setJob_level(int job_level)
    {
        this.job_level = job_level;
    }
    
    public int getSp()
    {
        return sp;
    }
    
    public void setSp(int sp)
    {
        this.sp = sp;
    }
    
    public int getMax_sp()
    {
        return max_sp;
    }
    
    public void setMax_sp(int max_sp)
    {
        this.max_sp = max_sp;
    }
    
    public short getOption()
    {
        return option;
    }
    
    public void setOption(short option)
    {
        this.option = option;
    }
    
    public short getManner()
    {
        return manner;
    }
    
    public void setManner(short manner)
    {
        this.manner = manner;
    }
    
    public char getKarma()
    {
        return karma;
    }
    
    public void setKarma(char karma)
    {
        this.karma = karma;
    }
    
    public short getHair()
    {
        return hair;
    }
    
    public void setHair(short hair)
    {
        this.hair = hair;
    }
    
    public int getHair_color()
    {
        return hair_color;
    }
    
    public void setHair_color(int hair_color)
    {
        this.hair_color = hair_color;
    }
    
    public int getClothes_color()
    {
        return clothes_color;
    }
    
    public void setClothes_color(int clothes_color)
    {
        this.clothes_color = clothes_color;
    }
    
    public int getParty_id()
    {
        return party_id;
    }
    
    public void setParty_id(int party_id)
    {
        this.party_id = party_id;
    }
    
    public int getGuild_id()
    {
        return guild_id;
    }
    
    public void setGuild_id(int guild_id)
    {
        this.guild_id = guild_id;
    }
    
    public int getPet_id()
    {
        return pet_id;
    }
    
    public void setPet_id(int pet_id)
    {
        this.pet_id = pet_id;
    }
    
    public int getFame()
    {
        return fame;
    }
    
    public void setFame(int fame)
    {
        this.fame = fame;
    }
    
    public short getWeapon()
    {
        return weapon;
    }
    
    public void setWeapon(short weapon)
    {
        this.weapon = weapon;
    }
    
    public short getShield()
    {
        return shield;
    }
    
    public void setShield(short shield)
    {
        this.shield = shield;
    }
    
    public short getHead_top()
    {
        return head_top;
    }
    
    public void setHead_top(short head_top)
    {
        this.head_top = head_top;
    }
    
    public short getHead_mid()
    {
        return head_mid;
    }
    
    public void setHead_mid(short head_mid)
    {
        this.head_mid = head_mid;
    }
    
    public short getHead_bottom()
    {
        return head_bottom;
    }
    
    public void setHead_bottom(short head_bottom)
    {
        this.head_bottom = head_bottom;
    }
    
    public String getName()
    {
        return name;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public int getBase_level()
    {
        return base_level;
    }
    
    public void setBase_level(int base_level)
    {
        this.base_level = base_level;
    }
    
    public short getStr()
    {
        return str;
    }
    
    public void setStr(short str)
    {
        this.str = str;
    }
    
    public short getAgi()
    {
        return agi;
    }
    
    public void setAgi(short agi)
    {
        this.agi = agi;
    }
    
    public short getVit()
    {
        return vit;
    }
    
    public void setVit(short vit)
    {
        this.vit = vit;
    }
    
    public short getInt()
    {
        return int_;
    }
    
    public void setInt(short int_)
    {
        this.int_ = int_;
    }
    
    public short getDex()
    {
        return dex;
    }
    
    public void setDex(short dex)
    {
        this.dex = dex;
    }
    
    public short getLuk()
    {
        return luk;
    }
    
    public void setLuk(short luk)
    {
        this.luk = luk;
    }
    
    public char getChar_num()
    {
        return char_num;
    }
    
    public void setChar_num(char char_num)
    {
        this.char_num = char_num;
    }
    
    public char getSex()
    {
        return sex;
    }
    
    public void setSex(char sex)
    {
        this.sex = sex;
    }
    
    public long getMapip()
    {
        return mapip;
    }
    
    public void setMapip(long mapip)
    {
        this.mapip = mapip;
    }
    
    public int getMapport()
    {
        return mapport;
    }
    
    public void setMapport(int mapport)
    {
        this.mapport = mapport;
    }
    
    public Skill[] getSkills()
    {
        return skills;
    }
    
    public void setSkills(Skill[] skills)
    {
        this.skills = skills;
    }
    
    public Friend[] getFriends()
    {
        return friends;
    }
    
    public void setFriends(Friend[] friends)
    {
        this.friends = friends;
    }
    
    public Point getLast_point()
    {
        return last_point;
    }
    
    public void setLast_point(Point last_point)
    {
        this.last_point = last_point;
    }
    
    public Point getSave_point()
    {
        return save_point;
    }
    
    public void setSave_point(Point save_point)
    {
        this.save_point = save_point;
    }
    
}
