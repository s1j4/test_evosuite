/*
 * Item.java
 *
 * Created on 20 mai 2006, 23:05
 *
 * Copyright (c) 2006, Fran�ois Bradette
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of their contributors may be used to endorse or
 *       promote products derived from this software without specific prior
 *       written permission.
 *
 * This software is provided by the regents and contributors "as is" and any
 * express or implied warranties, including, but not limited to, the implied
 * warranties of merchantability and fitness for a particular purpose are
 * disclaimed.  In no event shall the regents and contributors be liable for any
 * direct, indirect, incidental, special, exemplary, or consequential damages
 * (including, but not limited to, procurement of substitute goods or services;
 * loss of use, data, or profits; or business interruption) however caused and
 * on any theory of liability, whether in contract, strict liability, or tort
 * (including negligence or otherwise) arising in any way out of the use of this
 * software, even if advised of the possibility of such damage.
 *
 * Translate from eAthena(c) by Fran�ois Bradette
 */


package core.data;

import core.utiles.Constants;

/**
 *
 * @author Darksid_1
 */
public class Item
{
    
    private int id;
    private short nameid;
    private short amount;
    private short equip;
    private char identify;
    private char refine;
    private char attribute;
    private short cards[];//[MAX_SLOTS];
    /** Creates a new instance of Item */
    public Item()
    {
        cards = new short[Constants.MAX_SLOTS];
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public short getNameid()
    {
        return nameid;
    }

    public void setNameid(short nameid)
    {
        this.nameid = nameid;
    }

    public short getAmount()
    {
        return amount;
    }

    public void setAmount(short amount)
    {
        this.amount = amount;
    }

    public short getEquip()
    {
        return equip;
    }

    public void setEquip(short equip)
    {
        this.equip = equip;
    }

    public char getIdentify()
    {
        return identify;
    }

    public void setIdentify(char identify)
    {
        this.identify = identify;
    }

    public char getRefine()
    {
        return refine;
    }

    public void setRefine(char refine)
    {
        this.refine = refine;
    }

    public char getAttribute()
    {
        return attribute;
    }

    public void setAttribute(char attribute)
    {
        this.attribute = attribute;
    }

    public short[] getCard()
    {
        return cards;
    }

    public void setCard(short[] cards)
    {
        this.cards = cards;
    }

    public void addCardAt(short card, int ind)
    {
        cards[ind] = card;
    }
    
}
