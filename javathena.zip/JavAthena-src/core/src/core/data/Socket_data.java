/**
 * Socket_data.java
 *
 * Created on September 22, 2005, 8:46 PM
 *
 * Copyright (c) 2006, Fran�ois Bradette
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of their contributors may be used to endorse or
 *       promote products derived from this software without specific prior
 *       written permission.
 *
 * This software is provided by the regents and contributors "as is" and any
 * express or implied warranties, including, but not limited to, the implied
 * warranties of merchantability and fitness for a particular purpose are
 * disclaimed.  In no event shall the regents and contributors be liable for any
 * direct, indirect, incidental, special, exemplary, or consequential damages
 * (including, but not limited to, procurement of substitute goods or services;
 * loss of use, data, or profits; or business interruption) however caused and
 * on any theory of liability, whether in contract, strict liability, or tort
 * (including negligence or otherwise) arising in any way out of the use of this
 * software, even if advised of the possibility of such damage.
 *
 * Translate from eAthena(c) by Fran�ois Bradette
 */


package core.data;

import java.util.Calendar;
import java.net.*;
import java.io.*;
/**
 *
 *@author darksid_1@htomail.com
 */
public class Socket_data implements Runnable
{
    private String name;
    private int account_id;
    private int maintenance;
    private int new_;
    private int eof;
    private String rdata;
    private String wdata;
    private int max_rdata;
    private int max_wdata;
    private int rdata_size;
    private int wdata_size;
    private int rdata_pos;
    private Calendar rdata_tick;
    private Socket client_addr;
    private Excecutable func_recv;
    private Excecutable func_send;
    private IParse func_parse;
    private Excecutable func_console;
    
    private String md5key;
    
    private SessionType type;
    private int users;
    private InputStream in;
    private OutputStream out;
    private Thread t;
    private int listenPort;
    
    public static final int PARSE_LOGIN = 2;
    public static final int PARSE_CHAR = 3;
    
    private int[] ip;
    
    
    public Socket_data()
    {
        
    }
    
    public Socket_data(Socket client_addr, IParse parsefunction)
    {
        this.func_parse = parsefunction;
        this.client_addr = client_addr;
        //UserManagement.addSession(this);
        
        try
        {
            if(client_addr!=null)
            {
                in = client_addr.getInputStream();
                out = client_addr.getOutputStream();
            }
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }
        t = new Thread(this);
        t.start();
    }
    /** Creates a new instance of Socket_data*/
    public Socket_data(Socket client_addr)
    {
        this(client_addr,null);
    }
    public void close()
    {
        
        try
        {
            in.close();
            out.close();
            if(!client_addr.isClosed())
                client_addr.close();
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }
    }
    public synchronized void run()
    {
        try
        {
            while(!client_addr.isClosed())
            {
                func_parse.parse(in.read(),this);
            }
        }
        catch (SocketException ex)
        {
            ex.printStackTrace();
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }
    }
    
    public int func_recv()
    {
        try
        {
            
            if(!client_addr.isClosed())
                return in.read();
            return -1;
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
            return -1;
        }
    }
    
    public int func_recv(byte tab[])
    {
        try
        {
            if(!client_addr.isClosed())
                return in.read(tab);
            return -1;
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
            return -1;
        }
    }
    
    public void func_send(byte byte_tab[])
    {
        try
        {
            
            if(!client_addr.isClosed())
                out.write(byte_tab);
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }
    }
    
    public void func_send(int []integers)
    {
        try
        {
            if(client_addr.isClosed())
                for(int i = 0;i < integers.length; i++)
                    out.write(integers[i]);
            
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }
    }
    
    public void func_send(int integer)
    {
        try
        {
            
            if(!client_addr.isClosed())
                out.write(integer);
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }
    }
    
    public int func_parse(int commande, Socket_data session) throws IOException
    {
        return func_parse.parse( commande,  session);
    }
    
    public Object func_console(Object... args)
    {
        return func_console.executeO(args);
    }
    
    public int getEof()
    {
        
        return eof;
    }
    
    public void setEof(int eof)
    {
        
        this.eof = eof;
        if(eof==1)
        {
            //UserManagement.getRemoveSessions(this);
//            UserManagement.unLogServer(this);
            close();
        }
    }
    
    public String getRdata()
    {
        return rdata;
    }
    
    public void setRdata(String rdata)
    {
        this.rdata = rdata;
    }
    
    public String getWdata()
    {
        return wdata;
    }
    
    public void setWdata(String wdata)
    {
        this.wdata = wdata;
    }
    
    public int getMax_rdata()
    {
        return max_rdata;
    }
    
    public void setMax_rdata(int max_rdata)
    {
        this.max_rdata = max_rdata;
    }
    
    public int getMax_wdata()
    {
        return max_wdata;
    }
    
    public void setMax_wdata(int max_wdata)
    {
        this.max_wdata = max_wdata;
    }
    
    public int getRdata_size()
    {
        return rdata_size;
    }
    
    public void setRdata_size(int rdata_size)
    {
        this.rdata_size = rdata_size;
    }
    
    public int getWdata_size()
    {
        return wdata_size;
    }
    
    public void setWdata_size(int wdata_size)
    {
        this.wdata_size = wdata_size;
    }
    
    public int getRdata_pos()
    {
        return rdata_pos;
    }
    
    public void setRdata_pos(int rdata_pos)
    {
        this.rdata_pos = rdata_pos;
    }
    
    public Calendar getRdata_tick()
    {
        return rdata_tick;
    }
    
    public void setRdata_tick(Calendar rdata_tick)
    {
        this.rdata_tick = rdata_tick;
    }
    
    public Socket getClient_addr()
    {
        return client_addr;
    }
    
    public void setClient_addr(Socket client_addr)
    {
        if(client_addr!=null)
        {
            this.client_addr = client_addr;
            try
            {
                in = client_addr.getInputStream();
                out = client_addr.getOutputStream();
            }
            catch(IOException ex)
            {
                ex.printStackTrace();
            }
        }
    }
    
    public Excecutable getFunc_recv()
    {
        return func_recv;
    }
    
    public void setFunc_recv(Excecutable func_recv)
    {
        this.func_recv = func_recv;
    }
    
    public Excecutable getFunc_send()
    {
        return func_send;
    }
    
    public void setFunc_send(Excecutable func_send)
    {
        this.func_send = func_send;
    }
    
    public IParse getFunc_parse()
    {
        return func_parse;
    }
    
    public void setFunc_parse(IParse func_parse)
    {
        this.func_parse = func_parse;
    }
    
    public Excecutable getFunc_console()
    {
        return func_console;
    }
    
    public void setFunc_console(Excecutable func_console)
    {
        this.func_console = func_console;
    }
    
    public SessionType getType()
    {
        return type;
    }
    
    public void setType(SessionType type)
    {
        this.type = type;
    }
    
    public int getUsers()
    {
        return users;
    }
    
    public void setUsers(int users)
    {
        this.users = users;
    }
    
    public int getNew_()
    {
        return new_;
    }
    
    public void setNew_(int new_)
    {
        this.new_ = new_;
    }
    
    public int getMaintenance()
    {
        return maintenance;
    }
    
    public void setMaintenance(int maintenance)
    {
        this.maintenance = maintenance;
    }
    
    public String getName()
    {
        return name;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public void setIp(int[] ip)
    {
        this.ip = ip;
    }
    
    public int getListenPort()
    {
        return listenPort;
    }
    
    public void setListenPort(int listenPort)
    {
        this.listenPort = listenPort;
    }
    
    public Integer getAccount_id()
    {
        return account_id;
    }
    
    public void setAccount_id(int account_id)
    {
        this.account_id = account_id;
    }
    
    public String getMd5key()
    {
        return md5key;
    }
    
    public void setMd5key(String md5key)
    {
        this.md5key = md5key;
    }
    
    
    public String getIpStr()
    {
        return client_addr.getLocalAddress().getHostAddress();
    }
    
    
    
}
