/*
 * CharacterManagement.java
 *
 * Created on 27 novembre 2006, 12:23
 *
 * Copyright (c) 2006, Fran�ois Bradette
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of their contributors may be used to endorse or
 *       promote products derived from this software without specific prior
 *       written permission.
 *
 * This software is provided by the regents and contributors "as is" and any
 * express or implied warranties, including, but not limited to, the implied
 * warranties of merchantability and fitness for a particular purpose are
 * disclaimed.  In no event shall the regents and contributors be liable for any
 * direct, indirect, incidental, special, exemplary, or consequential damages
 * (including, but not limited to, procurement of substitute goods or services;
 * loss of use, data, or profits; or business interruption) however caused and
 * on any theory of liability, whether in contract, strict liability, or tort
 * (including negligence or otherwise) arising in any way out of the use of this
 * software, even if advised of the possibility of such damage.
 *
 * Translate from eAthena(c) by Fran�ois Bradette
 */
package javathena.login;

//Sun jdk
import java.io.*;
import java.sql.SQLException;
import java.net.*;
import java.util.Calendar;
import java.util.StringTokenizer;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


//JavAthena
import javathena.donne.*;
import javathena.login.parse.ParseLogin;
import core.utiles.*;
import core.data.Auth_data;
import core.utiles.Version;
import core.utiles.sql.MySQLConfig;
import javathena.donne.IDBManagementLogin;
import core.data.Socket_data;
import core.data.Global_reg;
import core.utiles.ACO;
import javolution.util.FastTable;

/**
 *
 * @author Francois
 */
public class Login
{
    
    class Timer_interval_GM_file extends TimerTask
    {
        
        public Timer_interval_GM_file()
        {
        }
        
        public void run()
        {
            UserManagement.check_GM_file();
        }
    }
    
    class Timer_interval_check_auth_sync extends TimerTask
    {
        public Timer_interval_check_auth_sync( )
        {
            
        }
        public void run()
        {
            check_auth_sync();
        }
    }
    
    class End extends Thread
    {
        public End()
        {
        }
        
        // traitement qui sera effectue suite d'une interruption du programme
        public void run()
        {
            do_final();
        }
    }
    
    
    /*enum  ACF
    {
        DEF, ALLOW, DENY
    }
    //*auth_dat = NULL;*/
    
    public static final int MAX_SERVERS = 30;
    public static final String LOGIN_CONF_NAME = "conf/login_athena.conf";
    public static final String LAN_CONF_NAME = "conf/subnet_athena.conf";
    //public static final int PASSWORDENC = 3;
    public static final int START_ACCOUNT_NUM = 2000000;
    public static final int END_ACCOUNT_NUM = 100000000;
    
    
    
    public static final int AUTH_BEFORE_SAVE_FILE = 10;
    public static final int AUTH_SAVE_FILE_DIVIDER = 50;
    public static final int DEFAULT_PASSWORDENC = 2;//System.getProperty("PASSWORDENC") != null;
    private static int PASSWORDENC = DEFAULT_PASSWORDENC;//System.getProperty("PASSWORDENC") != null;
    
    private static  File log_fp;
    protected static PrintWriter loginLogOut;
    protected static int auth_num = 0;
    protected int auth_max = 0;
    protected int server_fd[];
    private final ExecutorService pool;
    
    //according to the save method
    public static IDBManagementLogin dbManagemtType;
    
    
    /** Creates a new instance of Login int server_fd*/
    
    public Login()
    {
        
        Runtime.getRuntime().addShutdownHook(new End());
        String PASSWORDENCtmp = System.getProperty("PASSWORDENC");
        if(PASSWORDENCtmp != null && !PASSWORDENCtmp.equals(""))
        {
            PASSWORDENC = Integer.parseInt(PASSWORDENCtmp);
        }
        
        ConfigurationManagement.setGMMax(4000);
        
        setServer_fd(new int [MAX_SERVERS]);
        UserManagement.setAccountIdCount(START_ACCOUNT_NUM);
        ConfigurationManagement.setNew_account_flag(0);
        
        ConfigurationManagement.setBind_ip_str("127.0.0.1");
        ConfigurationManagement.setLan_char_ip("");
        ConfigurationManagement.setSubneti(new int[4]);
        ConfigurationManagement.setSubnetmaski(new int[4]);
        
        ConfigurationManagement.setAccount_filename("save/account.txt");
        ConfigurationManagement.setGM_account_filename("conf/GM_account.txt");
        ConfigurationManagement.setLogin_log_filename("log/login.log");
        
        setLog_fp(null);
        
        ConfigurationManagement.setLogin_log_unknown_packets_filename("log/login_unknown_packets.log");
        ConfigurationManagement.setSave_unknown_packets(0);
        ConfigurationManagement.setGm_account_filename_check_timer(15);
        
        ConfigurationManagement.setLog_login(true);
        ConfigurationManagement.setDisplay_parse_login(false);
        ConfigurationManagement.setDisplay_parse_admin(false);
        ConfigurationManagement.setDisplay_parse_fromchar(0);
        
        ConfigurationManagement.setNew_reg_tick(0);
        ConfigurationManagement.setAllowed_regs(1);
        ConfigurationManagement.setTime_allowed(10);
        
        ConfigurationManagement.setAccess_order(ACO.DENY_ALLOW);
        ConfigurationManagement.setAccess_allownum(0);
        ConfigurationManagement.setAccess_denynum(0);
        ConfigurationManagement.setAccess_allow(null);
        ConfigurationManagement.setAccess_deny(null);
        
        
        ConfigurationManagement.setAccess_ladmin_allownum(0);
        ConfigurationManagement.setAccess_ladmin_allow(null);
        
        ConfigurationManagement.setMin_level_to_connect(0);
        ConfigurationManagement.setAdd_to_unlimited_account(0);
        ConfigurationManagement.setStart_limited_time(-1);
        ConfigurationManagement.setCheck_ip_flag(1);
        
        ConfigurationManagement.setCheck_client_version(false);
        ConfigurationManagement.setClient_version_to_connect(20);
        pool = Executors.newFixedThreadPool(this.MAX_SERVERS);
        //ResourceBundle lang = java.util.ResourceBundle.getBundle("javathena/lang/" + Fonctions.LANG);
        
    }
    

    
    public static void login_log(String message)
    {
        if(ConfigurationManagement.isLog_login())
        {
            loginLogOut.println(Functions.calendarToString(Calendar.getInstance())+": " + message);
        }
    }
    
    private static void login_log(String format, Object... args)
    {
        if(ConfigurationManagement.isLog_login())
        {
            loginLogOut.printf( Functions.calendarToString(Calendar.getInstance())+": "+format ,args);
            loginLogOut.println();
        }
        
    }
    //Not implemented yet
    public int check_ipmask( int ip,String str)
    {
        return 0;
    }
     /*
      * @param  ip
      *         An InetAddress to check
      *
      * @throws  NullPointerException
      *          If the <tt>ip</tt> is <tt>null</tt>
      */
    public  boolean check_ip(InetAddress ip)
    {
        try
        {
            return ip.isReachable(180);
        }
        catch(IOException ex)
        {
            Functions.showError(ex.getMessage());
            return false;
        }
    }
    
    
    
// database version reading (v2)
// only
    public static int mmo_auth_initTXT()
    {
        
        File fp;
        int account_id;
        String userid;
        int server_count = 0;
        
        fp = new File(ConfigurationManagement.getAccount_filename());
        if(!fp.exists())
        {
            Functions.showError(MultilanguageManagement.getError_1(),ConfigurationManagement.getAccount_filename());
        }
        try
        {
            BufferedReader in  = new BufferedReader(new FileReader(fp));
            String ligne =null;
            ligne = in.readLine();
            while(ligne != null)
            {
                if(ligne.indexOf("//") !=-1 )
                {
                    ligne = ligne.substring(0,ligne.indexOf("//"));
                }
                if(ligne.length() > 0)
                {
                    StringTokenizer ligneTk = new StringTokenizer(ligne,"\t");
                    try
                    {
                        account_id = Integer.parseInt(ligneTk.nextElement().toString());
                        if(account_id > END_ACCOUNT_NUM)
                        {
                            Functions.showError(MultilanguageManagement.getError_2(), END_ACCOUNT_NUM, account_id);
                            dbManagemtType.login_log("","","0",
                                    String.format(MultilanguageManagement.getError_2(), END_ACCOUNT_NUM, account_id, ligne));
                        }
                        else
                        {
                            userid = ligneTk.nextElement().toString().trim();
                            if(Login.dbManagemtType.getUser(account_id)!=null)
                                //if(auth_dats.get(account_id)!=null)
                            {
                                Functions.showError(MultilanguageManagement.getError_3(), account_id);
                                dbManagemtType.login_log("","","0",
                                        String.format(MultilanguageManagement.getError_3(), account_id,ligne.replaceAll("%","%%")));
                            }
                            else
                                if(Login.dbManagemtType.getUser(userid)!=null)
                                {
                                Functions.showError(MultilanguageManagement.getError_4(), userid);
                                dbManagemtType.login_log("",userid,"0",
                                        String.format(MultilanguageManagement.getError_4(),
                                        userid,ligne));
                                }
                                else
                                {
                                Auth_data new_account = new Auth_data();
                                //ID, account name,
                                
                                if(userid.equals("%newid%"))
                                {
                                    if(account_id > UserManagement.getAccountIdCount())
                                        UserManagement.setAccountIdCount(account_id);
                                    break;
                                }
                                new_account.setAccount_id(account_id);
                                new_account.setUserid(userid);
                                // password,
                                new_account.setPass(ligneTk.nextElement().toString());
                                //last login time,
                                Calendar lastlogin = Calendar.getInstance();
                                String anneeS = ligneTk.nextElement().toString();
                                if(anneeS.charAt(0)!='0')
                                {
                                    StringTokenizer date_str = new StringTokenizer(anneeS, "-.: ");
                                    int annee = 0;
                                    int mois = 0;
                                    int jour = 0;
                                    
                                    int heur = 0;
                                    int minute = 0;
                                    int seconde = 0;
                                    if(date_str.hasMoreElements())
                                    {
                                        annee = Integer.parseInt( date_str.nextElement().toString());
                                        mois = Integer.parseInt( date_str.nextElement().toString());
                                        jour = Integer.parseInt( date_str.nextElement().toString());
                                        
                                        heur = Integer.parseInt( date_str.nextElement().toString());
                                        minute = Integer.parseInt( date_str.nextElement().toString());
                                        seconde = Integer.parseInt( date_str.nextElement().toString());
                                    }
                                    int milisec = 0;
                                    if(date_str.hasMoreElements())
                                        milisec = Integer.parseInt( date_str.nextElement().toString());
                                    
                                    lastlogin.set(annee, mois, jour, heur, minute, seconde);
                                    lastlogin.set(Calendar.MILLISECOND, milisec);
                                    new_account.setLastlogin(lastlogin);
                                }
                                //sex,
                                char s = ligneTk.nextElement().toString().toUpperCase().charAt(0);
                                new_account.setSex(Functions.charSexToInt(s));
                                
                                //# of logins
                                new_account.setLogincount(Integer.parseInt( ligneTk.nextElement().toString()));
                                //, state
                                new_account.setState(Integer.parseInt( ligneTk.nextElement().toString()));
                                //, email
                                String e_mail = ligneTk.nextElement().toString();
                                if (!Functions.e_mail_check(e_mail))
                                {
                                    Functions.showNotice(MultilanguageManagement.getNotice_1(),new_account.getUserid(),new_account.getAccount_id());
                                    new_account.setEmail(Constants.DEFAULT_EMAIL);
                                }
                                else
                                {
                                    new_account.setEmail(e_mail);
                                }
                                //, error message for state 7,
                                String error = ligneTk.nextElement().toString();
                                if(new_account.getState() != 7 )
                                    new_account.setError_message("-");
                                else
                                    new_account.setError_message(error);
                                //validity time
                                Calendar untils_time = Calendar.getInstance();
                                anneeS = ligneTk.nextElement().toString();
                                
                                untils_time.setTimeInMillis(Long.parseLong( anneeS));
                                
                                new_account.setConnect_until_time(untils_time);
                                
                                //, last (accepted) login ip,
                                String ip = ligneTk.nextElement().toString();
                                InetAddress tmpInetAddress = null;
                                if(ip.charAt(0) != '-')
                                {
                                    new_account.setLast_ip( ip);
                                }
                                //memo field,
                                
                                String tmp = ligneTk.nextElement().toString();
                                new_account.setMemo(tmp);
                                
                                // ban timestamp,
                                Calendar ban_time = Calendar.getInstance();
                                anneeS = ligneTk.nextElement().toString();
                                if(anneeS.charAt(0)!='0')
                                {
                                    ban_time.setTimeInMillis(Long.parseLong( anneeS));
                                }
                                else
                                {
                                    ban_time.setTimeInMillis(0);
                                }
                                new_account.setBan_until_time(ban_time);
                                // repeated(register text, register value)
                                int i = 0;
                                while(ligneTk.hasMoreElements() && i < Constants.ACCOUNT_REG2_NUM)
                                {
                                    String str1 = ligneTk.nextElement().toString();
                                    String value =  ligneTk.nextElement().toString();
                                    if(str1 != null && str1.length()!=0)
                                        new_account.getAccount_reg2()[i++] = new Global_reg(str1, value);
                                }
                                
                                if (new_account.getSex() == 2)
                                    server_count++;
                                
                                auth_num++;
                                if (account_id >= UserManagement.getAccountIdCount())
                                    UserManagement.addAccountIdCount();
                                
                                
                                UserManagement.addUser(new_account);
                                }
                        }
                    }
                    catch(NullPointerException ex)
                    {
                        Functions.showError(MultilanguageManagement.getError_5(),ex.getMessage() );
                    }
                }
                ligne = in.readLine();
            }
            switch(UserManagement.getNBUser())
            {
                case 0:
                    Functions.showNotice(MultilanguageManagement.getNotice_2(),ConfigurationManagement.getAccount_filename());
                    dbManagemtType.login_log("","","0",
                            String.format(MultilanguageManagement.getNotice_2(),ConfigurationManagement.getAccount_filename()+"."));
                    break;
                case 1:
                    Functions.showNotice(MultilanguageManagement.getNotice_3(),ConfigurationManagement.getAccount_filename());
                    dbManagemtType.login_log("","","",
                            String.format(MultilanguageManagement.getNotice_3(),ConfigurationManagement.getAccount_filename()));
                    break;
                default:
                    Functions.showNotice(MultilanguageManagement.getNotice_4(),UserManagement.getNBUser(),ConfigurationManagement.getAccount_filename());
                    dbManagemtType.login_log("","","",
                            String.format(MultilanguageManagement.getNotice_4(),UserManagement.getNBUser(),ConfigurationManagement.getAccount_filename()));
            }
            //this.getGm_account_db ()
            switch(UserManagement.getNBGM())
            {
                case 0:
                    Functions.showNotice(MultilanguageManagement.getNotice_5());
                    dbManagemtType.login_log("","","0",
                            String.format(MultilanguageManagement.getNotice_5()+ConfigurationManagement.getAccount_filename()+"."));
                    break;
                case 1:
                    Functions.showNotice(MultilanguageManagement.getNotice_6());
                    dbManagemtType.login_log("","","0",
                            String.format(MultilanguageManagement.getNotice_6()));
                    break;
                default:
                    Functions.showNotice(MultilanguageManagement.getNotice_7(),UserManagement.getNBGM());
                    dbManagemtType.login_log("","","0",
                            String.format(MultilanguageManagement.getNotice_7(),UserManagement.getNBGM()));
            }
            switch(server_count)
            {
                case 0:
                    Functions.showNotice(MultilanguageManagement.getNotice_8());
                    dbManagemtType.login_log("","","0",
                            String.format(MultilanguageManagement.getNotice_8()));
                    break;
                case 1:
                    Functions.showNotice(MultilanguageManagement.getNotice_9());
                    dbManagemtType.login_log("","","0",
                            String.format(MultilanguageManagement.getNotice_9()));
                    break;
                default:
                    Functions.showNotice(MultilanguageManagement.getNotice_10(),server_count );
                    dbManagemtType.login_log("","","0",
                            String.format(MultilanguageManagement.getNotice_10(),server_count));
            }
            in.close();
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
            Functions.showError(ex.getMessage());
        }
        return 0;
    }
    
    /**------------------------------------------
     * // Writing of the accounts database file
     * //   (accounts are sorted by id before save)
     * //------------------------------------------*/
    public static void mmo_auth_syncTXT()
    {
        File account_fp = new File(ConfigurationManagement.getAccount_filename());
        
        FastTable col = UserManagement.getAccountIds();
        col.sort();
        try
        {
            PrintWriter outAcc  = new PrintWriter(new FileWriter(account_fp));
            outAcc.println("// Accounts file: here are saved all information about the accounts.\n"+
                    "// Structure: ID, account name, password, last login time, sex, # of logins, state, email, error message for state 7, validity time, last (accepted) login ip, memo field, ban timestamp, repeated(register text, register value)\n"+
                    "// Some explanations:\n"+
                    "//   account name    : between 4 to 23 char for a normal account (standard client can't send less than 4 char).\n"+
                    "//   account password: between 4 to 23 char\n"+
                    "//   sex             : M or F for normal accounts, S for server accounts\n"+
                    "//   state           : 0: account is ok, 1 to 256: error code of packet 0x006a + 1\n"+
                    "//   email           : between 3 to 39 char (a@a.com is like no email)\n"+
                    "//   error message   : text for the state 7: 'Your are Prohibited to login until <text>'. Max 19 char\n"+
                    "//   valitidy time   : 0: unlimited account, <other value>: date calculated by addition of 1/1/1970 + value (number of seconds since the 1/1/1970)\n"+
                    "//   memo field      : max 254 char\n"+
                    "//   ban time        : 0: no ban, <other value>: banned until the date: date calculated by addition of 1/1/1970 + value (number of seconds since the 1/1/1970)\n");
            outAcc.flush();
            for(int i=0 ;i<UserManagement.getNBUser();i++)
            {
                
                if((Integer)col.get(i) >= 0)
                    outAcc.println(UserManagement.getUserTxt((Integer)col.get(i)));
                outAcc.flush();
            }
            outAcc.println(UserManagement.getAccountIdCount()+ "\t%newid%");
            
            ConfigurationManagement.setAuth_before_save_file(UserManagement.getNBUser() / AUTH_SAVE_FILE_DIVIDER);
            if (ConfigurationManagement.getAuth_before_save_file() < Login.AUTH_BEFORE_SAVE_FILE)
                ConfigurationManagement.setAuth_before_save_file(Login.AUTH_BEFORE_SAVE_FILE);
            
            outAcc.close();
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }
        
    }
    /**-----------------------------------------------------
     * // Check if we must save accounts file or not
     * //   every minute, we check if we must save because we
     * //   have do some authentifications without arrive to
     * //   the minimum of authentifications for the save.
     * // Note: all other modification of accounts (deletion,
     * //       change of some informations excepted lastip/
     * //       lastlogintime, creation) are always save
     * //       immediatly and set  the minimum of
     * //       authentifications to its initialization value.
     * //-----------------------------------------------------*/
    public  int check_auth_sync()
    {
        // we only save if necessary:
        // we have do some authentifications without do saving
        if (ConfigurationManagement.getAuth_before_save_file() < Login.AUTH_BEFORE_SAVE_FILE ||
                ConfigurationManagement.getAuth_before_save_file() < (int)(UserManagement.getNBUser() / Login.AUTH_SAVE_FILE_DIVIDER))
        {
            dbManagemtType.mmo_auth_sync();
        }
        
        return 0;
    }
    
    /**---------------------------------------
     * // Packet parsing for administation login
     * //---------------------------------------*/
    public int parse_admin(int commande, Socket_data session, Login hote)
    {
        InetAddress sin_addr = session.getClient_addr().getInetAddress();
        String ip = sin_addr.getHostAddress();
        
        if (session.getEof() == 1)
        {
            Functions.showNotice(MultilanguageManagement.getNotice_11(),session.getAccount_id());
            return 0;
        }
        
        commande += session.func_recv();
        
        while(commande != -1)
        {
            commande += session.func_recv()*256;
            switch(commande)
            {
                case -1:
                    return 0;
                case 0x7530:
                    Functions.showWarning(commande + " parse_admin : niy");
                case 0x7532:
                    Functions.showWarning(commande + " parse_admin : niy");
                case 0x7920:
                    Functions.showWarning(commande + " parse_admin : niy");
                case 0x7930:
                    Functions.showWarning(commande + " parse_admin : niy");
                case 0x7932:
                    Functions.showWarning(commande + " parse_admin : niy");
                case 0x7934:
                    Functions.showWarning(commande + " parse_admin : niy");
                case 0x7936:
                    Functions.showWarning(commande + " parse_admin : niy");
                case 0x7938:
                    Functions.showWarning(commande + " parse_admin : niy");
                case 0x793a:
                    Functions.showWarning(commande + " parse_admin : niy");
                case 0x793c:
                    Functions.showWarning(commande + " parse_admin : niy");
                case 0x793e:
                    Functions.showWarning(commande + " parse_admin : niy");
                case 0x7940:
                    Functions.showWarning(commande + " parse_admin : niy");
                case 0x7942:
                    Functions.showWarning(commande + " parse_admin : niy");
                case 0x7944:
                    Functions.showWarning(commande + " parse_admin : niy");
                case 0x7946:
                    Functions.showWarning(commande + " parse_admin : niy");
                case 0x7948:
                    Functions.showWarning(commande + " parse_admin : niy");
                case 0x794a:
                    Functions.showWarning(commande + " parse_admin : niy");
                case 0x794c:
                    Functions.showWarning(commande + " parse_admin : niy");
                case 0x794e:
                    Functions.showWarning(commande + " parse_admin : niy");
                case 0x7950:
                    Functions.showWarning(commande + " parse_admin : niy");
                case 0x7952:
                    Functions.showWarning(commande + " parse_admin : niy");
                case 0x7954:
                    Functions.showWarning(commande + " parse_admin : niy");
                case 0x7955:
                    System.out.println("L'administration a distance n'est pas implementer");
            }
            commande = session.func_recv();
        }
        return 0;
    }
    
/*    public int lan_ip_check(String p)
    {
        int i;
        int lancheck = 1;
        return lancheck;
    }*/
    
    /**-----------------------
     * // Console Command Parser [Wizputer]
     * //-----------------------**/
    public int parse_console(String command)
    {
        dbManagemtType.login_log("","","",
                String.format("Console command : '%s'", command));
        
        
        if(command.equals("shutdown") ||
                command.equals("exit") ||
                command.equals("quit") ||
                command.equals("end") )
            System.exit(0);
        else
            if(command.equals("alive") ||
                command.equals("status") )
                Functions.showNotice(MultilanguageManagement.getNotice_12());
            else
                if(command.equals("help"))
                {
            System.out.printf("\033[32mHelp of commands:\033[0m");
            System.out.printf("  To shutdown the server:");
            System.out.printf("  'shutdown|exit|qui|end'");
            System.out.printf("  To know if server is alive:");
            System.out.printf("  'alive|status'");
                }
        
        return 0;
    }
    
//----------------------------------
// Reading Lan Support configuration
//----------------------------------
    public void save_config_in_log()
    {
        int i;
        loginLogOut = Functions.open_log(ConfigurationManagement.getLogin_log_filename());
        // a newline in the log...
        login_log("");
        login_log("The login-server starting..." );
        
        // save configuration in log file
        login_log("The configuration of the server is set:" );
        
        if (ConfigurationManagement.getAdmin_state() != 1)
            login_log("- with no remote administration." );
        else if (ConfigurationManagement.getAdmin_pass() == null)
            login_log("- with a remote administration with a VOID password." );
        else if (ConfigurationManagement.getAdmin_pass() .equals("admin"))
            login_log("- with a remote administration with the DEFAULT password." );
        else
            login_log("- with a remote administration with the password of %d character(s).", ConfigurationManagement.getAdmin_pass().length());
        if (ConfigurationManagement.getAccess_ladmin_allownum() == 0 || (ConfigurationManagement.getAccess_ladmin_allownum() == 1 && ConfigurationManagement.getAccess_allow() == null))
        {
            login_log("- to accept any IP for remote administration" );
        }
        else
        {
            login_log("- to accept following IP for remote administration:" );
            for(i = 0; i < ConfigurationManagement.getAccess_ladmin_allownum(); i++)
                login_log(ConfigurationManagement.getAccess_ladmin_allow());
        }
        
        if (ConfigurationManagement.getGm_pass() == null)
            login_log("- with a VOID 'To GM become' password (gm_pass)." );
        else if (ConfigurationManagement.getGm_pass().equals("gm"))
            login_log("- with the DEFAULT 'To GM become' password (gm_pass)." );
        else
            login_log("- with a 'To GM become' password (gm_pass) of %d character(s).",ConfigurationManagement.getGm_pass().length() );
        if (ConfigurationManagement.getLevel_new_gm() == 0)
            login_log("- to refuse any creation of GM with @gm." );
        else
        {
            int level = ConfigurationManagement.getLevel_new_gm() ;
            login_log("- to create GM with level %d when @gm is used.",level);
        }
        
        if (ConfigurationManagement.getNew_account_flag() == 1)
            login_log("- to ALLOW new users (with _F/_M)." );
        else
            login_log("- to NOT ALLOW new users (with _F/_M)." );
        login_log("- with port: %d.",ConfigurationManagement.getLogin_port());
        login_log("- with the accounts file name: '%s'.",ConfigurationManagement.getAccount_filename());
        login_log("- with the GM accounts file name: '%s'.",ConfigurationManagement.getGM_account_filename());
        if (ConfigurationManagement.getGm_account_filename_check_timer() == 0)
            login_log("- to NOT check GM accounts file modifications." );
        else
            login_log("- to check GM accounts file modifications every %d seconds.",ConfigurationManagement.getGm_account_filename_check_timer());
        if (ConfigurationManagement.getUse_MD5_passwords() == 0)
            login_log("- to save password in plain text." );
        else
            login_log("- to save password with MD5 encrypting." );
        
        // not necessary to log the 'login_log_filename', we are inside :)
        
        login_log("- with the unknown packets file name: '%s'.",ConfigurationManagement.getLogin_log_unknown_packets_filename());
        if (ConfigurationManagement.getSave_unknown_packets() == 1)
            login_log("- to SAVE all unkown packets." );
        else
            login_log("- to SAVE only unkown packets sending by a char-server or a remote administration." );
        if (ConfigurationManagement.isDisplay_parse_login())
            login_log("- to display normal parse packets on console." );
        else
            login_log("- to NOT display normal parse packets on console." );
        if (ConfigurationManagement.isDisplay_parse_admin())
            login_log("- to display administration parse packets on console." );
        else
            login_log("- to NOT display administration parse packets on console." );
        if (ConfigurationManagement.getDisplay_parse_fromchar() == 1)
            login_log("- to display char-server parse packets on console." );
        else
            login_log("- to NOT display char-server parse packets on console." );
        
        if (ConfigurationManagement.getMin_level_to_connect()== 0) // 0: all players, 1-99 at least gm level x
            login_log("- with no minimum level for connection." );
        else if (ConfigurationManagement.getMin_level_to_connect() == 99)
            login_log("- to accept only GM with level 99." );
        else
            login_log("- to accept only GM with level %d or more.", ConfigurationManagement.getMin_level_to_connect());
        
        if (ConfigurationManagement.getAdd_to_unlimited_account() == 1)
            login_log("- to authorize adjustment (with timeadd ladmin) on an unlimited account." );
        else
            login_log("- to refuse adjustment (with timeadd ladmin) on an unlimited account. You must use timeset (ladmin command) before." );
        
        if (ConfigurationManagement.getStart_limited_time() < 0)
            login_log("- to create new accounts with an unlimited time." );
        else if (ConfigurationManagement.getStart_limited_time()  == 0)
            login_log("- to create new accounts with a limited time: time of creation." );
        else
            login_log("- to create new accounts with a limited time: time of creation %d second(s).", ConfigurationManagement.getStart_limited_time());
        
        if (ConfigurationManagement.getCheck_ip_flag() == 1)
            login_log("- with control of players IP between login-server and char-server." );
        else
            login_log("- to not check players IP between login-server and char-server." );
        
        if (ConfigurationManagement.getAccess_order() == ACO.DENY_ALLOW)
        {
            if (ConfigurationManagement.getAccess_denynum() == 0)
            {
                login_log("- with the IP security order: 'deny,allow' (allow if not deny). You refuse no IP." );
            }
            else if (ConfigurationManagement.getAccess_denynum() == 1 && ConfigurationManagement.getAccess_deny() == null)
            {
                login_log("- with the IP security order: 'deny,allow' (allow if not deny). You refuse ALL IP." );
            }
            else
            {
                login_log("- with the IP security order: 'deny,allow' (allow if not deny). Refused IP are:" );
                for(i = 0; i < ConfigurationManagement.getAccess_denynum(); i++)
                    login_log(ConfigurationManagement.getAccess_deny());
            }
        }
        else if (ConfigurationManagement.getAccess_order() == ACO.ALLOW_DENY)
        {
            if (ConfigurationManagement.getAccess_allownum() == 0)
            {
                login_log("- with the IP security order: 'allow,deny' (deny if not allow). But, NO IP IS AUTHORISED!" );
            }
            else if (ConfigurationManagement.getAccess_allownum() == 1 && ConfigurationManagement.getAccess_allow() == null)
            {
                login_log("- with the IP security order: 'allow,deny' (deny if not allow). You authorise ALL IP." );
            }
            else
            {
                login_log("- with the IP security order: 'allow,deny' (deny if not allow). Authorised IP are:" );
                for(i = 0; i < ConfigurationManagement.getAccess_denynum(); i++)
                    login_log(ConfigurationManagement.getAccess_deny());
            }
        }
        else
        { // ACO_MUTUAL_FAILTURE
            login_log("- with the IP security order: 'mutual-failture' (allow if in the allow list and not in the deny list)." );
            if (ConfigurationManagement.getAccess_allownum() == 0)
            {
                login_log("  But, NO IP IS AUTHORISED!" );
            }
            else if(ConfigurationManagement.getAccess_denynum() == 1 && ConfigurationManagement.getAccess_deny() == null)
            {
                login_log("  But, you refuse ALL IP!" );
            }
            else
            {
                if (ConfigurationManagement.getAccess_allownum() == 1 && ConfigurationManagement.getAccess_allow() == null)
                {
                    login_log("  You authorise ALL IP." );
                }
                else
                {
                    for(i = 0; i < ConfigurationManagement.getAccess_denynum(); i++)
                        login_log(ConfigurationManagement.getAccess_deny());
                }
                login_log("  Refused IP are:" );
                for(i = 0; i < ConfigurationManagement.getAccess_denynum(); i++)
                    login_log(ConfigurationManagement.getAccess_deny());
            }
            
            // dynamic password error ban
            if (ConfigurationManagement.getDynamic_pass_failure_ban())
                login_log("- with NO dynamic password error ban." );
            else
            {
                login_log("- with a dynamic password error ban:" );
                login_log("  After %d invalid password in %d minutes",ConfigurationManagement.getDynamic_pass_failure_ban_how_many(),ConfigurationManagement.getDynamic_pass_failure_ban_time());
                login_log("  IP is banned for %d minutes", ConfigurationManagement.getDynamic_pass_failure_ban_how_long());
            }
        }
    }
    
    public void do_final()
    {
        int i, fd;
        dbManagemtType.mmo_auth_sync();
        Functions.showInfo(MultilanguageManagement.getNotice_13());
        
        
        for (i = 0; i < UserManagement.getNBSession(); i++)
            UserManagement.getSessionAt(i).setEof(-1);
        dbManagemtType.login_log("","","0","----End of login-server (normal end with closing of all files).");
        if(loginLogOut != null)
        {
            loginLogOut.flush();
            loginLogOut.close();
        }
        Functions.showStatus("Finished.");
    }
    
    public int do_init( )
    {
        int i = 0;
        
        MultilanguageManagement.init();
        // read login-server configuration
        ConfigurationManagement.login_config_read((System.getProperty("LOGIN_CONF_NAME") != null && !System.getProperty("LOGIN_CONF_NAME").equals("")) ? System.getProperty("LOGIN_CONF_NAME") : LOGIN_CONF_NAME);
        ConfigurationManagement.display_conf_warnings(); // not in login_config_read, because we can use 'import' option, and display same message twice or more
        
        try
        {
            switch(Constants.DB_MODE)
            {
                case Constants.DB_TXT:
                    dbManagemtType = new TXTDBManagement();
                    dbManagemtType.readGMAccount();
                    save_config_in_log(); // not before, because log file name can be changed
                    mmo_auth_initTXT();
                    Timer t = new Timer("sauvegarde");
                    t.schedule(new Timer_interval_GM_file(), 60000, 60000);
                    t.schedule(new Timer_interval_check_auth_sync(), 60000, 60000);
                    break;
                case Constants.DB_MYSQL:
                    dbManagemtType = new MySQLDBManagement();
                    Functions.showInfo("Initializing md5key...");
                    MySQLConfig.setMd5key(Functions.getMd5String());
                    Functions.showInfo("md5key setup complete");
                    try
                    {
                        MySQLConfig.sql_config_read(MySQLConfig.SQL_CONF_NAME);
                        dbManagemtType.readGMAccount();
                    }
                    catch (SQLException ex)
                    {
                        ex.printStackTrace();
                    }
                    catch (ClassNotFoundException ex)
                    {
                        ex.printStackTrace();
                    }
                    //ban deleter timer - 1 minute term
                    /*Functions.showStatus("add interval tic (ip_ban_check)....\n");
                    add_timer_func_list(ip_ban_check,"ip_ban_check");
                    add_timer_interval(gettick()+10, ip_ban_check,0,0,60*1000);*/
                    break;
            }
            
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }
        catch (NullPointerException ex)
        {
            ex.printStackTrace();
        }
        ConfigurationManagement.login_lan_config_read((System.getProperty("LAN_CONF_NAME") !=null && !System.getProperty("LAN_CONF_NAME").equals("")) ? System.getProperty("LAN_CONF_NAME") : LAN_CONF_NAME);
        
        /*
                if (console) {
                set_defaultconsoleparse(parse_console);
                start_console();
        }
         */
        
        
        dbManagemtType.login_log("","","0",String.format("The login-server is ready (Server is listening on the port %d).",ConfigurationManagement.getLogin_port()) );
        Functions.showStatus("The login-server is %sready%s (Server is listening on the port %d).",Constants.CL_GREEN, Constants.CL_RESET,ConfigurationManagement.getLogin_port());
        
        try
        {
            ServerSocket ss = new ServerSocket(ConfigurationManagement.getLogin_port(),500,InetSocketAddress.createUnresolved("",ConfigurationManagement.getLogin_port()).getAddress());
            while(true)
            {
                Socket_data session =  new Socket_data(ss.accept(), new ParseLogin());
                UserManagement.addSession(session);
                session.setName("JavAthena");
            }
        }
        catch(BindException ex)
        {
            ex.printStackTrace();
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }
        return 0;
    }
    
    
    public boolean yesNoOnOffToBoolean(String anw)
    {
        anw = anw.toUpperCase();
        if(anw.equals("YES") || anw.equals("ON") )return true;
        if(anw.equals("NO") || anw.equals("OFF") )return false;
        throw new IllegalArgumentException("anw doit etre egale a yes/no/on/off");
    }
    
    
    
    public static void version(Socket_data session)
    {
        String ip = session.getClient_addr().getInetAddress().getHostAddress();
        dbManagemtType.login_log(ip,session.getName(),"",
                String.format("Sending of the server version (ip: %s)" , ip));
        byte reponse[] = new byte[10];
        reponse[0] = 0x31;
        reponse[1] = 0x75;
        reponse[2] = Version.ATHENA_MAJOR_VERSION;
        reponse[3] = Version.ATHENA_MINOR_VERSION;
        reponse[4] = Version.ATHENA_REVISION;
        reponse[5] = Version.ATHENA_RELEASE_FLAG;
        reponse[6] = Version.ATHENA_OFFICIAL_FLAG;
        reponse[7] = Version.ATHENA_SERVER_LOGIN;
        Functions.intToByteTab(Version.ATHENA_MOD_VERSION,8,10,reponse);
        session.func_send(reponse);
    }
    
    
    
    public static void codingKeyAdministration(Socket_data session)
    {
        session.func_send( getMd5Data(session));
        dbManagemtType.login_log(session.getIpStr(),"","0",
                String.format("Sending request of the coding key (ip: %s)" , session.getIpStr()));
    }
    
    public static void codingKey(Socket_data session)
    {
        
        session.func_send( getMd5Data(session));
        dbManagemtType.login_log(session.getIpStr(),"","0",
                String.format("'ladmin': Sending request of the coding key (ip: %s)" , session.getIpStr()));
    }
    
    public static byte[] getMd5Data(Socket_data session)
    {
        if(session.getMd5key() != null)
        {
            Functions.showWarning("login: abnormal request of MD5 key (already opened session).");
            session.setEof(1);
        }
        String tmpMd5 = Functions.getMd5String();
        session.setMd5key(tmpMd5);
        byte data[] = new byte[tmpMd5.length() + 4];
        Functions.intToByteTab(0x01dc,0,2,data);
        Functions.intToByteTab(data.length,2,4,data);
        Functions.stringToUnsignedByteTable(tmpMd5,data, 4, data.length);
        return data;
    }
    
    
    
    
    public static void alivePacketEncrypted(Socket_data session)
    {
        byte donnes[] = new byte[14];
        session.func_recv(donnes);
    }
    
    public static void alivePacket(Socket_data session)
    {
        byte donnes[] = new byte[24];
        session.func_recv(donnes);
    }
    
    
    
    
    public static void showTab(byte donnes[])
    {
        for(int i = 0;i < donnes.length; i++)
        {
            System.out.println(donnes[i] + " " + (char)donnes[i]);
        }
        System.out.println();
    }
    
    public static void logUnknownPackets(Socket_data session)
    {
    }
//	public void (Socket_data session){}
    
    
    public File getLog_fp()
    {
        return log_fp;
    }
    
    public void setLog_fp(File log_fp)
    {
        this.log_fp = log_fp;
    }
    
    
    public PrintWriter getOut()
    {
        return loginLogOut;
    }
    
    public void setOut(PrintWriter out)
    {
        loginLogOut = out;
    }
    
    
    public int getAuth_num()
    {
        return auth_num;
    }
    
    public void setAuth_num(int auth_num)
    {
        this.auth_num = auth_num;
    }
    
    public int getAuth_max()
    {
        return auth_max;
    }
    
    public void setAuth_max(int auth_max)
    {
        this.auth_max = auth_max;
    }
    
    public int[] getServer_fd()
    {
        return server_fd;
    }
    
    public void setServer_fd(int[] server_fd)
    {
        this.server_fd = server_fd;
    }
    
    public static int getPASSWORDENC()
    {
        return PASSWORDENC;
    }
    
    public static void setPASSWORDENC(int aPASSWORDENC)
    {
        PASSWORDENC = aPASSWORDENC;
    }
    
    
}
