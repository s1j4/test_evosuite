/*
 * Parse_login.java
 *
 * Created on October 3, 2005, 3:53 PM
 *
 * Copyright (c) 2006, Fran�ois Bradette
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of their contributors may be used to endorse or
 *       promote products derived from this software without specific prior
 *       written permission.
 *
 * This software is provided by the regents and contributors "as is" and any
 * express or implied warranties, including, but not limited to, the implied
 * warranties of merchantability and fitness for a particular purpose are
 * disclaimed.  In no event shall the regents and contributors be liable for any
 * direct, indirect, incidental, special, exemplary, or consequential damages
 * (including, but not limited to, procurement of substitute goods or services;
 * loss of use, data, or profits; or business interruption) however caused and
 * on any theory of liability, whether in contract, strict liability, or tort
 * (including negligence or otherwise) arising in any way out of the use of this
 * software, even if advised of the possibility of such damage.
 *
 * Translate from eAthena(c) by Fran�ois Bradette
 */


package javathena.login.parse;

import core.data.IParse;
import core.data.Socket_data;
import core.utiles.Functions;
import java.net.*;
import javathena.donne.*;
import javathena.login.*;
import core.utiles.ConfigurationManagement;
import javathena.login.Login;
/**
 *
 * @author Francois
 */
public class ParseLogin implements IParse
{
    public static final int PACKAGE_TO_SMALL = -257;
    public static final int ALIVE_PACKET = 0x200;
    public static final int ALIVE_PACKET_ENCRYPTED =0x204;
    
    public static final int NEW_CONNECTION_OF_CLIENT = 0x277;
    
    public static final int CONNECTION_OF_CLIENT = 0x64;
    public static final int CONNECTION_OF_CLIENT_ENCRYPTED = 0x01dd;
    public static final int CODING_KEY = 0x01db;
    public static final int CODING_KEY_ADMINISTRATION = 0x791a;
    public static final int CONNECTION_OF_CHAR_SERVER = 0x2710;
    public static final int VERSION = 0x7530;
    public static final int END_OF_CONNECTION = 0x7532;
    public static final int CONNECTION_OF_LOGIN_ADMINISTRATION = 0x7918;
    
    /** Creates a new instance of Parse_login */
    
    public ParseLogin()
    {
    }
    
    public  int parse(int commande,/*int length,*/ Socket_data session)
    {
        String ip = session.getIpStr();
        commande += session.func_recv()*256;
        
        if(ConfigurationManagement.isIpban())
        {
            if(Login.dbManagemtType.isIpBan(session.getIpStr()))
            {
                Functions.showWarning("packet from banned ip : %s\n", ip);
                session.setEof(1);
                return -1;
            }
            else
            {
                Functions.showInfo("packet from ip (ban check ok) : %s", ip);
            }
            
        }
        switch(commande)
        {
            case PACKAGE_TO_SMALL:
                session.setEof(1);
                break;
            case ALIVE_PACKET:
                Login.alivePacket(session);
                break;
            case ALIVE_PACKET_ENCRYPTED:
                Login.alivePacketEncrypted(session);
                break;
            case NEW_CONNECTION_OF_CLIENT:
            case CONNECTION_OF_CLIENT:
                //long time = System.nanoTime();
                UserManagement.connectionOfClientWithOutEncryption(session);
                 /*time = System.nanoTime()-time;
               System.out.printf("%10f \n",time/Math.pow(10,9));
                */
                break;
            case CONNECTION_OF_CLIENT_ENCRYPTED:
                UserManagement.connectionOfClientEncrypted(session);
                //Fonctions.showWarning("%d parse_login : niy",commande);
                break;
            case CODING_KEY:
                Login.codingKey(session);
                //Fonctions.showWarning("%d parse_login : niy",commande);
                break;
            case CODING_KEY_ADMINISTRATION:
                Login.codingKeyAdministration(session);
                //Fonctions.showWarning("%d parse_login : niy",commande);
                break;
            case CONNECTION_OF_CHAR_SERVER:
                UserManagement.connectionOfCharServer(session);
                break;
            case VERSION:
                Login.version(session);
                break;
            case END_OF_CONNECTION:
                Login.dbManagemtType.login_log(ip,"","",
                        String.format("End of connection (ip: " + ip + ")"));
                Functions.showWarning("End of connection (ip: %s)",ip);
                session.setEof(1);
                break;
            case CONNECTION_OF_LOGIN_ADMINISTRATION:
                UserManagement.administationLogin(session);
                Functions.showWarning("%d parse_login : niy",commande);
                break;
            default:
                return 0;
        }
        
        
        return 0;
    }
    
}