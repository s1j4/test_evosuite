/*
 * UserManagement.java
 *
 * Created on 3 avril 2006, 20:59
 *
 * Copyright (c) 2006, Fran�ois Bradette
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of their contributors may be used to endorse or
 *       promote products derived from this software without specific prior
 *       written permission.
 *
 * This software is provided by the regents and contributors "as is" and any
 * express or implied warranties, including, but not limited to, the implied
 * warranties of merchantability and fitness for a particular purpose are
 * disclaimed.  In no event shall the regents and contributors be liable for any
 * direct, indirect, incidental, special, exemplary, or consequential damages
 * (including, but not limited to, procurement of substitute goods or services;
 * loss of use, data, or profits; or business interruption) however caused and
 * on any theory of liability, whether in contract, strict liability, or tort
 * (including negligence or otherwise) arising in any way out of the use of this
 * software, even if advised of the possibility of such damage.
 *
 * Translate from eAthena(c) by Fran�ois Bradette
 */


package javathena.login;

import core.data.Auth_data;
import core.utiles.ConfigurationManagement;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Calendar;
import java.util.StringTokenizer;
import core.data.Global_reg;
import core.data.Socket_data;
import javathena.login.parse.ParseFromChar;
import core.utiles.sql.MySQLConfig;
import javathena.login.sql.data.Auth_data_SQL;
import core.utiles.Constants;
import core.utiles.Functions;
import core.utiles.MultilanguageManagement;
import core.utiles.UnsignedByte;
import javolution.util.FastMap;
import javolution.util.FastTable;

/**
 *
 * @author Darksid_1
 */
public class UserManagement
{
    
    /** Don't creates a new instance of UserManagement */
    private UserManagement()
    {
        
    }
    
    //private static final String LOGIN_LOG = ResourceBundle.getBundle("javathena/login/Log_ "+ (Constants.DB_MODE == Constants.DB_TXT?"txt":"sql")).getString("loginlog");
    //Account saved in save/account.txt
    //                  account_id,account
    private static FastMap auth_dats;
    //Accounts connected
    //                  account_id,account
    private static FastMap auth_dats_connecte;
    //                  userid,account
    private static FastMap index_userid_accountid;
    //              all accont_ids
    private static FastTable account_ids;
    //Server connected
    //                  userid  Socket data
    private static FastMap servers_connecter;
    
    //GM accounts
    private static FastMap gm_account_db;
    
    private static FastTable online_db;
    
    private static int account_id_count;
    
    private static FastTable sessions;
    private static FastTable char_sessions;
    
    private static FastMap dynamicFailBanCheck;
    
    private static FastMap keySessions;
    
    private static PrintWriter gmAccountsWrite;
    
    static
    {
        sessions = new FastTable();
        servers_connecter = new FastMap();
        
        char_sessions = new FastTable();
        
        auth_dats = new  FastMap();
        account_ids = new FastTable();
        index_userid_accountid = new FastMap();
        
        auth_dats_connecte = new  FastMap();
        online_db = new FastTable();
        
        gm_account_db = new FastMap();
        keySessions = new FastMap();
        
        dynamicFailBanCheck = new FastMap();
    }
    
    public static KeySession getKeySession(Integer id)
    {
        return (KeySession) keySessions.get(id);
    }
    
    public static KeySession removeKeySession(Integer id)
    {
        return (KeySession) keySessions.remove(id);
    }
    
    public static void addKeySession(Integer id,KeySession key)
    {
        keySessions.put(id, key);
    }
    
    public static synchronized Auth_data addUser(Auth_data new_account)
    {
        if(index_userid_accountid.get(new_account.getAccount_id()) == null)
        {
            auth_dats.put(new_account.getAccount_id(),new_account);
            index_userid_accountid.put(new_account.getUserid() ,new_account.getAccount_id());
            account_ids.add(new_account.getAccount_id());
            return new_account;
        }
        return null;
    }
    
    public static void addSession(Socket_data session)
    {
        sessions.add(session);
    }
    public static Socket_data getSessionAt(int ind)
    {
        return (Socket_data) sessions.get(ind);
    }
    
    public static int getNBSession()
    {
        return sessions.size();
    }
    
    public static void numberOfUser( Socket_data session)
    {
        byte donnes[] = new byte[4];
        byte alivePacket[] ={0x18,0x27};
        session.func_send(alivePacket);
        session.func_recv(donnes);
        session.setUsers(tabHexToInt(donnes));
        
        //showTab(donnes);
    }
    
    public static void emailCreation(Socket_data session)
    {
        byte donnes[] = new byte[44];
        
        String ip = session.getIpStr();
        session.func_recv(donnes);
        
        Integer accountid = Functions.byteTabToInt(0,4,donnes);
        String email = Functions.unsignedBytesToString(donnes,4,44).trim();
        if(!Functions.e_mail_check(email))
            Login.dbManagemtType.login_log(ip,session.getName(),"",
                    String.format(MultilanguageManagement.getLogin_log_1(),
                    session.getName(), accountid, ip));
        else
        {
            Auth_data tmpAcc = Login.dbManagemtType.getUser(accountid);
            if(tmpAcc != null && (tmpAcc.getEmail().equals(Constants.DEFAULT_EMAIL) || tmpAcc.getEmail() == null))
            {
                tmpAcc.setEmail(email);
                Login.dbManagemtType.mmo_auth_sync();
            }
            else
                Login.dbManagemtType.login_log(ip,session.getName(),"0",
                        String.format(MultilanguageManagement.getLogin_log_2(),
                        session.getName(), accountid, ip));
        }
    }
    
    public static void emailLimitedTime(Socket_data session)
    {
        byte donnes[] = new byte[4];
        byte answer[] = new byte[50];
        
        String ip = session.getIpStr();
        session.func_recv(donnes);
        Integer accountid = Functions.byteTabToInt(0,4,donnes);
        Auth_data tmpAcc = Login.dbManagemtType.getUser(accountid);
        if(tmpAcc != null)
        {
            Functions.intToByteTab(0x2717,0,2,answer);
            Functions.stringToUnsignedByteTable(tmpAcc.getEmail(),answer,6,46);
            Functions.doubleToByteTab( tmpAcc.getConnect_until_time().getTimeInMillis(),46,50, answer);
            session.func_send(answer);
        }
        else
            Login.dbManagemtType.login_log(ip,session.getName(),"",
                    String.format(MultilanguageManagement.getLogin_log_3(),
                    session.getName(), accountid, ip));
    }
    
    
    public static void statusChange(Socket_data session)
    {
        byte donnes[] = new byte[8];
        session.func_recv(donnes);
        String ip = session.getIpStr();
        int accountid = Functions.byteTabToInt(0,4,donnes);
        int statut = Functions.byteTabToInt(4,8,donnes);
        Auth_data actualAccount = Login.dbManagemtType.getUser(accountid);
        if(actualAccount != null)
        {
            if(actualAccount.getState() != statut)
            {
                Login.dbManagemtType.login_log(ip,session.getName(),"" + statut,
                        String.format(MultilanguageManagement.getLogin_log_4()  + Constants.NEWLINE,
                        session.getName(), accountid, statut, ip));
                if(statut != 0)
                {
                    int buff[] = new int[16];
                    Functions.intToIntTab(0x2731,0,2,buff);
                    Functions.intToIntTab(accountid,2,6,buff);
                    Functions.intToIntTab(statut,6,8,buff);
                    charif_sendallwos(-1, buff);
                    KeySession tmpKey = getKeySession(accountid);
                    tmpKey.setLogin1(tmpKey.getLogin1()+1);
                    addKeySession(accountid,tmpKey);
                }
                Login.dbManagemtType.mmo_auth_sync();
            }
            else
                Login.dbManagemtType.login_log(ip,session.getName(),"0" + statut,
                        String.format(MultilanguageManagement.getLogin_log_5()  + Constants.NEWLINE,
                        session.getName(), accountid, statut, ip));
            
        }
        else
            Login.dbManagemtType.login_log(ip,session.getName(),"0" + statut,
                    String.format(MultilanguageManagement.getLogin_log_6(),session.getName(), accountid, statut, ip));
    }
    
    
    public static void banResquest(Socket_data session)
    {
        byte donnes[] = new byte[16];
        String ip = session.getIpStr();
        session.func_recv(donnes);
        int accountid = Functions.byteTabToInt(0,4,donnes);
        Auth_data actualAccount = Login.dbManagemtType.getUser(accountid);
        if(actualAccount != null)
        {
            Calendar timestamp = Calendar.getInstance();
            if(actualAccount.getBan_until_time().getTimeInMillis() == 0 || actualAccount.getBan_until_time().getTimeInMillis() < timestamp.getTimeInMillis())
                timestamp = Calendar.getInstance();
            else
                timestamp = actualAccount.getBan_until_time();
            timestamp.set(timestamp.get(Calendar.YEAR) + Functions.byteTabToInt(4,8,donnes),
                    timestamp.get(Calendar.MONTH) + Functions.byteTabToInt(8,10,donnes),
                    timestamp.get(Calendar.DAY_OF_MONTH) + Functions.byteTabToInt(10,12,donnes),
                    timestamp.get(Calendar.HOUR_OF_DAY) + Functions.byteTabToInt(12,14,donnes),
                    timestamp.get(Calendar.MINUTE) + Functions.byteTabToInt(14,16,donnes),
                    timestamp.get(Calendar.SECOND) + Functions.byteTabToInt(16,18,donnes));
            
            if(timestamp != null)
            {
                if(timestamp.getTimeInMillis() <= Calendar.getInstance().getTimeInMillis())
                    timestamp = null;
                
                if(actualAccount.getBan_until_time().getTimeInMillis() != timestamp.getTimeInMillis())
                {
                    if(timestamp != null)
                    {
                        int buff[] = new int[16];
                        String timeString = Functions.calendarToString(timestamp);
                        Login.dbManagemtType.login_log(ip,session.getName(),"",
                                String.format(MultilanguageManagement.getLogin_log_7() + Constants.NEWLINE,
                                session.getAccount_id(), accountid, timestamp, (timestamp.getTimeInMillis() == 0 ? "no banishment" : timeString), ip));
                        
                        Functions.intToIntTab(0x2731,0,2,buff);
                        Functions.intToIntTab(accountid,2,6,buff);
                        buff[6] = 1; // 0: change of statut, 1: ban
                        Functions.longToIntTab(timestamp.getTimeInMillis(), 7, 16,buff);// status or final date of a banishment
                        charif_sendallwos(-1, buff);
                        KeySession tmpKey = getKeySession(accountid);
                        tmpKey.setLogin1(tmpKey.getLogin1()+1);
                        addKeySession(accountid,tmpKey);
                        actualAccount.setBan_until_time(timestamp);
                    }
                    else
                    {
                        Login.dbManagemtType.login_log(ip,session.getName(),"",
                                String.format(MultilanguageManagement.getLogin_log_8() + Constants.NEWLINE,
                                session.getName(), accountid, ip));
                    }
                    
                    Login.dbManagemtType.mmo_auth_sync();
                }
                else
                {
                    Login.dbManagemtType.login_log(ip,session.getName(),"",
                            String.format(MultilanguageManagement.getLogin_log_9() + Constants.NEWLINE,
                            session.getName(), accountid, ip));
                }
                
            }
            else
            {
                Login.dbManagemtType.login_log(ip,session.getName(),"",
                        String.format(MultilanguageManagement.getLogin_log_10()  + Constants.NEWLINE,
                        session.getName(), accountid, ip));
            }
        }
        else
            Login.dbManagemtType.login_log(ip,session.getName(),"",
                    String.format(MultilanguageManagement.getLogin_log_11()  + Constants.NEWLINE,
                    session.getName(), accountid, ip));
        
    }
    
    public static void changeSex(Socket_data session)
    {
        byte donnes[] = new byte[4];
        session.func_recv(donnes);
        String ip = session.getIpStr();
        int accountid = Functions.byteTabToInt(0,4,donnes);
        Auth_data actualAccount = Login.dbManagemtType.getUser(accountid);
        int sex;
        if(actualAccount != null)
        {
            if(actualAccount.getSex() != 2)
            {
                Login.dbManagemtType.login_log(ip,session.getName(),"0",
                        String.format(MultilanguageManagement.getLogin_log_12()
                        + Constants.NEWLINE, session.getName(), accountid, actualAccount.getSex(), ip));
            }
            else
            {
                if(actualAccount.getSex() == 0)
                {
                    sex = 1;
                }
                else
                {
                    sex = 0;
                }
                Login.dbManagemtType.login_log(ip,session.getName(),"0",
                        String.format(MultilanguageManagement.getLogin_log_13()
                        + Constants.NEWLINE,session.getName(), accountid , (sex == 2) ? 'S' : (sex == 1 ? 'M' : 'F'), ip));
                KeySession tmpKey = getKeySession(accountid);
                tmpKey.setLogin1(tmpKey.getLogin1()+1);
                addKeySession(accountid,tmpKey);
                actualAccount.setSex(sex);
                int buff[] = new int[16];
                Functions.intToIntTab(0x2723,0,2,buff);
                Functions.intToIntTab(accountid,2,6,buff);
                buff[7] = sex;
                charif_sendallwos(-1, buff);
                // Save
                Login.dbManagemtType.mmo_auth_sync();
                
            }
        }
        else
        {
            Login.dbManagemtType.login_log(ip,session.getName(),"0",
                    String.format(MultilanguageManagement.getLogin_log_14()
                    + Constants.NEWLINE, session.getName(), accountid , ip));
        }
    }
    
    public static void account_reg2(Socket_data session)
    {
        
        byte donnes[] = new byte[6];
        session.func_recv(donnes);
        int accountid = Functions.byteTabToInt(2,6,donnes);
        Auth_data actualAccount = Login.dbManagemtType.getUser(accountid);
        String ip = session.getIpStr();
        int length = Functions.byteTabToInt(0,2,donnes);
        Global_reg accountReg2ToSend[] =new Global_reg[Constants.ACCOUNT_REG2_NUM];
        if(actualAccount != null)
        {
            session.func_recv(donnes);
            Login.dbManagemtType.login_log(ip,session.getName(),"0",
                    String.format(MultilanguageManagement.getLogin_log_15()
                    + Constants.NEWLINE, session.getName(), accountid, ip));
            
            for(int j = 0,p = 13;j < Constants.ACCOUNT_REG2_NUM && p < length;j++)
            {
                accountReg2ToSend[j].setStr(Functions.unsignedBytesToString(donnes,p +(j * 31) ,p +((j+1) * 31)));
                p += 32;
                accountReg2ToSend[j].setValue(Functions.unsignedBytesToString(donnes,p + (j * 255),p +((j+1) * 255)));
                p += 256;
            }
            actualAccount.setAccount_reg2(accountReg2ToSend);
            //
            Functions.intToByteTab(0x2729,0,2,donnes);
            charif_sendallwos(session.getAccount_id(),donnes);
        }
        else
        {
            Login.dbManagemtType.login_log(ip,session.getName(),"0",
                    String.format(MultilanguageManagement.getLogin_log_16()+ Constants.NEWLINE,
                    session.getName(), accountid, session.getIpStr()));
        }
    }
    
    
    public static void toChangeAnEmail(Socket_data session)
    {
        Auth_data actualAccount;
        byte donnes[] = new byte[84];
        String ip = session.getIpStr();
        String actual_email, new_email;
        session.func_recv(donnes);
        int accountid = Functions.byteTabToInt(0,4,donnes);
        actual_email = Functions.unsignedBytesToString(donnes,4,44).trim();
        new_email = Functions.unsignedBytesToString(donnes,44,84).trim();
        if(!Functions.e_mail_check(actual_email))
        {
            Login.dbManagemtType.login_log(ip,session.getName(),"0",
                    String.format(MultilanguageManagement.getLogin_log_17() + Constants.NEWLINE,
                    session.getName(), accountid, ip));
            Login.dbManagemtType.getUser(accountid).setEmail("a@a.com");
        }
        else if(!Functions.e_mail_check(new_email))
            Login.dbManagemtType.login_log(ip,session.getName(),"0",
                    String.format(MultilanguageManagement.getLogin_log_18()+ Constants.NEWLINE,
                    session.getName(), accountid, ip));
        else if(new_email.equals("a@a.com"))
            Login.dbManagemtType.login_log(ip,session.getName(),"0",
                    String.format(MultilanguageManagement.getLogin_log_19() + Constants.NEWLINE,
                    session.getName(), accountid, ip));
        else
        {
            actualAccount = Login.dbManagemtType.getUser(accountid);
            if(actualAccount != null)
            {
                if(actualAccount.getEmail().equals(actual_email))
                {
                    actualAccount.setEmail(new_email);
                    Login.dbManagemtType.login_log(ip,session.getName(),"0",
                            String.format(MultilanguageManagement.getLogin_log_20() + Constants.NEWLINE,
                            session.getName(), accountid, actualAccount.getUserid(), new_email, ip));
                    Login.dbManagemtType.mmo_auth_sync();
                }
                else
                    Login.dbManagemtType.login_log(ip,session.getName(),"0",
                            String.format(MultilanguageManagement.getLogin_log_21()+ Constants.NEWLINE,
                            session.getName(), accountid, actualAccount.getUserid(), new_email, ip));
            }
            else
                Login.dbManagemtType.login_log(ip,session.getName(),"0",
                        String.format(MultilanguageManagement.getLogin_log_22() + Constants.NEWLINE,
                        session.getName(), accountid, ip));
        }
    }
    
    public static void toBecomeGM(Socket_data session)
    {
        byte donnes[] = new byte[70];
        int answer[] = new int[10];
        String ip = session.getIpStr();
        session.func_recv(donnes);
        Integer accountid = Functions.byteTabToInt(0,4,donnes);
        Functions.intToIntTab(0x2721,0,2,answer);
        Functions.intToIntTab(accountid,2,5,answer);
        String pass = Functions.unsignedBytesToString(donnes,8,70);
        if(pass.equals(ConfigurationManagement.getGm_pass()))
        {
            if(isGM(accountid) > 0)
            {
                if(ConfigurationManagement.getLevel_new_gm() > 0)
                {
                    Login.dbManagemtType.readGMAccount();
                    send_GM_accounts();
                    Functions.showInfo(MultilanguageManagement.getInfo_4() + Constants.NEWLINE, accountid, ConfigurationManagement.getLevel_new_gm());
                    Login.dbManagemtType.login_log(ip,session.getName(),"0",
                            String.format(MultilanguageManagement.getLogin_log_23() + Constants.NEWLINE, session.getName(), accountid, ConfigurationManagement.getLevel_new_gm(), ip));
                }
                else
                {
                    Functions.showError(MultilanguageManagement.getLogin_log_24() + Constants.NEWLINE, accountid);
                    Login.dbManagemtType.login_log(ip,session.getName(),"0",
                            String.format(MultilanguageManagement.getLogin_log_25() + Constants.NEWLINE ,
                            session.getName(), accountid, ip));
                }
            }
            else
            {
                Functions.showError(MultilanguageManagement.getError_6() + Constants.NEWLINE, accountid);
                Login.dbManagemtType.login_log(ip,session.getName(),"0",
                        String.format(MultilanguageManagement.getLogin_log_25() +  Constants.NEWLINE,
                        session.getName(), accountid, ip));
            }
        }
        else
        {
            Functions.showError(MultilanguageManagement.getError_7() + Constants.NEWLINE, accountid);
            Login.dbManagemtType.login_log(ip,session.getName(),"0",
                    String.format(MultilanguageManagement.getLogin_log_26()+ Constants.NEWLINE ,
                    session.getName(), accountid, ip));
        }
        
        charif_sendallwos(-1,answer);
        
    }
    public static int tabHexToInt(byte tab[])
    {
        int t = 0;
        for(int i = 0; i < tab.length ; i++)
        {
            t = UnsignedByte.parseByteToInt(tab[i])*((int)Math.pow(0x100, i));
        }
        return t;
    }
    
    public static synchronized Auth_data removeUser(Auth_data new_account)
    {
        if(index_userid_accountid.get(new_account.getAccount_id()) != null)
        {
            online_db.remove(new_account.getAccount_id());
            index_userid_accountid.remove(new_account.getUserid());
            account_ids.remove(new Integer(new_account.getAccount_id()));
            auth_dats.remove(new_account.getAccount_id());
            return new_account;
            
        }
        return null;
        
    }
    //-----------------------------------------------------
    // Clear Online User Database
    //-----------------------------------------------------
    public static int online_db_final()
    {
        online_db.clear();
        return 0;
    }
    
    public static int add_online_user(Auth_data account)
    {
        if(!is_user_online(account.getAccount_id()))
        {
            auth_dats_connecte.put(new Integer(account.getAccount_id()), account);
            online_db.add(account.getAccount_id());
            account.setLastlogin(Calendar.getInstance());
            return 0;
        }
        return -1;
    }
    public static void connectionOfCharServer(Socket_data session)
    {
        byte donnes[] = new byte[86];
        byte donnesEnvoi[];
        
        session.func_recv(donnes);
        
        String userId = "";
        String pass = "";
        String server_name = "";
        int ip[] = new int[4];
        int port = 0;
        userId = Functions.unsignedBytesToString(donnes,0,24);
        pass = Functions.unsignedBytesToString(donnes,24,50);
        
        for(int i = 52 ;i < 56;i++)
        {
            if(donnes[i] < 0)
                ip[i-52] = (donnes[i] + 256);
            else
                ip[i-52] = donnes[i];
        }
        port = Functions.unsignedByteToInt(donnes[56]) + (Functions.unsignedByteToInt(donnes[57])*256);
        session.setListenPort(port);
        for(int i = 58 ; donnes[i] != 0 && i < 86;i++)
        {
            if(donnes[i] < 0)
                server_name += (char)(donnes[i] + 256);
            else
                server_name += (char)donnes[i];
        }
        session.setName(server_name);
        String ipWithDot = ip[0] + "." + ip[1]
                + "." + ip[2] + "." +ip[3];
        Login.dbManagemtType.login_log(session.getIpStr(),session.getName(),"0",
                String.format(MultilanguageManagement.getLogin_log_27() +
                server_name + " @ " + ip[0] + "." + ip[1]
                + "." + ip[2] + "." +ip[3] + ":" + port + " (ip: " + ipWithDot + ")"));
        Auth_data tmp;
        /*Integer id = Login.dbManagemtMethods.getAccountID(userId);
        if(id == null)
            tmp = null;
        else*/
        tmp = Login.dbManagemtType.getUser(userId);
        if(tmp != null)
        {
            Integer id = tmp.getAccount_id();
            if(tmp.getSex() == 2)
            {
                if(servers_connecter.get((tmp.getAccount_id()+"")) == null)
                {
                    if(!pass.equals(tmp.getPass()))
                    {
                        Functions.showNotice(MultilanguageManagement.getNotice_14(),server_name,tmp.getAccount_id(),tmp.getUserid(),tmp.getPass(),ipWithDot);
                        Login.dbManagemtType.login_log(session.getIpStr(),session.getName(),"0",
                                String.format(MultilanguageManagement.getLogin_log_28(),server_name,tmp.getAccount_id(),tmp.getUserid(),tmp.getPass(),ipWithDot));
                    }
                    else
                    {
                        
                        session.setName(server_name);
                        session.setIp(ip);
                        session.setMaintenance(Functions.unsignedByteToInt(donnes[80]) + (Functions.unsignedByteToInt(donnes[81])*256));
                        session.setUsers(0);
                        session.setNew_(Functions.unsignedByteToInt(donnes[82]) + (Functions.unsignedByteToInt(donnes[83])*256));
                        servers_connecter.put(id,session);
                        char_sessions.add(session);
                        auth_dats_connecte.put(id,tmp);
                        donnesEnvoi = new byte[3];
                        donnesEnvoi[0] = 0x11;
                        donnesEnvoi[1] = 0x27;
                        donnesEnvoi[2] = 0;
                        session.func_send(donnesEnvoi);
                        session.setFunc_parse(new ParseFromChar());
                        session.setAccount_id(id);
                        tmp.setLastlogin();
                        send_GM_accounts();
                        return;
                    }
                }
                else
                {
                    Functions.showNotice(MultilanguageManagement.getNotice_15(),server_name,tmp.getAccount_id(),tmp.getUserid(),tmp.getPass(),session.getIpStr());
                    Login.dbManagemtType.login_log(session.getIpStr(),session.getName(),"0",
                            String.format(MultilanguageManagement.getLogin_log_29(),server_name,tmp.getAccount_id(),tmp.getUserid(),tmp.getPass(),session.getIpStr()));
                }
            }
        }
        else
        {
            Functions.showNotice(MultilanguageManagement.getNotice_16(),server_name,userId,pass,session.getIpStr());
            Login.dbManagemtType.login_log(session.getIpStr(),session.getName(),"0",
                    String.format(MultilanguageManagement.getLogin_log_30(),server_name,userId,pass,session.getIpStr()));
        }
        donnesEnvoi = new byte[3];
        donnesEnvoi[0] = 0x11;
        donnesEnvoi[1] = 0x27;
        donnesEnvoi[2] = 3;
        session.func_send(donnesEnvoi);
        //showTab(donnes);
    }
    public static void charServerToAuthentify(Socket_data session)
    {
        int acc;
        byte donnes[] = new byte[17];
        byte response[] = new byte[51];
        String ip = session.getIpStr();
        
        session.func_recv(donnes);
        acc = Functions.byteTabToInt(0,4,donnes);
        Auth_data accountToConnect = Login.dbManagemtType.getUser(acc);
        //Auth_data accountToConnect = this.auth_dats.get(acc);
        long login_id1 = Functions.byteTabToInt(4,8,donnes);
        long login_id2 = Functions.byteTabToInt(8,12,donnes);
        int sex = donnes[12];
        //this.check_ip_flag;
        
        KeySession tmpKey = getKeySession(acc);
        if(accountToConnect != null &&
                tmpKey.getLogin1() == login_id1 &&
                tmpKey.getLogin2() == login_id2 &&
                accountToConnect.getDelflag() == 0)
        {
            Calendar connect_until_time = Calendar.getInstance();
            accountToConnect.setDelflag(1);
            Login.dbManagemtType.login_log(ip,session.getName(),"0",
                    String.format(MultilanguageManagement.getLogin_log_31() ,
                    session.getName(), acc,ip));
            auth_dats_connecte.put(accountToConnect.getAccount_id(),accountToConnect);
            //online_db.add(accountToConnect.getAccount_id());
            response[0] = 0x13;
            response[1] = 0x27;
            Functions.intToByteTab(acc,2 ,6 ,response);
            response[6] = 0;
            Functions.stringToUnsignedByteTable(accountToConnect.getEmail(),response,7 ,47 );
            Functions.doubleToByteTab(accountToConnect.getConnect_until_time().getTimeInMillis(),47 ,51 ,response);
            session.func_send(response);
            return;
        }
        // authentification not found
        Login.dbManagemtType.login_log(ip,session.getName(),"0",
                String.format(MultilanguageManagement.getLogin_log_32(),session.getName(), acc,
                ip));
        response[0] = 0x13;
        response[1] = 0x27;
        Functions.intToByteTab(acc,2 ,6 ,response);
        response[6] = 1;
        session.func_send(response);
        
        
    }
    
    public static void account_idToOnline(Socket_data session)
    {
        byte donnes[] = new byte[4];
        session.func_recv(donnes);
        Integer account_id = Functions.byteTabToInt(0,4,donnes);
        Auth_data toConnect = Login.dbManagemtType.getUser(account_id);
        add_online_user(toConnect);
    }
    
    public static void account_idToOffline(Socket_data session)
    {
        byte donnes[] = new byte[4];
        session.func_recv(donnes);
        Integer account_id = Functions.byteTabToInt(0,4,donnes);
        Auth_data toDisconnect = Login.dbManagemtType.getUser(account_id);
        //Auth_data toDisconnect = auth_dats.get(account_id);
        if(toDisconnect != null)
        {
            toDisconnect.setDelflag(0);
            auth_dats_connecte.remove(account_id);
            online_db.remove(account_id);
        }
    }
    
    public static void connectionOfClientWithOutEncryption(Socket_data session)
    {
        byte data[] = new byte[53];
        String userid = "";
        String password = "";
        session.func_recv(data);
        int version = Functions.byteTabToInt(0,4,data);
        
        userid = Functions.unsignedBytesToString(data,4,27).trim();
        password = Functions.unsignedBytesToString(data,28,52).trim();
        Auth_data userAccount = null;
        /**/
        char lastChar = 0;
        int length = userid.length();
        if(lastChar != -1)
            lastChar = userid.toUpperCase().charAt(length - 1);
        if (userid.charAt(length - 2) == '_' && (lastChar == 'F' ||
                lastChar == 'M') )
        {
            userAccount = Login.dbManagemtType.getUser(userid.substring(0,length-2));
            if(userAccount != null)
            {
                connectionError(session, userAccount, 1);//
                return;
            }
        }
        else
        {
            userAccount = Login.dbManagemtType.getUser(userid);
        }
        boolean validPassword = false;
        if(userAccount != null && userAccount.getPass().equals(password))
            validPassword = true;
        
        connectionOfClient(session, userAccount, userid, password, validPassword, version);
    }
    
    
    /**
     *
     * @param session   the session of the <code>Socket_data</code> value.
     * @param userAccount
     * @param userid
     * @param password
     * @param validPassword
     * @param version
     **/
    public static void connectionOfClient(Socket_data session, Auth_data userAccount, String userid, String password, boolean validPassword, int version)
    {
        int i = 0;
        int sex = -1;
        String ipClient = session.getIpStr();
        
        try
        {
            int result =-1;
            
            //Calendar tv;
            //String tmpstr;
            int len;
            boolean newaccount = false;
            
            len = userid.length() - 2;
            char lastChar = userid.toUpperCase().charAt(len +1);
            if (userid.charAt(len) == '_' && (lastChar == 'F' ||
                    lastChar == 'M') &&
                    ConfigurationManagement.getNew_account_flag() == 1 &&
                    UserManagement.getAccountIdCount() <= Login.END_ACCOUNT_NUM
                    && len >= 4 && password.length() >= 4 && userAccount == null)
            {
                
                
                //only continue if amount in this time limit is allowed (account registration flood protection)[Kevin]
                if(System.currentTimeMillis() <= ConfigurationManagement.getNew_reg_tick() && ConfigurationManagement.getNum_regs()>= ConfigurationManagement.getAllowed_regs())
                {
                    Functions.showNotice(MultilanguageManagement.getNotice_17(),ipClient );
                    result = 3;
                    Login.dbManagemtType.login_log("","","" + result,
                            String.format(MultilanguageManagement.getLogin_log_33(),ipClient));
                    
                }
                else
                {
                    ConfigurationManagement.setNum_regs(0);
                }
                if(ConfigurationManagement.getNum_regs() == 0)
                    ConfigurationManagement.setNum_regs(System.currentTimeMillis() + ConfigurationManagement.getTime_allowed() *1000);
                ConfigurationManagement.addNum_regs();
                sex = Functions.charSexToInt(userid.charAt(userid.length()-1));
                userid = userid.substring(0,len);
                newaccount = true;
                userAccount = Login.dbManagemtType.addUser(userid,password,Constants.DEFAULT_EMAIL,sex);
                
                ConfigurationManagement.setAuth_before_save_file(0);
                Login.dbManagemtType.login_log(ipClient,userid,"" + result,
                        String.format(MultilanguageManagement.getLogin_log_34(),userid,password,userid.charAt(userid.length() - 1),ipClient));
                
            }
            
            
            //EXE Version check [Sirius]
            if (ConfigurationManagement.isCheck_client_version() && version != 0 &&
                    version != ConfigurationManagement.getClient_version_to_connect())
                connectionError(session, userAccount, 5);//result = 5;
            
            if(userAccount!=null && !newaccount)
            {
                if( !validPassword || !userid.equals(userAccount.getUserid()))
                {
                    result = 1;
                    Login.dbManagemtType.login_log(ipClient,userid,"" + result,
                            String.format(MultilanguageManagement.getLogin_log_35(),
                            userid,userAccount.getPass(),password,ipClient));
                    connectionError(session, userAccount, result);// // 1 = Incorrect Password
                }
                
                if (userAccount.getState() != 0)
                {
                    Login.dbManagemtType.login_log(ipClient,userid,"" + userAccount.getState() ,
                            String.format(MultilanguageManagement.getLogin_log_36(),
                            userid,userAccount.getPass(),userAccount.getState(),ipClient));
                    switch(userAccount.getState())
                    { // packet 0x006a value + 1
                        case 1: // 0 = Unregistered ID
                        case 2: // 1 = Incorrect Password
                        case 3: // 2 = This ID is expired
                        case 4: // 3 = Rejected from Server
                        case 5: // 4 = You have been blocked by the GM Team
                        case 6: // 5 = Your Game's EXE file is not the latest version
                        case 7: // 6 = Your are Prohibited to log in until %s
                        case 8: // 7 = Server is jammed due to over populated
                        case 9: // 8 = No more accounts may be connected from this company
                        case 10: // 9 = MSI_REFUSE_BAN_BY_DBA
                        case 11: // 10 = MSI_REFUSE_EMAIL_NOT_CONFIRMED
                        case 12: // 11 = MSI_REFUSE_BAN_BY_GM
                        case 13: // 12 = MSI_REFUSE_TEMP_BAN_FOR_DBWORK
                        case 14: // 13 = MSI_REFUSE_SELF_LOCK
                        case 15: // 14 = MSI_REFUSE_NOT_PERMITTED_GROUP
                        case 16: // 15 = MSI_REFUSE_NOT_PERMITTED_GROUP
                        case 100: // 99 = This ID has been totally erased
                        case 101: // 100 = Login information remains at %s.
                        case 102: // 101 = Account has been locked for a hacking investigation. Please contact the GM Team for more information
                        case 103: // 102 = This account has been temporarily prohibited from login due to a bug-related investigation
                        case 104: // 103 = This character is being deleted. Login is temporarily unavailable for the time being
                        case 105: // 104 = Your spouse character is being deleted. Login is temporarily unavailable for the time being
                            result =  userAccount.getState() - 1;
                        default:
                            result = 99; // 99 = ID has been totally erased
                    }
                    connectionError(session, userAccount, result);//
                    return;
                }
                
                if(ConfigurationManagement.isOnline_check())
                {
                    if (is_user_online(userAccount.getAccount_id()))
                    {
                        int buff[] = new int[8];
                        Functions.intToIntTab(0x2734,0,2,buff);
                        charif_sendallwos(-1,buff);
                        
                        Functions.showWarning(MultilanguageManagement.getWarning_40(),userAccount.getAccount_id());
                        result = 3;
                        connectionError(session, userAccount, result);// // Rejected
                        
                        Login.dbManagemtType.login_log(ipClient,userid,"" + result,
                                String.format(MultilanguageManagement.getLogin_log_37(),userid, userAccount.getPass(), Functions.calendarToString(userAccount.getBan_until_time()), ipClient));
                        
                    }
                }
                
                if (userAccount.getBan_until_time().getTimeInMillis() != 0)
                { // if account is banned
                    
                    String tmpstr = Functions.calendarToString(userAccount.getBan_until_time());
                    if (userAccount.getBan_until_time().getTimeInMillis() > Calendar.getInstance().getTimeInMillis())
                    { // always banned
                        connectionError(session, userAccount, 6);//result = 6; // 6 = Your are Prohibited to log in until %s
                        Login.dbManagemtType.login_log(ipClient,userid,"" + result,
                                String.format(MultilanguageManagement.getLogin_log_38(),userid, userAccount.getPass(), Functions.calendarToString(userAccount.getBan_until_time()), ipClient));
                        
                    }
                    else
                    { // ban is finished
                        Login.dbManagemtType.login_log(ipClient,userid,"" + result,
                                String.format(MultilanguageManagement.getLogin_log_39(), userid, userAccount.getPass(), tmpstr, ipClient));
                        userAccount.getBan_until_time().setTimeInMillis(0); // reset the ban time
                    }
                }
                if (userAccount.getBan_until_time().getTimeInMillis() != 0 && userAccount.getConnect_until_time().getTimeInMillis() < Calendar.getInstance().getTimeInMillis())
                {
                    connectionError(session, userAccount, 2);//result = 2; // 2 = This ID is expired
                    Login.dbManagemtType.login_log(ipClient,userid,"" + result,
                            String.format(MultilanguageManagement.getLogin_log_40(),userid,userAccount.getPass(),ipClient));
                    return;
                }
                
                Login.dbManagemtType.login_log(ipClient,userid,"" + result,
                        String.format(MultilanguageManagement.getLogin_log_41(),userid, userAccount.getPass(),ipClient));
            }
            else
            {
                if (userAccount == null)
                {
                    connectionError(session, userAccount, 0);//result = 0; // 0 = Unregistered ID
                    Login.dbManagemtType.login_log(ipClient,userid,"" + result,
                            String.format(MultilanguageManagement.getLogin_log_42(), userid, password,  ipClient));
                    return;
                }
                
            }
            
            KeySession key = new KeySession();
            int login_id = new java.security.SecureRandom().nextInt();
            while(login_id < 1)login_id = new java.security.SecureRandom().nextInt();
            key.setLogin1(login_id);
            
            login_id = new java.security.SecureRandom().nextInt();
            while(login_id < 1)login_id = new java.security.SecureRandom().nextInt();
            key.setLogin2(login_id);
            addKeySession(userAccount.getAccount_id(),key);
            if (sex != 2 && userAccount.getAccount_id() < 700000)
                Functions.showWarning(MultilanguageManagement.getWarning_41(), userid, userAccount.getAccount_id());
            
            userAccount.setLast_ip(session.getIpStr());
            
            
            // Save until for change ip/time of auth is not very useful => limited save for that
            // Save there informations isnot necessary, because they are saved in log file.
            if (ConfigurationManagement.lesslessAuth_before_save_file()  <= 0) // Reduce counter. 0 or less, we save
                Login.dbManagemtType.mmo_auth_sync();
            
            //result = -1; // account OK
            
            //tmp = auth_dats.get(account_id);
            if (result == -1 && userAccount != null)
            {
                Integer account_id = userAccount.getAccount_id();
                int gm_level = isGM(account_id);
                if (ConfigurationManagement.getMin_level_to_connect() > gm_level && gm_level != -1)
                {
                    Login.dbManagemtType.login_log(ipClient,userid,"" + result,
                            String.format(MultilanguageManagement.getLogin_log_42(),ConfigurationManagement.getMin_level_to_connect(), userid, gm_level, ipClient));
                    byte errTab[] = new byte[3];
                    
                    errTab[0] = UnsignedByte.parseIntToByte(0x81);
                    errTab[2] = 1;
                    session.func_send(errTab);
                }
                else
                {
                    if (gm_level >= 0)
                    {
                        Functions.showInfo(MultilanguageManagement.getLogin_log_43(), gm_level, userid);
                        userAccount.setLevel(gm_level);
                    }
                    else
                    {
                        Functions.showInfo(MultilanguageManagement.getInfo_5(),userid);
                    }
                    
                    /*if(userAccount.getLevel() > 0)
                        send_GM_accounts();*/
                    ConfigurationManagement.setServer_num(0);
                    byte reponseTab[] = new byte[47 + 32 * Login.MAX_SERVERS];
                    for(i = 0; i < Login.MAX_SERVERS && i < char_sessions.size(); i++)
                    {
                        Socket_data sessionCourrante = (Socket_data) char_sessions.get(i);
                        int port = sessionCourrante.getListenPort();
                        byte ipTab[] = sessionCourrante.getClient_addr().getInetAddress().getAddress();
                        String nom = sessionCourrante.getName();
                        int maintenance = sessionCourrante.getMaintenance();
                        int new_ = sessionCourrante.getNew_();
                        
                        reponseTab[47 + 32 * i] = ipTab[0];
                        reponseTab[47 + (32 * i)+1] = ipTab[1];
                        reponseTab[47 + (32 * i)+2] = ipTab[2];
                        reponseTab[47 + (32 * i)+3] = ipTab[3];
                        reponseTab[47+ (32 * i) +4] = UnsignedByte.parseIntToByte( port % 0x100);
                        port -=(port % 0x100);
                        port /= 0x100;
                        reponseTab[47+i*32+5] = UnsignedByte.parseIntToByte( port );
                        //47+server_num*32+6
                        for(int j = 0;j < 20 && j < session.getName().length() ;j++)
                        {
                            reponseTab[(47+i*32+6)+j] = (byte)session.getName().charAt(j);
                        }
                        Functions.intToByteTab(session.getUsers(), 47+i*32+26, 47+i*32+28, reponseTab);
                        Functions.intToByteTab(session.getMaintenance(), 47+i*32+28, 47+i*32+30, reponseTab);
                        Functions.intToByteTab(session.getNew_(), 47+i*32+30, 47+i*32+32, reponseTab);
                    }
                    // if at least 1 char-server
                    if(char_sessions.size() > 0)
                    {
                        reponseTab[0] = 0x69;
                        //key =  getKeySession(userAccount.getAccount_id());
                        Functions.intToByteTab(47 + 32 * char_sessions.size(),2 ,4 ,reponseTab);
                        Functions.intToByteTab(key.getLogin1(),4 ,8 ,reponseTab);
                        Functions.intToByteTab(userAccount.getAccount_id(),8 ,12 ,reponseTab);
                        Functions.intToByteTab(key.getLogin2(),12 ,16 ,reponseTab);
                        //Fonctions.intToByteTab(0, 16, 20, reponseTab); // in old version, that was for ip (not more used)
                        String date = Functions.calendarToString(userAccount.getLastlogin());
                        for(int j = 0;j < 24 && j < date.length();j++)// in old version, that was for name (not more used)
                            reponseTab[j+20] = (byte)date.charAt(j);
                        userAccount.setVersion(version);
                        reponseTab[46] = (byte)userAccount.getSex();
                        userAccount.setLastlogin();
                        session.func_send(reponseTab);
                    }
                    else
                    {
                        Functions.showWarning(MultilanguageManagement.getWarning_42(),userid,ipClient);
                        Login.dbManagemtType.login_log(ipClient,userid,"" + result,
                                String.format(MultilanguageManagement.getLogin_log_44(),userid,ipClient));
                        byte errTab[] = new byte[3];
                        errTab[0] = -127;
                        errTab[2] = 1;
                        session.func_send(errTab);
                    }
                }
            }
            else
            {
                connectionError(session, userAccount, result);//WFIFOSET(fd,23);
            }
            
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    
    private static void connectionError(final Socket_data session, final Auth_data userAccount, final int result)
    {
        byte reponseTab[] = new byte[23];
        reponseTab[0] = 0x6a;
        try
        {
            reponseTab[2] = UnsignedByte.parseIntToByte(result);
            if(result == -2)
            {
                Functions.addToBanListTXT(session.getIpStr());
            }
            
            if(result == 1)
            {
                if(ConfigurationManagement.getDynamic_pass_failure_ban())
                    Login.dbManagemtType.dynamicFailBanCheck(session.getIpStr());
            }
            // 6 = Your are Prohibited to log in until %s
            if (result == 6)
            {
                if (userAccount != null)
                {
                    if (userAccount.getBan_until_time().getTimeInMillis() != 0)
                    { // if account is banned, we send ban timestamp
                        String tmpstr = userAccount.getBan_until_time().getTime().toString();
                        for(int j=2; j < 23;j++)
                        {
                            reponseTab[j] = UnsignedByte.parseIntToByte((int)tmpstr.charAt(j-2));
                        }
                    }
                    else
                    { // we send error message
                        Functions.stringToUnsignedByteTable(userAccount.getError_message(),reponseTab,2,23);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        session.func_send(reponseTab);//WFIFOSET(fd,23);
        session.close();
    }
    
    //-------------------------------------------------------
    // Reading function of GM accounts file (and their level)
    //-------------------------------------------------------
    public static int read_gm_accountTXT()
    {
        String line = new String(new char[512]);
        
        File gmacc = new File(ConfigurationManagement.getGM_account_filename());
        
        int account_id = 0;
        int level = 0;
        int line_counter = 0;
        
        int start_range = 0;
        int end_range = 0;
        boolean is_range = false;
        int current_id = 0;
        if(gm_account_db == null)
            gm_account_db = new FastMap();
        
        
        ConfigurationManagement.setCreation_time_GM_account_file(gmacc.lastModified());
        
        if (!gmacc.exists() && gmacc.length() != 0)
        {
            Functions.showError(MultilanguageManagement.getError_17(), ConfigurationManagement.getGM_account_filename());
            Functions.showError(MultilanguageManagement.getError_8());
            Login.dbManagemtType.login_log("","","",
                    String.format(MultilanguageManagement.getLogin_log_45(), ConfigurationManagement.getGM_account_filename()));
            Login.dbManagemtType.login_log("","","",
                    MultilanguageManagement.getLogin_log_43());
            
            return 1;
        }
        
        try
        {
            BufferedReader fp  = new BufferedReader(new FileReader(gmacc));
            line = fp.readLine();
            while(line != null && UserManagement.getNBGM() < ConfigurationManagement.getGMMax())
            {
                
                if(line.indexOf("//") == 0 || line.compareTo("") == 0)
                {
                    line = fp.readLine();
                    line_counter++;
                    continue;
                }
                if(line.indexOf("//") != -1)
                {
                    line = line.substring(line.indexOf("//"), line.length());
                }
                
                line_counter++;
                if(line.indexOf("-") != -1 || line.indexOf("~") != -1)
                {
                    is_range = true;
                    StringTokenizer strTK = new StringTokenizer(line,"-~ ");
                    
                    if(strTK.hasMoreElements())
                    {
                        start_range = Integer.parseInt(strTK.nextElement().toString());
                        if(strTK.hasMoreElements())
                        {
                            end_range = Integer.parseInt(strTK.nextElement().toString());
                            if(strTK.hasMoreElements())
                                level = Integer.parseInt(strTK.nextElement().toString());
                            else
                                Functions.showError(MultilanguageManagement.getError_9(), ConfigurationManagement.getGM_account_filename(),line_counter);
                        }
                        else
                            Functions.showError(MultilanguageManagement.getError_10(), ConfigurationManagement.getGM_account_filename(), line_counter);
                    }
                    else
                        Functions.showError(MultilanguageManagement.getError_11(),ConfigurationManagement.getGM_account_filename(),line_counter);
                }
                else
                {
                    StringTokenizer strTK = new StringTokenizer(line," ");
                    if(strTK.hasMoreElements())
                    {
                        account_id = Integer.parseInt( strTK.nextElement().toString());
                        if(strTK.hasMoreElements())
                        {
                            level  = Integer.parseInt( strTK.nextElement().toString());
                        }
                        else
                            Functions.showError(MultilanguageManagement.getError_12(), ConfigurationManagement.getGM_account_filename(), line_counter);
                    }
                    else
                        Functions.showError(MultilanguageManagement.getError_13(), ConfigurationManagement.getGM_account_filename(), line_counter);
                }
                if (is_range)
                {
                    if (start_range == end_range)
                        Functions.showError(MultilanguageManagement.getError_14(),ConfigurationManagement.getGM_account_filename(), line_counter);
                    else
                        if (start_range > end_range)
                            Functions.showError(MultilanguageManagement.getError_15(), ConfigurationManagement.getGM_account_filename(), line_counter);
                        else
                            for (current_id = start_range ; current_id <= end_range ; current_id++)
                            {
                        int tmpLvl = levelIsValid(level, ConfigurationManagement.getGM_account_filename(), UserManagement.getNBGM(), line_counter);
                        if(tmpLvl != -1)
                            addGM(current_id,level);
                            }
                }
                else
                {
                    int tmpLvl = levelIsValid(level, ConfigurationManagement.getGM_account_filename(), UserManagement.getNBGM(), line_counter);
                    if(tmpLvl != -1)
                    {
                        addGM(account_id,level);
                    }
                }
                line = fp.readLine();
            }
            fp.close();
            
            gmAccountsWrite =  new PrintWriter(new FileWriter(gmacc,true),true);
            
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }
        return 0;
    }
    
    public static void send_GM_accounts()
    {
        Object gmIds[] = gm_account_db.keySet().toArray();
        byte donnesEnvoi[] = new byte[(gm_account_db.size()*5)+4];
        Functions.intToByteTab(0x2732,0,2,donnesEnvoi);
        int len = 4;
        for(int i = 0; i < gmIds.length ; i++)
        {
            Integer GMId = (Integer) gmIds[i];
            Integer level = (Integer) gm_account_db.get(GMId);
            if(level > 0)
            {
                Functions.intToByteTab(GMId, len, len + 4, donnesEnvoi);
                Functions.intToByteTab(level, len + 4, len + 5, donnesEnvoi);
                len += 5;
            }
        }
        Functions.intToByteTab(len,2,4,donnesEnvoi);
        charif_sendallwos(-1,donnesEnvoi);
    }
    
    public static int levelIsValid(int level,String GM_account_filename,int GM_num, int line_counter )
    {
        if (level <= 0)
        {
            Functions.showError(MultilanguageManagement.getError_16(),GM_account_filename,(GM_num + 1),line_counter,level);
            level = -1;
        }
        else
        {
            if (level > 99)
            {//, GM_account_filename, GM_num+1, level
                Functions.showNotice(MultilanguageManagement.getNotice_18(),GM_account_filename,(GM_num + 1),level);
                level = 99;
            }
        }
        return level;
    }
    //----------------------------------------------------------------------
    // Adds a new GM using acc id and level
    //----------------------------------------------------------------------
    /**
     *@param account_id
     *@param level
     **/
    public static boolean addGM(int account_id, int level)
    {
        boolean do_add = false;
        
        
        if (Login.dbManagemtType.getUser(account_id)!=null)
        {
            do_add = true;
        }
        
        
        if (getGM(account_id)!=null)
        {
            if (getGMLevel(account_id)== level)
            {
                Functions.showWarning(MultilanguageManagement.getWarning_43(), account_id, level);
                return false;
            }
            else
            {
                Functions.showWarning(MultilanguageManagement.getWarning_44(),account_id,getGMLevel(account_id),level);
                getGM(account_id).setLevel(level);
            }
            return true;
        }
        
        // if new account
        if (ConfigurationManagement.getGMMax() > UserManagement.getNBGM() && do_add)
        {
            Auth_data nGM = new Auth_data();
            nGM.setLevel(level);
            gm_account_db.put(account_id,nGM.getLevel());
            if (UserManagement.getNBGM() >= ConfigurationManagement.getGMMax())
            {
                Functions.showWarning(MultilanguageManagement.getWarning_45(),ConfigurationManagement.getGMMax());
                Login.dbManagemtType.login_log("","","0",
                        String.format(MultilanguageManagement.getLogin_log_46(), ConfigurationManagement.getGMMax() ));
            }
            return true;
        }
        return false;
    }
    
    public static void remove_online_user(Integer account_id)
    {
        if(account_id == 99)
            online_db_final();
        else
            online_db.remove(account_id);
    }
    
    public static boolean is_user_online(Integer account_id)
    {
        return online_db.contains(account_id);
    }
    public static int getNBUser()
    {
        return auth_dats.size();
    }
    public static int getNBGM()
    {
        return gm_account_db.size();
    }
    
    public static int charif_sendallwos(int sfd,int []buf)
    {
        
        Integer i, c=0, fd;
        for( i = 0;i<char_sessions.size();i++)
        {
            fd = ((Auth_data)char_sessions.get(i)).getAccount_id();
            if (fd >= 0 && fd != sfd)
            {
                ((Socket_data)sessions.get(i)).func_send(buf);
                c++;
            }
        }
        return c;
    }
    public static int charif_sendallwos(int sfd,byte []buf)
    {
        
        Integer i, c=0, fd;
        for( i = 0;i<char_sessions.size();i++)
        {
            fd = ((Socket_data)char_sessions.get(i)).getAccount_id();
            if (fd >= 0 && fd != sfd)
            {
                ((Socket_data)sessions.get(i)).func_send(buf);
                c++;
            }
        }
        return c;
    }
    public static int check_GM_file()
    {
        long new_time = new File(ConfigurationManagement.getGM_account_filename()).lastModified();
        if (ConfigurationManagement.getGm_account_filename_check_timer() < 1)
            return 0;
        if (new_time != ConfigurationManagement.getCreation_time_GM_account_file())
        {
            Login.dbManagemtType.readGMAccount();
            UserManagement.send_GM_accounts();
        }
        return 0;
    }
    public static synchronized Auth_data addUserTXT( String userid, String password, String email,int sex)
    {
        
        Auth_data new_account = new Auth_data();
        
        while (isGM(account_id_count) > 0)
            account_id_count++;
        
        int account_id = account_id_count++;
        new_account.setAccount_id(account_id);
        new_account.setUserid(userid);
        new_account.setSex(sex);
        new_account.setLogincount(0);
        new_account.setState(0);
        if(Functions.e_mail_check(email))
            new_account.setEmail(email);
        else
            new_account.setEmail("-");
        
        new_account.setError_message("-");
        
        Calendar datetmp = Calendar.getInstance();
        datetmp.setTimeInMillis(0);
        new_account.setBan_until_time(datetmp);
        
        if (ConfigurationManagement.getStart_limited_time() < 0)
        {
            datetmp.setTimeInMillis(0); // unlimited
        }
        else
        {
            datetmp.setTimeInMillis(datetmp.getTimeInMillis() + ConfigurationManagement.getStart_limited_time());
            
        }
        new_account.setConnect_until_time(datetmp);
        
        new_account.setLast_ip(null);
        new_account.setMemo("-");
        
        if(ConfigurationManagement.isUse_md5_passwds())
        {
            try
            {
                new_account.setPass(Functions.encryptePassword(password));
            }
            catch (NoSuchAlgorithmException ex)
            {
                ex.printStackTrace();
                return null;
            }
            catch (UnsupportedEncodingException ex)
            {
                ex.printStackTrace();
                return null;
            }
        }
        else
            new_account.setPass(password);
        return addUser(new_account);
    }
    
    public static synchronized int isGM(long account_id)
    {
        Auth_data tmp = (Auth_data) auth_dats.get(account_id);
        if(tmp!=null)
        {
            return (Integer)gm_account_db.get(account_id);
        }
        tmp = null;
        return -1;
    }
    
    
    public static synchronized void setAccountIdCount(int aic)
    {
        account_id_count = aic;
    }
    
    public static synchronized int getAccountIdCount()
    {
        return account_id_count;
    }
    
    public static synchronized void addAccountIdCount()
    {
        account_id_count++;
    }
    
    public static synchronized void addAccountIdCount(int nb)
    {
        account_id_count += nb;
    }
    
    public static Auth_data getUserTxt(Integer account_id)
    {
        return (Auth_data) auth_dats.get(account_id);
    }
    
    public static Auth_data getUserTxt(String user_id)
    {
        Integer accountID = (Integer) index_userid_accountid.get(user_id);
        if(accountID != null)
            return (Auth_data) auth_dats.get(accountID);
        else
            return null;
    }
    
    public static Auth_data getUserSQL(Integer account_id)
    {
        String sql = String.format(
                "SELECT `%s`,`%s`,`%s`,`lastlogin`,`logincount`,`sex`,`connect_until`,`last_ip`,`ban_until`,`state`,`%s`,`email` FROM `%s` WHERE BINARY `%s`='%s'",
                MySQLConfig.getLogin_db_account_id(), MySQLConfig.getLogin_db_userid(), MySQLConfig.getLogin_db_user_pass(), MySQLConfig.getLogin_db_level(), MySQLConfig.getLogin_db(), MySQLConfig.getLogin_db_account_id(), account_id);
        try
        {
            ResultSet result = MySQLConfig.executeQuery(sql);
            return  getUserSQL(result);
        }
        catch (SQLException ex)
        {
            ex.printStackTrace();
            return null;
        }
    }
    
    public static Auth_data getUserSQL(ResultSet result) throws SQLException
    {
        
        Auth_data user = null;
        if(result.next())
        {
            user = new Auth_data();
            user.setAccount_id(result.getInt(1));
            user.setUserid(result.getString(2));
            user.setPass(result.getString(3));
            Calendar lastlogin =  Calendar.getInstance();
            try
            {
                String dateStr = result.getString(4);
                if(!dateStr.equals("00-00-00 00:00:00"))
                    lastlogin.setTime(result.getDate(4));
                else
                    lastlogin.setTimeInMillis(0);
            }
            catch (SQLException ex)
            {
                ex.printStackTrace();
            }
            user.setLastlogin(lastlogin);
            user.setLogincount(result.getInt(5));
            user.setSex(Functions.charSexToInt(result.getString(6).charAt(0)));
            Calendar cut =  Calendar.getInstance();
            cut.setTimeInMillis(result.getInt(7));;
            user.setConnect_until_time(cut);
            user.setLast_ip(result.getString(8));
            Calendar but =  Calendar.getInstance();
            but.setTimeInMillis(result.getInt(9));
            user.setBan_until_time(but);
            user.setState(result.getInt(10));
            user.setLevel(result.getInt(11));
            user.setEmail(result.getString(12));
            return new Auth_data_SQL(user);
        }
        return null;
    }
    
    public static Auth_data getUserSQL(String user_id)
    {
        String sql = String.format(
                "SELECT `%s`,`%s`,`%s`,`lastlogin`,`logincount`,`sex`,`connect_until`,`last_ip`,`ban_until`,`state`,`%s`,`email` FROM `%s` WHERE BINARY `%s`='%s'",
                MySQLConfig.getLogin_db_account_id(), MySQLConfig.getLogin_db_userid(), MySQLConfig.getLogin_db_user_pass(), MySQLConfig.getLogin_db_level(), MySQLConfig.getLogin_db(), MySQLConfig.getLogin_db_userid(), user_id);
        try
        {
            ResultSet result = MySQLConfig.executeQuery(sql);
            return  getUserSQL(result);
        }
        catch (SQLException ex)
        {
            ex.printStackTrace();
            return null;
        }
    }
    
    public static Integer getAccountID(String user_id)
    {
        return (Integer) index_userid_accountid.get(user_id);
    }
    
    public static void unLogServer(Socket_data socket_data)
    {
        sessions.remove(socket_data);
        char_sessions.remove(socket_data);
        online_db.remove(socket_data.getAccount_id());
    }
    public static FastTable getAccountIds()
    {
        
        Object[] en =  auth_dats.keySet().toArray();
        FastTable col = new FastTable();
        for(int i = 0; i < en.length; i++)
            col.add(en[i]);
        return col;
    }
    
    private static int getGMLevel(Integer id)
    {
        return (Integer)gm_account_db.get(id);
    }
    
    private static Auth_data getGM(int account_id)
    {
        Integer level = (Integer) gm_account_db.get(account_id);
        if(level != null && level > 0)
            return Login.dbManagemtType.getUser(account_id);
        else
            return null;
    }
    
    public static void connectionOfClientEncrypted(Socket_data session)
    {
        Auth_data userAccount;
        byte data[] = new byte[45];
        session.func_recv(data);
        String userid = "";
        String password = "";
        int version = Functions.byteTabToInt(0,4,data);
        userid = Functions.unsignedBytesToString(data,4,27).trim();
        password = Functions.unsignedBytesToString(data,28,16).trim();
        userAccount = Login.dbManagemtType.getUser(userid);
        String MD5 = session.getMd5key();
        try
        {
            int length = userid.length();
            char lastChar = userid.toUpperCase().charAt(length - 1);
            if (userid.charAt(length - 2) == '_' && (lastChar == 'F' ||
                    lastChar == 'M') )
            {
                userAccount = Login.dbManagemtType.getUser(userid.substring(0,length-2));
                if(userAccount != null)
                {
                    connectionError(session, userAccount, 1);//
                    return;
                }
            }
            else
            {
                userAccount = Login.dbManagemtType.getUser(userid);
            }
            connectionOfClient(session, userAccount, userid, password, Functions.checkEncryptedPassword(MD5,password,userAccount.getPass(),Login.getPASSWORDENC()), version);
            
        }
        catch (NoSuchAlgorithmException ex)
        {
            ex.printStackTrace();
        }
        catch (UnsupportedEncodingException ex)
        {
            ex.printStackTrace();
        }
    }
    
    
    public static void changeSexChrif_changesex(Socket_data session)
    {
        
        byte data[] = new byte[2];
        session.func_recv(data);
        int length = Functions.byteTabToInt(0,2,data);
        data = new byte[length - 4];
        int accountid = Functions.byteTabToInt(0,2,data);
        int sex = Functions.byteTabToInt(2,4,data);
        Auth_data userTempo = Login.dbManagemtType.getUser(accountid);
        String ip = session.getIpStr();
        
        if(userTempo != null)
        {
            Login.dbManagemtType.login_log(ip,userTempo.getUserid(),"",
                    String.format(MultilanguageManagement.getLogin_log_47()
                    +Constants.NEWLINE, session.getName(),accountid ,
                    (sex == 2) ? 'S' : (sex == 1 ? 'M' : 'F'), session.getIpStr()));
            userTempo.setSex(sex);
            KeySession key = getKeySession(accountid);
            key.setLogin1(key.getLogin1() + 1);
            addKeySession(accountid,key);
            int buff[] = new int[16];
            Functions.intToIntTab(0x2723,0,2,buff);
            Functions.intToIntTab(accountid,2,4,buff);
            Functions.intToIntTab(sex,2,4,buff);
            charif_sendallwos(-1, buff);
        }
        else
        {
            Login.dbManagemtType.login_log(ip,"none","",
                    String.format(MultilanguageManagement.getLogin_log_48() + Constants.NEWLINE,
                    session.getName(), accountid, (sex == 2) ? 'S' : (sex ==1 ? 'M' : 'F'), session.getIpStr()));
        }
    }
    /**
     * login request by an admin
     *
     *@param Socket_data
     *
     */
    public static void administationLogin(Socket_data session)
    {
        boolean encrypted = session.func_recv() != 0;
        byte donnes[];
        
        if(encrypted)
            donnes = new byte[17];
        else
            donnes = new byte[25];
        
        session.func_recv(donnes);
    }
    
    public static Auth_data addUserSQL(String userid, String password, String email,int sex)
    {
        Auth_data_SQL new_accountSQL;
        try
        {
            new_accountSQL = new Auth_data_SQL(userid, password, email, sex);
            Auth_data new_account = addUser(new_accountSQL);
            if(new_account != null && new_account.getLevel() > 0)
            {
                read_gm_accountSQL();
                send_GM_accounts();
            }
            return new_account;
        }
        catch (SQLException ex)
        {
            ex.printStackTrace();
            return null;
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            return null;
        }
    }
    
    public static void dynamicFailBanCheckMySQL(String ipStr)
    {
        String sql = String.format("SELECT count(*) FROM `%s` WHERE `ip` = '%s' AND `rcode` = '1' AND `time` > NOW() - INTERVAL %d MINUTE",
                MySQLConfig.getLoginlog_db(), ipStr, ConfigurationManagement.getDynamic_pass_failure_ban_time());
        try
        {
            ResultSet anwser = MySQLConfig.executeQuery(sql);
            if(anwser.next() && anwser.getInt(1) >= ConfigurationManagement.getDynamic_pass_failure_ban_how_many())
            {
                addIpToBanListMySQL(ipStr);
            }
        }
        catch (SQLException ex)
        {
            ex.printStackTrace();
        }
    }
    
    public static void addIpToBanListMySQL(String ipStr) throws SQLException
    {
        int []ipTab = Functions.ipStringToByteTab(ipStr);
        String sql = String.format("INSERT INTO `ipbanlist`(`list`,`btime`,`rtime`,`reason`) VALUES ('%d.%d.%d.*', NOW() , NOW() +  INTERVAL %d MINUTE ,'Password error ban:')", ipTab[0], ipTab[1], ipTab[2], ConfigurationManagement.getDynamic_pass_failure_ban_how_long());
        MySQLConfig.executeUpdate(sql);
    }
    
    public static void dynamicFailBanCheckTXT(String ip)
    {
        Integer nb = (Integer) dynamicFailBanCheck.get(ip);
        if(nb == null)
            nb = 0;
        if(nb >= ConfigurationManagement.getDynamic_pass_failure_ban_how_many())
            Functions.addToBanListTXT(ip);
        else
            dynamicFailBanCheck.put(ip,++nb);
    }
    
    public static void read_gm_accountSQL()
    {
        String sqlQuery = String.format("SELECT `%s`,`%s` FROM `%s` WHERE `%s`> '0'",MySQLConfig.getLogin_db_account_id(),MySQLConfig.getLogin_db_level(),MySQLConfig.getLogin_db(),MySQLConfig.getLogin_db_level());
        try
        {
            ResultSet awnser =  MySQLConfig.executeQuery(sqlQuery);
            while(awnser.next())
            {
                addGM(awnser.getInt(1),awnser.getInt(2));
            }
        }
        catch (SQLException ex)
        {
            ex.printStackTrace();
        }
    }
    
    public static void sendUserList(Socket_data session)
    {
        byte data[] = new byte[8];
        int start = Functions.byteTabToInt(0,4,data);
        int end = Functions.byteTabToInt(4,8,data);
        
        byte dataToSend[] = new byte[(38 * account_ids.size()) + 4];
        int length = 4;
        account_ids.sort();
        for(int i = 0;(Integer)account_ids.get(i) < account_ids.size() &&
                (Integer)account_ids.get(i) > start && (Integer)account_ids.get(i) < end;i++)
        {
            Integer accountId = (Integer) account_ids.get(i);
            Auth_data account = Login.dbManagemtType.getUser(accountId);
            
            Functions.intToByteTab(accountId, length, length + 4, dataToSend);
            Functions.intToByteTab(isGM(accountId), length + 4, length + 5, dataToSend);
            Functions.stringToUnsignedByteTable(account.getUserid(),dataToSend,length + 5,length + 29);
            length += 38;
        }
    }
    
    
    
    public static void unban(Socket_data session)
    {
        byte data[] = new byte[4];
        session.func_recv(data);
        int acc = Functions.byteTabToInt(0,4,data);
        Auth_data account = Login.dbManagemtType.getUser(acc);
        if(account != null)
        {
            if(account.getBan_until_time().getTimeInMillis() != 0)
            {
                Login.dbManagemtType.login_log(session.getIpStr(),"","0",String.format(MultilanguageManagement.getWarning_46(),
                        session.getName(), acc, session.getIpStr()));
                Calendar bantime = Calendar.getInstance();
                bantime.setTimeInMillis(0);
                account.setBan_until_time(bantime);
            }
            else
            {
                Login.dbManagemtType.login_log(session.getIpStr(), "", "0",String.format(MultilanguageManagement.getWarning_10() ,
							          session.getName(), acc, session.getIpStr()));
            }
        }
    }
}
class KeySession
{
    private int login1;
    private int login2;
    public KeySession()
    {
    }
    public static KeySession getInstance()
    {
        return new KeySession();
    }
    public int getLogin1()
    {
        return login1;
    }
    
    public void setLogin1(int login1)
    {
        this.login1 = login1;
    }
    
    public int getLogin2()
    {
        return login2;
    }
    
    public void setLogin2(int login2)
    {
        this.login2 = login2;
    }
}