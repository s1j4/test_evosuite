/**
 * Definition of a connection property and supporting classes.
 *
 * @since 5
 */
package org.firebirdsql.jaybird.props.def;