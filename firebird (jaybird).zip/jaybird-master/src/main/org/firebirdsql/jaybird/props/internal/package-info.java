/**
 * Internal API for connection properties and the definition of properties supported by Jaybird.
 *
 * @since 5
 */
@InternalApi
package org.firebirdsql.jaybird.props.internal;

import org.firebirdsql.util.InternalApi;