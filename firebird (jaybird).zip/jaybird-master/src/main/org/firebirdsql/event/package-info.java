/**
 * Provides support for listening to Firebird events.
 */
package org.firebirdsql.event;