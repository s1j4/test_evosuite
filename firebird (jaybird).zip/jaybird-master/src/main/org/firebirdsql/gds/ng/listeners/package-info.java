/**
 * Listener interfaces and supporting classes for the {@link org.firebirdsql.gds.ng} API.
 *
 * @since 3
 */
@InternalApi
package org.firebirdsql.gds.ng.listeners;

import org.firebirdsql.util.InternalApi;