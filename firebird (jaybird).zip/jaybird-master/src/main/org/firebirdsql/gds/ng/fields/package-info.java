/**
 * Low-level field (i.e. column or parameter) and row descriptors, and row values.
 *
 * @since 3
 */
@InternalApi
package org.firebirdsql.gds.ng.fields;

import org.firebirdsql.util.InternalApi;