/**
 * Implementation of {@link org.firebirdsql.gds.ng.wire.crypt} for {@code Arc4}.
 *
 * @since 4
 */
@InternalApi
package org.firebirdsql.gds.ng.wire.crypt.arc4;

import org.firebirdsql.util.InternalApi;