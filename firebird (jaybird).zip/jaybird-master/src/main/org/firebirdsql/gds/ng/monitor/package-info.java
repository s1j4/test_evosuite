/**
 * Interfaces for operation monitoring (experimental feature).
 *
 * @since 4
 */
package org.firebirdsql.gds.ng.monitor;