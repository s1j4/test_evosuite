/**
 * Implementation of {@link org.firebirdsql.gds.ng.wire.auth} for the {@code Srp} family of authentication plugin.
 *
 * @since 3
 */
@InternalApi
package org.firebirdsql.gds.ng.wire.auth.srp;

import org.firebirdsql.util.InternalApi;