/**
 * SPI for Firebird authentication plugins for the wire protocol implementation.
 *
 * @since 3
 */
package org.firebirdsql.gds.ng.wire.auth;