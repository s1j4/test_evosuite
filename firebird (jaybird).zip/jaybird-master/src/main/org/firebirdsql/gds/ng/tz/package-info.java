/**
 * Mapping between Firebird and Java time zones and supporting classes.
 *
 * @since 4
 */
@InternalApi
package org.firebirdsql.gds.ng.tz;

import org.firebirdsql.util.InternalApi;