/**
 * Arguments (code, type information and value) for {@link org.firebirdsql.gds.impl.ParameterBufferBase}.
 */
@InternalApi
package org.firebirdsql.gds.impl.argument;

import org.firebirdsql.util.InternalApi;