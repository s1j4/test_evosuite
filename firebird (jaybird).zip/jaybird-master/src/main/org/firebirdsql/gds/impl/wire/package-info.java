/**
 * Pure-java implementation of {@link org.firebirdsql.gds.impl.GDSFactoryPlugin} and supporting classes.
 */
@InternalApi
package org.firebirdsql.gds.impl.wire;

import org.firebirdsql.util.InternalApi;