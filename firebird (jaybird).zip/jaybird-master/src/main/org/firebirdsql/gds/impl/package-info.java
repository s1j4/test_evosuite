/**
 * This package contains classes for the pluggable GDS implementations.
 */
@InternalApi
package org.firebirdsql.gds.impl;

import org.firebirdsql.util.InternalApi;