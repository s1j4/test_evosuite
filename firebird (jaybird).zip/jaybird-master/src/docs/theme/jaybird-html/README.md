firebird-html theme
===================

This theme is build using the asciidoctor-stylesheet-factory.
The source of the theme can be found in branch `firebird` of <https://github.com/mrotteveel/asciidoctor-stylesheet-factory>.

When updating, remove comments with `/\*.*?\*/` and replace multiple linebreaks using `(?:\r?\n){2,}` replacement `\n`