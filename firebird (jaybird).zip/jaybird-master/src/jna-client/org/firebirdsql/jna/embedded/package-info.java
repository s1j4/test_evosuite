/**
 * Provides look up of Firebird Embeddded library SPIs as defined by {@link org.firebirdsql.jna.embedded.spi}.
 *
 * @since 5
 */
package org.firebirdsql.jna.embedded;