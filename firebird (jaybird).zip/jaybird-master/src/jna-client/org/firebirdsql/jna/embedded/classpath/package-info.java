/**
 * Supporting classes for implementations of {@link org.firebirdsql.jna.embedded.spi} to provide Firebird Embedded on
 * the classpath.
 *
 * @since 5
 */
package org.firebirdsql.jna.embedded.classpath;