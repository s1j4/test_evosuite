/**
 * Mappings of fbclient API for use with JNA (Java Native Access).
 *
 * @since 3
 */
@InternalApi
package org.firebirdsql.jna.fbclient;

import org.firebirdsql.util.InternalApi;