/**
 * Implementation of the {@link org.firebirdsql.gds.ng} API for accessing Firebird using fbclient (native and embedded),
 * using the JNA (Java Native Access) library.
 *
 * @since 3
 */
@InternalApi
package org.firebirdsql.gds.ng.jna;

import org.firebirdsql.util.InternalApi;