#!/bin/sh
exec mvn install:install-file -Dfile=wheel-core-0.8.5.jar -DpomFile=pom.xml -DgroupId=wheel -DartifactId=wheel-core -Dversion=0.8.5 -Dpackaging=jar
