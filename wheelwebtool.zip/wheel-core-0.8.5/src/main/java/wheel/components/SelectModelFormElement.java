/*
Copyright (c) 2007-2008, Henri Frilund

All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
    * Neither the name of the <ORGANIZATION> nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package wheel.components;

import wheel.util.DynamicSelectModel;

public abstract class SelectModelFormElement extends FormElement implements IBuildableComponent {
    protected ISelectModel model;
    private boolean built;

    protected SelectModelFormElement(Component parent, String componentId, ISelectModel model, ElExpression binding) {
        super(parent, componentId);
        this.model = model;
        this.setBinding(binding);

        if (model instanceof DynamicSelectModel) {
            DynamicSelectModel dsm = (DynamicSelectModel)model;
            dsm.validate();
            dsm.setComponent(this);
            dsm.setTopLevelComponent(this._getTopLevelComponent(false));
        }
    }

    protected boolean enhance(RenderableComponent component, boolean selected, int index) {
        boolean enhanced = false;

        if (model instanceof IEnhancingSelectModel) {
            IEnhancingSelectModel enhancingSelectModel = (IEnhancingSelectModel)model;

            RenderableComponent renderBefore = enhancingSelectModel.renderBefore(component, index, selected);

            if (renderBefore != null) {
                enhanced = true;
                component.addRenderBefore(renderBefore);
            }

            RenderableComponent renderAfter = enhancingSelectModel.renderAfter(component, index, selected);

            if (renderAfter != null) {
                enhanced = true;
                component.addRenderAfter(renderAfter);
            }

            String renderHint = enhancingSelectModel.renderHint(component, index, selected);

            if (renderHint != null && renderHint.length() > 0) {
                enhanced = true;
                component.renderHint(renderHint);
            }
        }

        return enhanced;
    }

    public void preBuild() {

    }

    public void postBuild() {
    }

    public boolean _isBuilt() {
        return built;
    }

    public void _setBuilt(boolean built) {
        this.built = built;
    }
}
