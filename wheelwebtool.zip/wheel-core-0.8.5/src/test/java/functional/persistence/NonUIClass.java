package functional.persistence;

import wheel.components.StandaloneComponent;

public class NonUIClass extends StandaloneComponent {
    private String field1;

    public void buildComponent() {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}
