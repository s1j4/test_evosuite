package samples.pages;

public class LocalizationExample extends SamplesApp {
    public void buildComponent() {
        super.buildComponent();

        h3(message("message1"));
        h4(message("message2"));
        h4(message("appMessage1"));
        h4(message("replacementExample", "##Replacement 0##", "##Replacement 1##"));
        a(message("frontpageLinkText")).actionBinding(message("frontpageLinkHref"));
    }
}
