package samples.pages;

import wheel.components.StandaloneComponent;

public class MyErrorPage extends StandaloneComponent {
    public void buildComponent() {
        h1("piipaa");
    }
}
