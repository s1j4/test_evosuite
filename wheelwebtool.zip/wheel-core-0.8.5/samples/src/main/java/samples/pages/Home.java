package samples.pages;

public class Home extends SamplesApp {
    public void buildComponent() {
        super.buildComponent();

        div().clasS("main").
            h1("Samples application").up().
            h3("Available samples").up().
            ol().
                li().a("HelloWorld").actionBinding("HelloWorld").up(2).
                li().a("Number guessing game").actionBinding("NumberGuessing").up(2).
                li().a("Localization example").actionBinding("LocalizationExample").up(2).
                li().a("Layout example").actionBinding("LayoutExample");

    }
}
